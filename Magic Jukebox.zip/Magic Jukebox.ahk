#Requires AutoHotkey v2.0
#SingleInstance Force
Persistent

; ================= CONFIG =================
configFile := A_AppData "\Magic Jukebox\config.ini"
tempDir := A_Temp "\Rocola"
playlistsFile := A_AppData "\Magic Jukebox\playlists.ini"

DirCreate(tempDir)
DirCreate(A_AppData "\Magic Jukebox")



; ================= IDIOMAS =================
CreateLanguageFiles() {
    global configFile
    langDir := A_AppData "\Magic Jukebox"

    ; ===== EN =====
    enContent := ""
    enContent .= "[General]`n"
    enContent .= "app_name = Magic Jukebox`n"
    enContent .= "playing = Playing:`n"
    enContent .= "`n"
    enContent .= "[Tray]`n"
    enContent .= "search_song = Search song`n"
    enContent .= "playlist_manager = Playlist manager`n"
    enContent .= "open_miniplayer = Open miniplayer`n"
    enContent .= "auto_mode_on = Auto mode [On]`n"
    enContent .= "auto_mode_off = Auto mode [Off]`n"
    enContent .= "pause_resume = Pause / Resume`n"
    enContent .= "repeat_song = Repeat song`n"
    enContent .= "change_music_folder = Change music folder`n"
    enContent .= "change_vlc = Change VLC.exe`n"
    enContent .= "assign_hotkeys = Assign hotkeys`n"
    enContent .= "change_language = Change language`n"
    enContent .= "return_normal_mode = Return to normal mode`n"
    enContent .= "quit = Exit`n"
    enContent .= "`n"
    enContent .= "[Hotkeys]`n"
    enContent .= "prev_song = Previous song`n"
    enContent .= "next_song = Next song`n"
    enContent .= "search_song = Search song`n"
    enContent .= "pause_resume = Pause / Resume`n"
    enContent .= "repeat_song = Repeat song`n"
    enContent .= "playlist = Playlist manager`n"
    enContent .= "guide = Guide`n"
    enContent .= "update_hotkeys = Update hotkeys`n"
    enContent .= "hotkeys_updated = Hotkeys updated successfully.`n"
    enContent .= "invalid_hotkey = The hotkey for '{1}' is not valid.``nCorrect the value and try again.`n"
    enContent .= "guide_text = Format: Modifier+Key``n``nValid modifiers:``n  Ctrl, Alt, Shift, Win``n``nExamples:``n  Ctrl+9``n  Alt+F1``n  Ctrl+Shift+P``n  Win+R``n``nYou can also assign individual keys``nalthough not recommended (e.g. F9).``n``nFor Numpad: Ctrl+Numpad9``nRemember to enable Num Lock if using Numpad.`n"
    enContent .= "`n"
    enContent .= "[Setup]`n"
    enContent .= "select_music_folder = Select your music folder`n"
    enContent .= "must_select_folder = You must select a music folder to continue.`n"
    enContent .= "invalid_folder = Invalid folder.`n"
    enContent .= "select_vlc = Select the vlc.exe file`n"
    enContent .= "must_select_vlc = You must select vlc.exe.`n"
    enContent .= "incorrect_file = Incorrect file.`n"
    enContent .= "music_folders_title = Music Folders`n"
    enContent .= "music_folders_label = Music folders:`n"
    enContent .= "add_folder = + Add`n"
    enContent .= "change_folder_btn = Change`n"
    enContent .= "remove_folder = Remove`n"
    enContent .= "select_music_folder_dir = Select music folder`n"
    enContent .= "select_new_location = Select new location`n"
    enContent .= "must_keep_one_folder = You must keep at least one music folder.`n"
    enContent .= "add_folder_recursive = + Add with subfolders`n"
    enContent .= "tray_tip_start = Magic Jukebox is here, running in the background`n"
    enContent .= "`n"
    enContent .= "[Search]`n"
    enContent .= "search_title = Search song`n"
    enContent .= "no_music_folder = No music folder designated.``nSet it up first.`n"
    enContent .= "no_songs_found = No songs found in the current folder.`n"
    enContent .= "`n"
    enContent .= "[Playlist]`n"
    enContent .= "playlist_title = Playlist Manager`n"
    enContent .= "reorder_title_playlists = Playlist Manager (Setting new order)`n"
    enContent .= "reorder_title_songs = Playlist Manager (Setting order of {1})`n"
    enContent .= "search_song = Search song:`n"
    enContent .= "playlists = Playlists:`n"
    enContent .= "playlist_songs = Playlist songs:`n"
    enContent .= "play = ▶ Play`n"
    enContent .= "remove = ➖ Remove`n"
    enContent .= "delete = 🗑 Delete`n"
    enContent .= "create_playlist = ➕ Create playlist`n"
    enContent .= "play_all = ▶ Play all Playlists`n"
    enContent .= "loop_on = Loop: ON`n"
    enContent .= "loop_off = Loop: OFF`n"
    enContent .= "random_on = Random: ON`n"
    enContent .= "random_off = Random: OFF`n"
    enContent .= "reorder_instructions = To change the playback order, double-click a song or playlist to enter edit mode.`n"
    enContent .= "reorder_playlists_instructions = Select a playlist and use ▲ ▼ to move it.`n"
    enContent .= "reorder_songs_instructions = Select a song and use ▲ ▼ to move it.`n"
    enContent .= "move_up = ▲ Up`n"
    enContent .= "move_down = ▼ Down`n"
    enContent .= "exit_reorder = ✖ Exit edit mode`n"
    enContent .= "new_playlist_title = Create playlist`n"
    enContent .= "new_playlist_label = Name of the new playlist:`n"
    enContent .= "create = Create`n"
    enContent .= "cancel = Cancel`n"
    enContent .= "name_empty = The name cannot be empty.`n"
    enContent .= "name_exists = A playlist with that name already exists.`n"
    enContent .= "confirm_delete = Are you sure you want to delete this playlist?`n"
    enContent .= "confirm_delete_title = Confirm`n"
    enContent .= "select_playlist_first = Select or create a playlist first.`n"
    enContent .= "`n"
    enContent .= "[MiniPlayer]`n"
    enContent .= "artist = Artist`n"
    enContent .= "album = Album`n"
    enContent .= "title = Title`n"
    enContent .= "`n"
    enContent .= "[Language]`n"
    enContent .= "language_title = Select language`n"
    enContent .= "`n"
    try FileDelete(langDir  "\en-lang.ini")
    FileAppend(enContent, langDir "\en-lang.ini", "UTF-8")

    ; ===== ES =====
    esContent := ""
    esContent .= "[General]`n"
    esContent .= "app_name = Magic Jukebox`n"
    esContent .= "playing = Reproduciendo:`n"
    esContent .= "`n"
    esContent .= "[Tray]`n"
    esContent .= "search_song = Buscar canción`n"
    esContent .= "playlist_manager = Lista de reproducción`n"
    esContent .= "open_miniplayer = Abrir minireproductor`n"
    esContent .= "auto_mode_on = Modo automático [On]`n"
    esContent .= "auto_mode_off = Modo automático [Off]`n"
    esContent .= "pause_resume = Pausar / Reanudar`n"
    esContent .= "repeat_song = Repetir canción`n"
    esContent .= "change_music_folder = Cambiar carpeta de música`n"
    esContent .= "change_vlc = Cambiar VLC.exe`n"
    esContent .= "assign_hotkeys = Asignar atajos`n"
    esContent .= "change_language = Cambiar idioma`n"
    esContent .= "return_normal_mode = Volver al modo normal`n"
    esContent .= "quit = Salir`n"
    esContent .= "`n"
    esContent .= "[Hotkeys]`n"
    esContent .= "prev_song = Canción anterior`n"
    esContent .= "next_song = Siguiente canción`n"
    esContent .= "search_song = Buscar canción`n"
    esContent .= "pause_resume = Pausar / Reanudar`n"
    esContent .= "repeat_song = Repetir canción`n"
    esContent .= "playlist = Lista de reproducción`n"
    esContent .= "guide = Guía`n"
    esContent .= "update_hotkeys = Actualizar atajos`n"
    esContent .= "hotkeys_updated = Atajos actualizados correctamente.`n"
    esContent .= "invalid_hotkey = El atajo para '{1}' no es válido.``nCorrija el valor e intente de nuevo.`n"
    esContent .= "guide_text = Formato: Modificador+Tecla``n``nModificadores válidos:``n  Ctrl, Alt, Shift, Win``n``nEjemplos:``n  Ctrl+9``n  Alt+F1``n  Ctrl+Shift+P``n  Win+R``n``nTambién puede asignar teclas individuales``naunque no se recomienda (ej: F9).``n``nPara Numpad: Ctrl+Numpad9``nRecuerde activar Bloq Num si usa Numpad.`n"
    esContent .= "`n"
    esContent .= "[Setup]`n"
    esContent .= "select_music_folder = Selecciona la carpeta designada de música`n"
    esContent .= "must_select_folder = Debes seleccionar una carpeta de música para continuar.`n"
    esContent .= "invalid_folder = Carpeta inválida.`n"
    esContent .= "select_vlc = Selecciona el archivo vlc.exe`n"
    esContent .= "must_select_vlc = Debes seleccionar vlc.exe.`n"
    esContent .= "incorrect_file = Archivo incorrecto.`n"
    esContent .= "music_folders_title = Carpetas de música`n"
    esContent .= "music_folders_label = Carpetas de música:`n"
    esContent .= "add_folder = + Agregar`n"
    esContent .= "change_folder_btn = Cambiar`n"
    esContent .= "remove_folder = Eliminar`n"
    esContent .= "select_music_folder_dir = Selecciona la carpeta de música`n"
    esContent .= "select_new_location = Selecciona la nueva ubicación`n"
    esContent .= "must_keep_one_folder = Debes mantener al menos una carpeta de música.`n"
    esContent .= "add_folder_recursive = + Agregar con subcarpetas`n"
    esContent .= "tray_tip_start = Magic Jukebox está aquí, en segundo plano`n"
    esContent .= "`n"
    esContent .= "[Search]`n"
    esContent .= "search_title = Buscar canción`n"
    esContent .= "no_music_folder = No hay carpeta de música designada.``nConfigúrala primero.`n"
    esContent .= "no_songs_found = No se encontraron canciones en la carpeta actual.`n"
    esContent .= "`n"
    esContent .= "[Playlist]`n"
    esContent .= "playlist_title = Administrador de Playlists`n"
    esContent .= "reorder_title_playlists = Administrador de Playlists (Asignando nuevo orden)`n"
    esContent .= "reorder_title_songs = Administrador de Playlists (Asignando orden de {1})`n"
    esContent .= "search_song = Buscar canción:`n"
    esContent .= "playlists = Playlists:`n"
    esContent .= "playlist_songs = Canciones de la playlist:`n"
    esContent .= "play = ▶ Reproducir`n"
    esContent .= "remove = ➖ Quitar`n"
    esContent .= "delete = 🗑 Eliminar`n"
    esContent .= "create_playlist = ➕ Crear lista de reproducción`n"
    esContent .= "play_all = ▶ Reproducir todas las Playlists`n"
    esContent .= "loop_on = Bucle: ON`n"
    esContent .= "loop_off = Bucle: OFF`n"
    esContent .= "random_on = Aleatorio: ON`n"
    esContent .= "random_off = Aleatorio: OFF`n"
    esContent .= "reorder_instructions = Para cambiar el orden de reproducción, haz doble click en una canción o playlist para entrar al modo edición.`n"
    esContent .= "reorder_playlists_instructions = Seleccione una playlist y use ▲ ▼ para moverla.`n"
    esContent .= "reorder_songs_instructions = Seleccione una canción y use ▲ ▼ para moverla.`n"
    esContent .= "move_up = ▲ Subir`n"
    esContent .= "move_down = ▼ Bajar`n"
    esContent .= "exit_reorder = ✖ Salir del modo edición`n"
    esContent .= "new_playlist_title = Crear lista de reproducción`n"
    esContent .= "new_playlist_label = Nombre de la nueva lista:`n"
    esContent .= "create = Crear`n"
    esContent .= "cancel = Cancelar`n"
    esContent .= "name_empty = El nombre no puede estar vacío.`n"
    esContent .= "name_exists = Ya existe una lista con ese nombre.`n"
    esContent .= "confirm_delete = ¿Seguro que quieres borrar la playlist?`n"
    esContent .= "confirm_delete_title = Confirmar`n"
    esContent .= "select_playlist_first = Selecciona o crea una playlist primero.`n"
    esContent .= "`n"
    esContent .= "[MiniPlayer]`n"
    esContent .= "artist = Artista`n"
    esContent .= "album = Álbum`n"
    esContent .= "title = Título`n"
    esContent .= "`n"
    esContent .= "[Language]`n"
    esContent .= "language_title = Seleccionar idioma`n"
    esContent .= "`n"
    try FileDelete(langDir  "\es-lang.ini")
    FileAppend(esContent, langDir "\es-lang.ini", "UTF-8")

    ; ===== PT =====
    ptContent := ""
    ptContent .= "[General]`n"
    ptContent .= "app_name = Magic Jukebox`n"
    ptContent .= "playing = Reproduzindo:`n"
    ptContent .= "`n"
    ptContent .= "[Tray]`n"
    ptContent .= "search_song = Buscar música`n"
    ptContent .= "playlist_manager = Lista de reprodução`n"
    ptContent .= "open_miniplayer = Abrir miniplayer`n"
    ptContent .= "auto_mode_on = Modo automático [On]`n"
    ptContent .= "auto_mode_off = Modo automático [Off]`n"
    ptContent .= "pause_resume = Pausar / Retomar`n"
    ptContent .= "repeat_song = Repetir música`n"
    ptContent .= "change_music_folder = Alterar pasta de música`n"
    ptContent .= "change_vlc = Alterar VLC.exe`n"
    ptContent .= "assign_hotkeys = Atribuir atalhos`n"
    ptContent .= "change_language = Alterar idioma`n"
    ptContent .= "return_normal_mode = Voltar ao modo normal`n"
    ptContent .= "quit = Sair`n"
    ptContent .= "`n"
    ptContent .= "[Hotkeys]`n"
    ptContent .= "prev_song = Música anterior`n"
    ptContent .= "next_song = Próxima música`n"
    ptContent .= "search_song = Buscar música`n"
    ptContent .= "pause_resume = Pausar / Retomar`n"
    ptContent .= "repeat_song = Repetir música`n"
    ptContent .= "playlist = Lista de reprodução`n"
    ptContent .= "guide = Guia`n"
    ptContent .= "update_hotkeys = Atualizar atalhos`n"
    ptContent .= "hotkeys_updated = Atalhos atualizados com sucesso.`n"
    ptContent .= "invalid_hotkey = O atalho para '{1}' não é válido.``nCorrija o valor e tente novamente.`n"
    ptContent .= "guide_text = Formato: Modificador+Tecla``n``nModificadores válidos:``n  Ctrl, Alt, Shift, Win``n``nExemplos:``n  Ctrl+9``n  Alt+F1``n  Ctrl+Shift+P``n  Win+R``n``nTambém pode atribuir teclas individuais``nembora não seja recomendado (ex: F9).``n``nPara Numpad: Ctrl+Numpad9``nLembre-se de ativar o Num Lock.`n"
    ptContent .= "`n"
    ptContent .= "[Setup]`n"
    ptContent .= "select_music_folder = Selecione a pasta de música`n"
    ptContent .= "must_select_folder = Você deve selecionar uma pasta de música para continuar.`n"
    ptContent .= "invalid_folder = Pasta inválida.`n"
    ptContent .= "select_vlc = Selecione o arquivo vlc.exe`n"
    ptContent .= "must_select_vlc = Você deve selecionar o vlc.exe.`n"
    ptContent .= "incorrect_file = Arquivo incorreto.`n"
    ptContent .= "music_folders_title = Pastas de música`n"
    ptContent .= "music_folders_label = Pastas de música:`n"
    ptContent .= "add_folder = + Adicionar`n"
    ptContent .= "change_folder_btn = Alterar`n"
    ptContent .= "remove_folder = Remover`n"
    ptContent .= "select_music_folder_dir = Selecione a pasta de música`n"
    ptContent .= "select_new_location = Selecione a nova localização`n"
    ptContent .= "must_keep_one_folder = Você deve manter pelo menos uma pasta de música.`n"
    ptContent .= "add_folder_recursive = + Adicionar com subpastas`n"
    ptContent .= "tray_tip_start = Magic Jukebox está aqui, em segundo plano`n"
    ptContent .= "`n"
    ptContent .= "[Search]`n"
    ptContent .= "search_title = Buscar música`n"
    ptContent .= "no_music_folder = Nenhuma pasta de música designada.``nConfigure primeiro.`n"
    ptContent .= "no_songs_found = Nenhuma música encontrada na pasta atual.`n"
    ptContent .= "`n"
    ptContent .= "[Playlist]`n"
    ptContent .= "playlist_title = Gerenciador de Playlists`n"
    ptContent .= "reorder_title_playlists = Gerenciador de Playlists (Definindo nova ordem)`n"
    ptContent .= "reorder_title_songs = Gerenciador de Playlists (Definindo ordem de {1})`n"
    ptContent .= "search_song = Buscar música:`n"
    ptContent .= "playlists = Playlists:`n"
    ptContent .= "playlist_songs = Músicas da playlist:`n"
    ptContent .= "play = ▶ Reproduzir`n"
    ptContent .= "remove = ➖ Remover`n"
    ptContent .= "delete = 🗑 Excluir`n"
    ptContent .= "create_playlist = ➕ Criar playlist`n"
    ptContent .= "play_all = ▶ Reproduzir todas as Playlists`n"
    ptContent .= "loop_on = Loop: ON`n"
    ptContent .= "loop_off = Loop: OFF`n"
    ptContent .= "random_on = Aleatório: ON`n"
    ptContent .= "random_off = Aleatório: OFF`n"
    ptContent .= "reorder_instructions = Para alterar a ordem de reprodução, clique duas vezes em uma música ou playlist.`n"
    ptContent .= "reorder_playlists_instructions = Selecione uma playlist e use ▲ ▼ para movê-la.`n"
    ptContent .= "reorder_songs_instructions = Selecione uma música e use ▲ ▼ para movê-la.`n"
    ptContent .= "move_up = ▲ Subir`n"
    ptContent .= "move_down = ▼ Descer`n"
    ptContent .= "exit_reorder = ✖ Sair do modo de edição`n"
    ptContent .= "new_playlist_title = Criar playlist`n"
    ptContent .= "new_playlist_label = Nome da nova playlist:`n"
    ptContent .= "create = Criar`n"
    ptContent .= "cancel = Cancelar`n"
    ptContent .= "name_empty = O nome não pode estar vazio.`n"
    ptContent .= "name_exists = Já existe uma playlist com esse nome.`n"
    ptContent .= "confirm_delete = Tem certeza que deseja excluir esta playlist?`n"
    ptContent .= "confirm_delete_title = Confirmar`n"
    ptContent .= "select_playlist_first = Selecione ou crie uma playlist primeiro.`n"
    ptContent .= "`n"
    ptContent .= "[MiniPlayer]`n"
    ptContent .= "artist = Artista`n"
    ptContent .= "album = Álbum`n"
    ptContent .= "title = Título`n"
    ptContent .= "`n"
    ptContent .= "[Language]`n"
    ptContent .= "language_title = Selecionar idioma`n"
    ptContent .= "`n"
    try FileDelete(langDir  "\pt-lang.ini")
    FileAppend(ptContent, langDir "\pt-lang.ini", "UTF-8")

    ; ===== FR =====
    frContent := ""
    frContent .= "[General]`n"
    frContent .= "app_name = Magic Jukebox`n"
    frContent .= "playing = En lecture :`n"
    frContent .= "`n"
    frContent .= "[Tray]`n"
    frContent .= "search_song = Rechercher une chanson`n"
    frContent .= "playlist_manager = Liste de lecture`n"
    frContent .= "open_miniplayer = Ouvrir le mini-lecteur`n"
    frContent .= "auto_mode_on = Mode automatique [On]`n"
    frContent .= "auto_mode_off = Mode automatique [Off]`n"
    frContent .= "pause_resume = Pause / Reprendre`n"
    frContent .= "repeat_song = Répéter la chanson`n"
    frContent .= "change_music_folder = Changer le dossier de musique`n"
    frContent .= "change_vlc = Changer VLC.exe`n"
    frContent .= "assign_hotkeys = Attribuer des raccourcis`n"
    frContent .= "change_language = Changer de langue`n"
    frContent .= "return_normal_mode = Retour au mode normal`n"
    frContent .= "quit = Quitter`n"
    frContent .= "`n"
    frContent .= "[Hotkeys]`n"
    frContent .= "prev_song = Chanson précédente`n"
    frContent .= "next_song = Chanson suivante`n"
    frContent .= "search_song = Rechercher une chanson`n"
    frContent .= "pause_resume = Pause / Reprendre`n"
    frContent .= "repeat_song = Répéter la chanson`n"
    frContent .= "playlist = Liste de lecture`n"
    frContent .= "guide = Guide`n"
    frContent .= "update_hotkeys = Mettre à jour`n"
    frContent .= "hotkeys_updated = Raccourcis mis à jour avec succès.`n"
    frContent .= "invalid_hotkey = Le raccourci pour '{1}' n'est pas valide.``nCorrigez la valeur et réessayez.`n"
    frContent .= "guide_text = Format : Modificateur+Touche``n``nModificateurs valides :``n  Ctrl, Alt, Shift, Win``n``nExemples :``n  Ctrl+9``n  Alt+F1``n  Ctrl+Shift+P``n  Win+R``n``nVous pouvez aussi attribuer des touches seules``nbien que non recommandé (ex : F9).``n``nPour le pavé numérique : Ctrl+Numpad9``nPensez à activer Verr. Num.`n"
    frContent .= "`n"
    frContent .= "[Setup]`n"
    frContent .= "select_music_folder = Sélectionnez votre dossier de musique`n"
    frContent .= "must_select_folder = Vous devez sélectionner un dossier de musique pour continuer.`n"
    frContent .= "invalid_folder = Dossier invalide.`n"
    frContent .= "select_vlc = Sélectionnez le fichier vlc.exe`n"
    frContent .= "must_select_vlc = Vous devez sélectionner vlc.exe.`n"
    frContent .= "incorrect_file = Fichier incorrect.`n"
    frContent .= "music_folders_title = Dossiers de musique`n"
    frContent .= "music_folders_label = Dossiers de musique :`n"
    frContent .= "add_folder = + Ajouter`n"
    frContent .= "change_folder_btn = Modifier`n"
    frContent .= "remove_folder = Supprimer`n"
    frContent .= "select_music_folder_dir = Sélectionnez le dossier de musique`n"
    frContent .= "select_new_location = Sélectionnez le nouvel emplacement`n"
    frContent .= "must_keep_one_folder = Vous devez conserver au moins un dossier de musique.`n"
    frContent .= "add_folder_recursive = + Ajouter avec sous-dossiers`n"
    frContent .= "tray_tip_start = Magic Jukebox est ici, en arrière-plan`n"
    frContent .= "`n"
    frContent .= "[Search]`n"
    frContent .= "search_title = Rechercher une chanson`n"
    frContent .= "no_music_folder = Aucun dossier de musique désigné.``nConfigurez-le d'abord.`n"
    frContent .= "no_songs_found = Aucune chanson trouvée dans le dossier actuel.`n"
    frContent .= "`n"
    frContent .= "[Playlist]`n"
    frContent .= "playlist_title = Gestionnaire de playlists`n"
    frContent .= "reorder_title_playlists = Gestionnaire de playlists (Définition du nouvel ordre)`n"
    frContent .= "reorder_title_songs = Gestionnaire de playlists (Définition de l'ordre de {1})`n"
    frContent .= "search_song = Rechercher une chanson :`n"
    frContent .= "playlists = Playlists :`n"
    frContent .= "playlist_songs = Chansons de la playlist :`n"
    frContent .= "play = ▶ Lire`n"
    frContent .= "remove = ➖ Retirer`n"
    frContent .= "delete = 🗑 Supprimer`n"
    frContent .= "create_playlist = ➕ Créer une playlist`n"
    frContent .= "play_all = ▶ Lire toutes les playlists`n"
    frContent .= "loop_on = Boucle : ON`n"
    frContent .= "loop_off = Boucle : OFF`n"
    frContent .= "random_on = Aléatoire : ON`n"
    frContent .= "random_off = Aléatoire : OFF`n"
    frContent .= "reorder_instructions = Pour modifier l'ordre de lecture, double-cliquez sur une chanson ou une playlist.`n"
    frContent .= "reorder_playlists_instructions = Sélectionnez une playlist et utilisez ▲ ▼ pour la déplacer.`n"
    frContent .= "reorder_songs_instructions = Sélectionnez une chanson et utilisez ▲ ▼ pour la déplacer.`n"
    frContent .= "move_up = ▲ Monter`n"
    frContent .= "move_down = ▼ Descendre`n"
    frContent .= "exit_reorder = ✖ Quitter le mode édition`n"
    frContent .= "new_playlist_title = Créer une playlist`n"
    frContent .= "new_playlist_label = Nom de la nouvelle playlist :`n"
    frContent .= "create = Créer`n"
    frContent .= "cancel = Annuler`n"
    frContent .= "name_empty = Le nom ne peut pas être vide.`n"
    frContent .= "name_exists = Une playlist avec ce nom existe déjà.`n"
    frContent .= "confirm_delete = Êtes-vous sûr de vouloir supprimer cette playlist ?`n"
    frContent .= "confirm_delete_title = Confirmer`n"
    frContent .= "select_playlist_first = Sélectionnez ou créez une playlist d'abord.`n"
    frContent .= "`n"
    frContent .= "[MiniPlayer]`n"
    frContent .= "artist = Artiste`n"
    frContent .= "album = Album`n"
    frContent .= "title = Titre`n"
    frContent .= "`n"
    frContent .= "[Language]`n"
    frContent .= "language_title = Sélectionner la langue`n"
    frContent .= "`n"
    try FileDelete(langDir  "\fr-lang.ini")
    FileAppend(frContent, langDir "\fr-lang.ini", "UTF-8")

    ; ===== DE =====
    deContent := ""
    deContent .= "[General]`n"
    deContent .= "app_name = Magic Jukebox`n"
    deContent .= "playing = Wiedergabe:`n"
    deContent .= "`n"
    deContent .= "[Tray]`n"
    deContent .= "search_song = Lied suchen`n"
    deContent .= "playlist_manager = Wiedergabeliste`n"
    deContent .= "open_miniplayer = Miniplayer öffnen`n"
    deContent .= "auto_mode_on = Automatikmodus [Ein]`n"
    deContent .= "auto_mode_off = Automatikmodus [Aus]`n"
    deContent .= "pause_resume = Pause / Fortsetzen`n"
    deContent .= "repeat_song = Lied wiederholen`n"
    deContent .= "change_music_folder = Musikordner ändern`n"
    deContent .= "change_vlc = VLC.exe ändern`n"
    deContent .= "assign_hotkeys = Tastenkürzel zuweisen`n"
    deContent .= "change_language = Sprache ändern`n"
    deContent .= "return_normal_mode = Zum Normalmodus zurückkehren`n"
    deContent .= "quit = Beenden`n"
    deContent .= "`n"
    deContent .= "[Hotkeys]`n"
    deContent .= "prev_song = Vorheriges Lied`n"
    deContent .= "next_song = Nächstes Lied`n"
    deContent .= "search_song = Lied suchen`n"
    deContent .= "pause_resume = Pause / Fortsetzen`n"
    deContent .= "repeat_song = Lied wiederholen`n"
    deContent .= "playlist = Wiedergabeliste`n"
    deContent .= "guide = Anleitung`n"
    deContent .= "update_hotkeys = Aktualisieren`n"
    deContent .= "hotkeys_updated = Tastenkürzel erfolgreich aktualisiert.`n"
    deContent .= "invalid_hotkey = Das Tastenkürzel für '{1}' ist nicht gültig.``nKorrigieren Sie den Wert und versuchen Sie es erneut.`n"
    deContent .= "guide_text = Format: Modifikator+Taste``n``nGültige Modifikatoren:``n  Ctrl, Alt, Shift, Win``n``nBeispiele:``n  Ctrl+9``n  Alt+F1``n  Ctrl+Shift+P``n  Win+R``n``nSie können auch einzelne Tasten zuweisen,``nobwohl nicht empfohlen (z.B. F9).``n``nFür Numpad: Ctrl+Numpad9``nDenken Sie daran, Num Lock zu aktivieren.`n"
    deContent .= "`n"
    deContent .= "[Setup]`n"
    deContent .= "select_music_folder = Wählen Sie Ihren Musikordner`n"
    deContent .= "must_select_folder = Sie müssen einen Musikordner auswählen, um fortzufahren.`n"
    deContent .= "invalid_folder = Ungültiger Ordner.`n"
    deContent .= "select_vlc = Wählen Sie die vlc.exe-Datei`n"
    deContent .= "must_select_vlc = Sie müssen vlc.exe auswählen.`n"
    deContent .= "incorrect_file = Falsche Datei.`n"
    deContent .= "music_folders_title = Musikordner`n"
    deContent .= "music_folders_label = Musikordner:`n"
    deContent .= "add_folder = + Hinzufügen`n"
    deContent .= "change_folder_btn = Ändern`n"
    deContent .= "remove_folder = Entfernen`n"
    deContent .= "select_music_folder_dir = Musikordner auswählen`n"
    deContent .= "select_new_location = Neuen Speicherort auswählen`n"
    deContent .= "must_keep_one_folder = Sie müssen mindestens einen Musikordner behalten.`n"
    deContent .= "add_folder_recursive = + Mit Unterordnern hinzufügen`n"
    deContent .= "tray_tip_start = Magic Jukebox ist hier, im Hintergrund`n"
    deContent .= "`n"
    deContent .= "[Search]`n"
    deContent .= "search_title = Lied suchen`n"
    deContent .= "no_music_folder = Kein Musikordner festgelegt.``nBitte zuerst einrichten.`n"
    deContent .= "no_songs_found = Keine Lieder im aktuellen Ordner gefunden.`n"
    deContent .= "`n"
    deContent .= "[Playlist]`n"
    deContent .= "playlist_title = Wiedergabelisten-Manager`n"
    deContent .= "reorder_title_playlists = Wiedergabelisten-Manager (Neue Reihenfolge festlegen)`n"
    deContent .= "reorder_title_songs = Wiedergabelisten-Manager (Reihenfolge von {1} festlegen)`n"
    deContent .= "search_song = Lied suchen:`n"
    deContent .= "playlists = Wiedergabelisten:`n"
    deContent .= "playlist_songs = Lieder der Wiedergabeliste:`n"
    deContent .= "play = ▶ Abspielen`n"
    deContent .= "remove = ➖ Entfernen`n"
    deContent .= "delete = 🗑 Löschen`n"
    deContent .= "create_playlist = ➕ Wiedergabeliste erstellen`n"
    deContent .= "play_all = ▶ Alle Wiedergabelisten abspielen`n"
    deContent .= "loop_on = Schleife: EIN`n"
    deContent .= "loop_off = Schleife: AUS`n"
    deContent .= "random_on = Zufällig: EIN`n"
    deContent .= "random_off = Zufällig: AUS`n"
    deContent .= "reorder_instructions = Um die Wiedergabereihenfolge zu ändern, doppelklicken Sie auf ein Lied oder eine Wiedergabeliste.`n"
    deContent .= "reorder_playlists_instructions = Wählen Sie eine Wiedergabeliste und verwenden Sie ▲ ▼ zum Verschieben.`n"
    deContent .= "reorder_songs_instructions = Wählen Sie ein Lied und verwenden Sie ▲ ▼ zum Verschieben.`n"
    deContent .= "move_up = ▲ Nach oben`n"
    deContent .= "move_down = ▼ Nach unten`n"
    deContent .= "exit_reorder = ✖ Bearbeitungsmodus beenden`n"
    deContent .= "new_playlist_title = Wiedergabeliste erstellen`n"
    deContent .= "new_playlist_label = Name der neuen Wiedergabeliste:`n"
    deContent .= "create = Erstellen`n"
    deContent .= "cancel = Abbrechen`n"
    deContent .= "name_empty = Der Name darf nicht leer sein.`n"
    deContent .= "name_exists = Eine Wiedergabeliste mit diesem Namen existiert bereits.`n"
    deContent .= "confirm_delete = Möchten Sie diese Wiedergabeliste wirklich löschen?`n"
    deContent .= "confirm_delete_title = Bestätigen`n"
    deContent .= "select_playlist_first = Bitte wählen oder erstellen Sie zuerst eine Wiedergabeliste.`n"
    deContent .= "`n"
    deContent .= "[MiniPlayer]`n"
    deContent .= "artist = Künstler`n"
    deContent .= "album = Album`n"
    deContent .= "title = Titel`n"
    deContent .= "`n"
    deContent .= "[Language]`n"
    deContent .= "language_title = Sprache auswählen`n"
    deContent .= "`n"
    try FileDelete(langDir  "\de-lang.ini")
    FileAppend(deContent, langDir "\de-lang.ini", "UTF-8")

    ; ===== IT =====
    itContent := ""
    itContent .= "[General]`n"
    itContent .= "app_name = Magic Jukebox`n"
    itContent .= "playing = In riproduzione:`n"
    itContent .= "`n"
    itContent .= "[Tray]`n"
    itContent .= "search_song = Cerca brano`n"
    itContent .= "playlist_manager = Playlist`n"
    itContent .= "open_miniplayer = Apri mini-lettore`n"
    itContent .= "auto_mode_on = Modalità automatica [On]`n"
    itContent .= "auto_mode_off = Modalità automatica [Off]`n"
    itContent .= "pause_resume = Pausa / Riprendi`n"
    itContent .= "repeat_song = Ripeti brano`n"
    itContent .= "change_music_folder = Cambia cartella musica`n"
    itContent .= "change_vlc = Cambia VLC.exe`n"
    itContent .= "assign_hotkeys = Assegna scorciatoie`n"
    itContent .= "change_language = Cambia lingua`n"
    itContent .= "return_normal_mode = Torna alla modalità normale`n"
    itContent .= "quit = Esci`n"
    itContent .= "`n"
    itContent .= "[Hotkeys]`n"
    itContent .= "prev_song = Brano precedente`n"
    itContent .= "next_song = Brano successivo`n"
    itContent .= "search_song = Cerca brano`n"
    itContent .= "pause_resume = Pausa / Riprendi`n"
    itContent .= "repeat_song = Ripeti brano`n"
    itContent .= "playlist = Playlist`n"
    itContent .= "guide = Guida`n"
    itContent .= "update_hotkeys = Aggiorna scorciatoie`n"
    itContent .= "hotkeys_updated = Scorciatoie aggiornate con successo.`n"
    itContent .= "invalid_hotkey = La scorciatoia per '{1}' non è valida.``nCorreggi il valore e riprova.`n"
    itContent .= "guide_text = Formato: Modificatore+Tasto``n``nModificatori validi:``n  Ctrl, Alt, Shift, Win``n``nEsempi:``n  Ctrl+9``n  Alt+F1``n  Ctrl+Shift+P``n  Win+R``n``nPuoi anche assegnare tasti singoli``nanche se non consigliato (es. F9).``n``nPer Numpad: Ctrl+Numpad9``nRicordati di attivare Bloc Num.`n"
    itContent .= "`n"
    itContent .= "[Setup]`n"
    itContent .= "select_music_folder = Seleziona la cartella musica`n"
    itContent .= "must_select_folder = Devi selezionare una cartella musica per continuare.`n"
    itContent .= "invalid_folder = Cartella non valida.`n"
    itContent .= "select_vlc = Seleziona il file vlc.exe`n"
    itContent .= "must_select_vlc = Devi selezionare vlc.exe.`n"
    itContent .= "incorrect_file = File non corretto.`n"
    itContent .= "music_folders_title = Cartelle musicali`n"
    itContent .= "music_folders_label = Cartelle musicali:`n"
    itContent .= "add_folder = + Aggiungi`n"
    itContent .= "change_folder_btn = Modifica`n"
    itContent .= "remove_folder = Rimuovi`n"
    itContent .= "select_music_folder_dir = Seleziona la cartella musicale`n"
    itContent .= "select_new_location = Seleziona la nuova posizione`n"
    itContent .= "must_keep_one_folder = Devi mantenere almeno una cartella musicale.`n"
    itContent .= "add_folder_recursive = + Aggiungi con sottocartelle`n"
    itContent .= "tray_tip_start = Magic Jukebox è qui, in background`n"
    itContent .= "`n"
    itContent .= "[Search]`n"
    itContent .= "search_title = Cerca brano`n"
    itContent .= "no_music_folder = Nessuna cartella musica designata.``nConfigurala prima.`n"
    itContent .= "no_songs_found = Nessun brano trovato nella cartella attuale.`n"
    itContent .= "`n"
    itContent .= "[Playlist]`n"
    itContent .= "playlist_title = Gestore Playlist`n"
    itContent .= "reorder_title_playlists = Gestore Playlist (Impostazione nuovo ordine)`n"
    itContent .= "reorder_title_songs = Gestore Playlist (Impostazione ordine di {1})`n"
    itContent .= "search_song = Cerca brano:`n"
    itContent .= "playlists = Playlist:`n"
    itContent .= "playlist_songs = Brani della playlist:`n"
    itContent .= "play = ▶ Riproduci`n"
    itContent .= "remove = ➖ Rimuovi`n"
    itContent .= "delete = 🗑 Elimina`n"
    itContent .= "create_playlist = ➕ Crea playlist`n"
    itContent .= "play_all = ▶ Riproduci tutte le playlist`n"
    itContent .= "loop_on = Loop: ON`n"
    itContent .= "loop_off = Loop: OFF`n"
    itContent .= "random_on = Casuale: ON`n"
    itContent .= "random_off = Casuale: OFF`n"
    itContent .= "reorder_instructions = Per cambiare l'ordine di riproduzione, fai doppio clic su un brano o una playlist.`n"
    itContent .= "reorder_playlists_instructions = Seleziona una playlist e usa ▲ ▼ per spostarla.`n"
    itContent .= "reorder_songs_instructions = Seleziona un brano e usa ▲ ▼ per spostarlo.`n"
    itContent .= "move_up = ▲ Su`n"
    itContent .= "move_down = ▼ Giù`n"
    itContent .= "exit_reorder = ✖ Esci dalla modalità modifica`n"
    itContent .= "new_playlist_title = Crea playlist`n"
    itContent .= "new_playlist_label = Nome della nuova playlist:`n"
    itContent .= "create = Crea`n"
    itContent .= "cancel = Annulla`n"
    itContent .= "name_empty = Il nome non può essere vuoto.`n"
    itContent .= "name_exists = Esiste già una playlist con questo nome.`n"
    itContent .= "confirm_delete = Sei sicuro di voler eliminare questa playlist?`n"
    itContent .= "confirm_delete_title = Conferma`n"
    itContent .= "select_playlist_first = Seleziona o crea prima una playlist.`n"
    itContent .= "`n"
    itContent .= "[MiniPlayer]`n"
    itContent .= "artist = Artista`n"
    itContent .= "album = Album`n"
    itContent .= "title = Titolo`n"
    itContent .= "`n"
    itContent .= "[Language]`n"
    itContent .= "language_title = Seleziona lingua`n"
    itContent .= "`n"
    try FileDelete(langDir  "\it-lang.ini")
    FileAppend(itContent, langDir "\it-lang.ini", "UTF-8")

    ; ===== NL =====
    nlContent := ""
    nlContent .= "[General]`n"
    nlContent .= "app_name = Magic Jukebox`n"
    nlContent .= "playing = Afspelen:`n"
    nlContent .= "`n"
    nlContent .= "[Tray]`n"
    nlContent .= "search_song = Nummer zoeken`n"
    nlContent .= "playlist_manager = Afspeellijst`n"
    nlContent .= "open_miniplayer = Minispeler openen`n"
    nlContent .= "auto_mode_on = Automatische modus [Aan]`n"
    nlContent .= "auto_mode_off = Automatische modus [Uit]`n"
    nlContent .= "pause_resume = Pauzeren / Hervatten`n"
    nlContent .= "repeat_song = Nummer herhalen`n"
    nlContent .= "change_music_folder = Muziekmap wijzigen`n"
    nlContent .= "change_vlc = VLC.exe wijzigen`n"
    nlContent .= "assign_hotkeys = Sneltoetsen toewijzen`n"
    nlContent .= "change_language = Taal wijzigen`n"
    nlContent .= "return_normal_mode = Terug naar normale modus`n"
    nlContent .= "quit = Afsluiten`n"
    nlContent .= "`n"
    nlContent .= "[Hotkeys]`n"
    nlContent .= "prev_song = Vorig nummer`n"
    nlContent .= "next_song = Volgend nummer`n"
    nlContent .= "search_song = Nummer zoeken`n"
    nlContent .= "pause_resume = Pauzeren / Hervatten`n"
    nlContent .= "repeat_song = Nummer herhalen`n"
    nlContent .= "playlist = Afspeellijst`n"
    nlContent .= "guide = Gids`n"
    nlContent .= "update_hotkeys = Sneltoetsen bijwerken`n"
    nlContent .= "hotkeys_updated = Sneltoetsen succesvol bijgewerkt.`n"
    nlContent .= "invalid_hotkey = De sneltoets voor '{1}' is niet geldig.``nCorrigeer de waarde en probeer opnieuw.`n"
    nlContent .= "guide_text = Formaat: Modifier+Toets``n``nGeldige modifiers:``n  Ctrl, Alt, Shift, Win``n``nVoorbeelden:``n  Ctrl+9``n  Alt+F1``n  Ctrl+Shift+P``n  Win+R``n``nU kunt ook afzonderlijke toetsen toewijzen``nhoewel niet aanbevolen (bijv. F9).``n``nVoor Numpad: Ctrl+Numpad9``nVergeet niet Num Lock in te schakelen.`n"
    nlContent .= "`n"
    nlContent .= "[Setup]`n"
    nlContent .= "select_music_folder = Selecteer uw muziekmap`n"
    nlContent .= "must_select_folder = U moet een muziekmap selecteren om door te gaan.`n"
    nlContent .= "invalid_folder = Ongeldige map.`n"
    nlContent .= "select_vlc = Selecteer het vlc.exe-bestand`n"
    nlContent .= "must_select_vlc = U moet vlc.exe selecteren.`n"
    nlContent .= "incorrect_file = Onjuist bestand.`n"
    nlContent .= "music_folders_title = Muziekmappen`n"
    nlContent .= "music_folders_label = Muziekmappen:`n"
    nlContent .= "add_folder = + Toevoegen`n"
    nlContent .= "change_folder_btn = Wijzigen`n"
    nlContent .= "remove_folder = Wissen`n"
    nlContent .= "select_music_folder_dir = Selecteer muziekmap`n"
    nlContent .= "select_new_location = Selecteer nieuwe locatie`n"
    nlContent .= "must_keep_one_folder = U moet minimaal één muziekmap behouden.`n"
    nlContent .= "add_folder_recursive = + Toevoegen met submappen`n"
    nlContent .= "tray_tip_start = Magic Jukebox is hier, op de achtergrond`n"
    nlContent .= "`n"
    nlContent .= "[Search]`n"
    nlContent .= "search_title = Nummer zoeken`n"
    nlContent .= "no_music_folder = Geen muziekmap aangewezen.``nStel deze eerst in.`n"
    nlContent .= "no_songs_found = Geen nummers gevonden in de huidige map.`n"
    nlContent .= "`n"
    nlContent .= "[Playlist]`n"
    nlContent .= "playlist_title = Afspeellijstbeheer`n"
    nlContent .= "reorder_title_playlists = Afspeellijstbeheer (Nieuwe volgorde instellen)`n"
    nlContent .= "reorder_title_songs = Afspeellijstbeheer (Volgorde van {1} instellen)`n"
    nlContent .= "search_song = Nummer zoeken:`n"
    nlContent .= "playlists = Afspeellijsten:`n"
    nlContent .= "playlist_songs = Nummers in afspeellijst:`n"
    nlContent .= "play = ▶ Afspelen`n"
    nlContent .= "remove = ➖ Verwijderen`n"
    nlContent .= "delete = 🗑 Wissen`n"
    nlContent .= "create_playlist = ➕ Afspeellijst maken`n"
    nlContent .= "play_all = ▶ Alle afspeellijsten afspelen`n"
    nlContent .= "loop_on = Herhalen: AAN`n"
    nlContent .= "loop_off = Herhalen: UIT`n"
    nlContent .= "random_on = Willekeurig: AAN`n"
    nlContent .= "random_off = Willekeurig: UIT`n"
    nlContent .= "reorder_instructions = Dubbelklik op een nummer of afspeellijst om de volgorde te wijzigen.`n"
    nlContent .= "reorder_playlists_instructions = Selecteer een afspeellijst en gebruik ▲ ▼ om deze te verplaatsen.`n"
    nlContent .= "reorder_songs_instructions = Selecteer een nummer en gebruik ▲ ▼ om het te verplaatsen.`n"
    nlContent .= "move_up = ▲ Omhoog`n"
    nlContent .= "move_down = ▼ Omlaag`n"
    nlContent .= "exit_reorder = ✖ Bewerkingsmodus verlaten`n"
    nlContent .= "new_playlist_title = Afspeellijst maken`n"
    nlContent .= "new_playlist_label = Naam van de nieuwe afspeellijst:`n"
    nlContent .= "create = Maken`n"
    nlContent .= "cancel = Annuleren`n"
    nlContent .= "name_empty = De naam mag niet leeg zijn.`n"
    nlContent .= "name_exists = Er bestaat al een afspeellijst met die naam.`n"
    nlContent .= "confirm_delete = Weet u zeker dat u deze afspeellijst wilt verwijderen?`n"
    nlContent .= "confirm_delete_title = Bevestigen`n"
    nlContent .= "select_playlist_first = Selecteer of maak eerst een afspeellijst.`n"
    nlContent .= "`n"
    nlContent .= "[MiniPlayer]`n"
    nlContent .= "artist = Artiest`n"
    nlContent .= "album = Album`n"
    nlContent .= "title = Titel`n"
    nlContent .= "`n"
    nlContent .= "[Language]`n"
    nlContent .= "language_title = Taal selecteren`n"
    nlContent .= "`n"
    try FileDelete(langDir  "\nl-lang.ini")
    FileAppend(nlContent, langDir "\nl-lang.ini", "UTF-8")

    ; ===== PL =====
    plContent := ""
    plContent .= "[General]`n"
    plContent .= "app_name = Magic Jukebox`n"
    plContent .= "playing = Odtwarzanie:`n"
    plContent .= "`n"
    plContent .= "[Tray]`n"
    plContent .= "search_song = Szukaj utworu`n"
    plContent .= "playlist_manager = Lista odtwarzania`n"
    plContent .= "open_miniplayer = Otwórz miniplayer`n"
    plContent .= "auto_mode_on = Tryb automatyczny [Wł]`n"
    plContent .= "auto_mode_off = Tryb automatyczny [Wył]`n"
    plContent .= "pause_resume = Pauza / Wznów`n"
    plContent .= "repeat_song = Powtórz utwór`n"
    plContent .= "change_music_folder = Zmień folder muzyki`n"
    plContent .= "change_vlc = Zmień VLC.exe`n"
    plContent .= "assign_hotkeys = Przypisz skróty`n"
    plContent .= "change_language = Zmień język`n"
    plContent .= "return_normal_mode = Powróć do trybu normalnego`n"
    plContent .= "quit = Wyjdź`n"
    plContent .= "`n"
    plContent .= "[Hotkeys]`n"
    plContent .= "prev_song = Poprzedni utwór`n"
    plContent .= "next_song = Następny utwór`n"
    plContent .= "search_song = Szukaj utworu`n"
    plContent .= "pause_resume = Pauza / Wznów`n"
    plContent .= "repeat_song = Powtórz utwór`n"
    plContent .= "playlist = Lista odtwarzania`n"
    plContent .= "guide = Przewodnik`n"
    plContent .= "update_hotkeys = Zaktualizuj skróty`n"
    plContent .= "hotkeys_updated = Skróty zostały pomyślnie zaktualizowane.`n"
    plContent .= "invalid_hotkey = Skrót dla '{1}' jest nieprawidłowy.``nPopraw wartość i spróbuj ponownie.`n"
    plContent .= "guide_text = Format: Modyfikator+Klawisz``n``nPoprawne modyfikatory:``n  Ctrl, Alt, Shift, Win``n``nPrzykłady:``n  Ctrl+9``n  Alt+F1``n  Ctrl+Shift+P``n  Win+R``n``nMożna też przypisać pojedyncze klawisze``nchociaż nie jest to zalecane (np. F9).``n``nDla Numpad: Ctrl+Numpad9``nPamiętaj o włączeniu Num Lock.`n"
    plContent .= "`n"
    plContent .= "[Setup]`n"
    plContent .= "select_music_folder = Wybierz folder muzyki`n"
    plContent .= "must_select_folder = Musisz wybrać folder muzyki, aby kontynuować.`n"
    plContent .= "invalid_folder = Nieprawidłowy folder.`n"
    plContent .= "select_vlc = Wybierz plik vlc.exe`n"
    plContent .= "must_select_vlc = Musisz wybrać vlc.exe.`n"
    plContent .= "incorrect_file = Nieprawidłowy plik.`n"
    plContent .= "music_folders_title = Foldery muzyczne`n"
    plContent .= "music_folders_label = Foldery muzyczne:`n"
    plContent .= "add_folder = + Dodaj`n"
    plContent .= "change_folder_btn = Zmień`n"
    plContent .= "remove_folder = Usuń`n"
    plContent .= "select_music_folder_dir = Wybierz folder muzyczny`n"
    plContent .= "select_new_location = Wybierz nową lokalizację`n"
    plContent .= "must_keep_one_folder = Musisz zachować co najmniej jeden folder muzyczny.`n"
    plContent .= "add_folder_recursive = + Dodaj z podfolderami`n"
    plContent .= "tray_tip_start = Magic Jukebox jest tutaj, w tle`n"
    plContent .= "`n"
    plContent .= "[Search]`n"
    plContent .= "search_title = Szukaj utworu`n"
    plContent .= "no_music_folder = Nie wyznaczono folderu muzyki.``nSkonfiguruj go najpierw.`n"
    plContent .= "no_songs_found = Nie znaleziono utworów w bieżącym folderze.`n"
    plContent .= "`n"
    plContent .= "[Playlist]`n"
    plContent .= "playlist_title = Menedżer list odtwarzania`n"
    plContent .= "reorder_title_playlists = Menedżer list odtwarzania (Ustawianie nowej kolejności)`n"
    plContent .= "reorder_title_songs = Menedżer list odtwarzania (Ustawianie kolejności {1})`n"
    plContent .= "search_song = Szukaj utworu:`n"
    plContent .= "playlists = Listy odtwarzania:`n"
    plContent .= "playlist_songs = Utwory na liście:`n"
    plContent .= "play = ▶ Odtwórz`n"
    plContent .= "remove = ➖ Usuń`n"
    plContent .= "delete = 🗑 Skasuj`n"
    plContent .= "create_playlist = ➕ Utwórz listę odtwarzania`n"
    plContent .= "play_all = ▶ Odtwórz wszystkie listy`n"
    plContent .= "loop_on = Pętla: WŁ`n"
    plContent .= "loop_off = Pętla: WYŁ`n"
    plContent .= "random_on = Losowo: WŁ`n"
    plContent .= "random_off = Losowo: WYŁ`n"
    plContent .= "reorder_instructions = Aby zmienić kolejność odtwarzania, kliknij dwukrotnie utwór lub listę.`n"
    plContent .= "reorder_playlists_instructions = Wybierz listę i użyj ▲ ▼ aby ją przenieść.`n"
    plContent .= "reorder_songs_instructions = Wybierz utwór i użyj ▲ ▼ aby go przenieść.`n"
    plContent .= "move_up = ▲ W górę`n"
    plContent .= "move_down = ▼ W dół`n"
    plContent .= "exit_reorder = ✖ Wyjdź z trybu edycji`n"
    plContent .= "new_playlist_title = Utwórz listę odtwarzania`n"
    plContent .= "new_playlist_label = Nazwa nowej listy:`n"
    plContent .= "create = Utwórz`n"
    plContent .= "cancel = Anuluj`n"
    plContent .= "name_empty = Nazwa nie może być pusta.`n"
    plContent .= "name_exists = Lista o tej nazwie już istnieje.`n"
    plContent .= "confirm_delete = Czy na pewno chcesz usunąć tę listę odtwarzania?`n"
    plContent .= "confirm_delete_title = Potwierdź`n"
    plContent .= "select_playlist_first = Najpierw wybierz lub utwórz listę odtwarzania.`n"
    plContent .= "`n"
    plContent .= "[MiniPlayer]`n"
    plContent .= "artist = Artysta`n"
    plContent .= "album = Album`n"
    plContent .= "title = Tytuł`n"
    plContent .= "`n"
    plContent .= "[Language]`n"
    plContent .= "language_title = Wybierz język`n"
    plContent .= "`n"
    try FileDelete(langDir  "\pl-lang.ini")
    FileAppend(plContent, langDir "\pl-lang.ini", "UTF-8")

    ; ===== RU =====
    ruContent := ""
    ruContent .= "[General]`n"
    ruContent .= "app_name = Magic Jukebox`n"
    ruContent .= "playing = Воспроизведение:`n"
    ruContent .= "`n"
    ruContent .= "[Tray]`n"
    ruContent .= "search_song = Найти песню`n"
    ruContent .= "playlist_manager = Список воспроизведения`n"
    ruContent .= "open_miniplayer = Открыть мини-плеер`n"
    ruContent .= "auto_mode_on = Автоматический режим [Вкл]`n"
    ruContent .= "auto_mode_off = Автоматический режим [Выкл]`n"
    ruContent .= "pause_resume = Пауза / Продолжить`n"
    ruContent .= "repeat_song = Повторить песню`n"
    ruContent .= "change_music_folder = Изменить папку музыки`n"
    ruContent .= "change_vlc = Изменить VLC.exe`n"
    ruContent .= "assign_hotkeys = Назначить горячие клавиши`n"
    ruContent .= "change_language = Изменить язык`n"
    ruContent .= "return_normal_mode = Вернуться в обычный режим`n"
    ruContent .= "quit = Выход`n"
    ruContent .= "`n"
    ruContent .= "[Hotkeys]`n"
    ruContent .= "prev_song = Предыдущая песня`n"
    ruContent .= "next_song = Следующая песня`n"
    ruContent .= "search_song = Найти песню`n"
    ruContent .= "pause_resume = Пауза / Продолжить`n"
    ruContent .= "repeat_song = Повторить песню`n"
    ruContent .= "playlist = Список воспроизведения`n"
    ruContent .= "guide = Руководство`n"
    ruContent .= "update_hotkeys = Обновить`n"
    ruContent .= "hotkeys_updated = Горячие клавиши успешно обновлены.`n"
    ruContent .= "invalid_hotkey = Горячая клавиша для '{1}' недействительна.``nИсправьте значение и попробуйте снова.`n"
    ruContent .= "guide_text = Формат: Модификатор+Клавиша``n``nДопустимые модификаторы:``n  Ctrl, Alt, Shift, Win``n``nПримеры:``n  Ctrl+9``n  Alt+F1``n  Ctrl+Shift+P``n  Win+R``n``nМожно также назначить одиночные клавиши,``nхотя это не рекомендуется (напр. F9).``n``nДля цифрового блока: Ctrl+Numpad9``nНе забудьте включить Num Lock.`n"
    ruContent .= "`n"
    ruContent .= "[Setup]`n"
    ruContent .= "select_music_folder = Выберите папку с музыкой`n"
    ruContent .= "must_select_folder = Необходимо выбрать папку с музыкой для продолжения.`n"
    ruContent .= "invalid_folder = Недействительная папка.`n"
    ruContent .= "select_vlc = Выберите файл vlc.exe`n"
    ruContent .= "must_select_vlc = Необходимо выбрать vlc.exe.`n"
    ruContent .= "incorrect_file = Неверный файл.`n"
    ruContent .= "music_folders_title = Папки с музыкой`n"
    ruContent .= "music_folders_label = Папки с музыкой:`n"
    ruContent .= "add_folder = + Добавить`n"
    ruContent .= "change_folder_btn = Изменить`n"
    ruContent .= "remove_folder = Удалить`n"
    ruContent .= "select_music_folder_dir = Выберите папку с музыкой`n"
    ruContent .= "select_new_location = Выберите новое расположение`n"
    ruContent .= "must_keep_one_folder = Необходимо сохранить хотя бы одну папку с музыкой.`n"
    ruContent .= "add_folder_recursive = + Добавить с подпапками`n"
    ruContent .= "tray_tip_start = Magic Jukebox здесь, в фоновом режиме`n"
    ruContent .= "`n"
    ruContent .= "[Search]`n"
    ruContent .= "search_title = Найти песню`n"
    ruContent .= "no_music_folder = Папка с музыкой не назначена.``nСначала настройте её.`n"
    ruContent .= "no_songs_found = Песни в текущей папке не найдены.`n"
    ruContent .= "`n"
    ruContent .= "[Playlist]`n"
    ruContent .= "playlist_title = Менеджер плейлистов`n"
    ruContent .= "reorder_title_playlists = Менеджер плейлистов (Установка нового порядка)`n"
    ruContent .= "reorder_title_songs = Менеджер плейлистов (Установка порядка {1})`n"
    ruContent .= "search_song = Найти песню:`n"
    ruContent .= "playlists = Плейлисты:`n"
    ruContent .= "playlist_songs = Песни плейлиста:`n"
    ruContent .= "play = ▶ Играть`n"
    ruContent .= "remove = ➖ Удалить`n"
    ruContent .= "delete = 🗑 Стереть`n"
    ruContent .= "create_playlist = ➕ Создать плейлист`n"
    ruContent .= "play_all = ▶ Воспроизвести все плейлисты`n"
    ruContent .= "loop_on = Повтор: ВКЛ`n"
    ruContent .= "loop_off = Повтор: ВЫКЛ`n"
    ruContent .= "random_on = Случайно: ВКЛ`n"
    ruContent .= "random_off = Случайно: ВЫКЛ`n"
    ruContent .= "reorder_instructions = Для изменения порядка воспроизведения дважды щёлкните песню или плейлист.`n"
    ruContent .= "reorder_playlists_instructions = Выберите плейлист и используйте ▲ ▼ для перемещения.`n"
    ruContent .= "reorder_songs_instructions = Выберите песню и используйте ▲ ▼ для перемещения.`n"
    ruContent .= "move_up = ▲ Вверх`n"
    ruContent .= "move_down = ▼ Вниз`n"
    ruContent .= "exit_reorder = ✖ Выйти из режима редактирования`n"
    ruContent .= "new_playlist_title = Создать плейлист`n"
    ruContent .= "new_playlist_label = Название нового плейлиста:`n"
    ruContent .= "create = Создать`n"
    ruContent .= "cancel = Отмена`n"
    ruContent .= "name_empty = Название не может быть пустым.`n"
    ruContent .= "name_exists = Плейлист с таким названием уже существует.`n"
    ruContent .= "confirm_delete = Вы уверены, что хотите удалить этот плейлист?`n"
    ruContent .= "confirm_delete_title = Подтвердить`n"
    ruContent .= "select_playlist_first = Сначала выберите или создайте плейлист.`n"
    ruContent .= "`n"
    ruContent .= "[MiniPlayer]`n"
    ruContent .= "artist = Исполнитель`n"
    ruContent .= "album = Альбом`n"
    ruContent .= "title = Название`n"
    ruContent .= "`n"
    ruContent .= "[Language]`n"
    ruContent .= "language_title = Выбор языка`n"
    ruContent .= "`n"
    try FileDelete(langDir  "\ru-lang.ini")
    FileAppend(ruContent, langDir "\ru-lang.ini", "UTF-8")

    ; ===== TR =====
    trContent := ""
    trContent .= "[General]`n"
    trContent .= "app_name = Magic Jukebox`n"
    trContent .= "playing = Oynatılıyor:`n"
    trContent .= "`n"
    trContent .= "[Tray]`n"
    trContent .= "search_song = Şarkı ara`n"
    trContent .= "playlist_manager = Çalma listesi`n"
    trContent .= "open_miniplayer = Mini oynatıcıyı aç`n"
    trContent .= "auto_mode_on = Otomatik mod [Açık]`n"
    trContent .= "auto_mode_off = Otomatik mod [Kapalı]`n"
    trContent .= "pause_resume = Duraklat / Devam et`n"
    trContent .= "repeat_song = Şarkıyı tekrarla`n"
    trContent .= "change_music_folder = Müzik klasörünü değiştir`n"
    trContent .= "change_vlc = VLC.exe değiştir`n"
    trContent .= "assign_hotkeys = Kısayol tuşu ata`n"
    trContent .= "change_language = Dili değiştir`n"
    trContent .= "return_normal_mode = Normal moda dön`n"
    trContent .= "quit = Çıkış`n"
    trContent .= "`n"
    trContent .= "[Hotkeys]`n"
    trContent .= "prev_song = Önceki şarkı`n"
    trContent .= "next_song = Sonraki şarkı`n"
    trContent .= "search_song = Şarkı ara`n"
    trContent .= "pause_resume = Duraklat / Devam et`n"
    trContent .= "repeat_song = Şarkıyı tekrarla`n"
    trContent .= "playlist = Çalma listesi`n"
    trContent .= "guide = Rehber`n"
    trContent .= "update_hotkeys = Kısayolları güncelle`n"
    trContent .= "hotkeys_updated = Kısayollar başarıyla güncellendi.`n"
    trContent .= "invalid_hotkey = '{1}' için kısayol geçerli değil.``nDeğeri düzeltin ve tekrar deneyin.`n"
    trContent .= "guide_text = Format: Değiştirici+Tuş``n``nGeçerli değiştiriciler:``n  Ctrl, Alt, Shift, Win``n``nÖrnekler:``n  Ctrl+9``n  Alt+F1``n  Ctrl+Shift+P``n  Win+R``n``nTek tuş da atayabilirsiniz``nancak önerilmez (ör. F9).``n``nNumpad için: Ctrl+Numpad9``nNumpad kullanıyorsanız Num Lock'u açmayı unutmayın.`n"
    trContent .= "`n"
    trContent .= "[Setup]`n"
    trContent .= "select_music_folder = Müzik klasörünüzü seçin`n"
    trContent .= "must_select_folder = Devam etmek için bir müzik klasörü seçmelisiniz.`n"
    trContent .= "invalid_folder = Geçersiz klasör.`n"
    trContent .= "select_vlc = vlc.exe dosyasını seçin`n"
    trContent .= "must_select_vlc = vlc.exe'yi seçmelisiniz.`n"
    trContent .= "incorrect_file = Yanlış dosya.`n"
    trContent .= "music_folders_title = Müzik Klasörleri`n"
    trContent .= "music_folders_label = Müzik klasörleri:`n"
    trContent .= "add_folder = + Ekle`n"
    trContent .= "change_folder_btn = Değiştir`n"
    trContent .= "remove_folder = Kaldır`n"
    trContent .= "select_music_folder_dir = Müzik klasörünü seçin`n"
    trContent .= "select_new_location = Yeni konumu seçin`n"
    trContent .= "must_keep_one_folder = En az bir müzik klasörü tutmalısınız.`n"
    trContent .= "add_folder_recursive = + Alt klasörlerle ekle`n"
    trContent .= "tray_tip_start = Magic Jukebox burada, arka planda`n"
    trContent .= "`n"
    trContent .= "[Search]`n"
    trContent .= "search_title = Şarkı ara`n"
    trContent .= "no_music_folder = Müzik klasörü belirlenmedi.``nÖnce ayarlayın.`n"
    trContent .= "no_songs_found = Mevcut klasörde şarkı bulunamadı.`n"
    trContent .= "`n"
    trContent .= "[Playlist]`n"
    trContent .= "playlist_title = Çalma Listesi Yöneticisi`n"
    trContent .= "reorder_title_playlists = Çalma Listesi Yöneticisi (Yeni sıra belirleniyor)`n"
    trContent .= "reorder_title_songs = Çalma Listesi Yöneticisi ({1} sırası belirleniyor)`n"
    trContent .= "search_song = Şarkı ara:`n"
    trContent .= "playlists = Çalma listeleri:`n"
    trContent .= "playlist_songs = Çalma listesindeki şarkılar:`n"
    trContent .= "play = ▶ Oynat`n"
    trContent .= "remove = ➖ Kaldır`n"
    trContent .= "delete = 🗑 Sil`n"
    trContent .= "create_playlist = ➕ Çalma listesi oluştur`n"
    trContent .= "play_all = ▶ Tüm çalma listelerini oynat`n"
    trContent .= "loop_on = Döngü: AÇIK`n"
    trContent .= "loop_off = Döngü: KAPALI`n"
    trContent .= "random_on = Rastgele: AÇIK`n"
    trContent .= "random_off = Rastgele: KAPALI`n"
    trContent .= "reorder_instructions = Oynatma sırasını değiştirmek için bir şarkıya veya listeye çift tıklayın.`n"
    trContent .= "reorder_playlists_instructions = Bir çalma listesi seçin ve ▲ ▼ ile taşıyın.`n"
    trContent .= "reorder_songs_instructions = Bir şarkı seçin ve ▲ ▼ ile taşıyın.`n"
    trContent .= "move_up = ▲ Yukarı`n"
    trContent .= "move_down = ▼ Aşağı`n"
    trContent .= "exit_reorder = ✖ Düzenleme modundan çık`n"
    trContent .= "new_playlist_title = Çalma listesi oluştur`n"
    trContent .= "new_playlist_label = Yeni çalma listesinin adı:`n"
    trContent .= "create = Oluştur`n"
    trContent .= "cancel = İptal`n"
    trContent .= "name_empty = Ad boş olamaz.`n"
    trContent .= "name_exists = Bu adda bir çalma listesi zaten var.`n"
    trContent .= "confirm_delete = Bu çalma listesini silmek istediğinizden emin misiniz?`n"
    trContent .= "confirm_delete_title = Onayla`n"
    trContent .= "select_playlist_first = Önce bir çalma listesi seçin veya oluşturun.`n"
    trContent .= "`n"
    trContent .= "[MiniPlayer]`n"
    trContent .= "artist = Sanatçı`n"
    trContent .= "album = Albüm`n"
    trContent .= "title = Başlık`n"
    trContent .= "`n"
    trContent .= "[Language]`n"
    trContent .= "language_title = Dil seçin`n"
    trContent .= "`n"
    try FileDelete(langDir  "\tr-lang.ini")
    FileAppend(trContent, langDir "\tr-lang.ini", "UTF-8")

    ; ===== JA =====
    jaContent := ""
    jaContent .= "[General]`n"
    jaContent .= "app_name = Magic Jukebox`n"
    jaContent .= "playing = 再生中：`n"
    jaContent .= "`n"
    jaContent .= "[Tray]`n"
    jaContent .= "search_song = 曲を検索`n"
    jaContent .= "playlist_manager = プレイリスト`n"
    jaContent .= "open_miniplayer = ミニプレーヤーを開く`n"
    jaContent .= "auto_mode_on = 自動モード [オン]`n"
    jaContent .= "auto_mode_off = 自動モード [オフ]`n"
    jaContent .= "pause_resume = 一時停止 / 再開`n"
    jaContent .= "repeat_song = 曲を繰り返す`n"
    jaContent .= "change_music_folder = 音楽フォルダを変更`n"
    jaContent .= "change_vlc = VLC.exeを変更`n"
    jaContent .= "assign_hotkeys = ホットキーを設定`n"
    jaContent .= "change_language = 言語を変更`n"
    jaContent .= "return_normal_mode = 通常モードに戻る`n"
    jaContent .= "quit = 終了`n"
    jaContent .= "`n"
    jaContent .= "[Hotkeys]`n"
    jaContent .= "prev_song = 前の曲`n"
    jaContent .= "next_song = 次の曲`n"
    jaContent .= "search_song = 曲を検索`n"
    jaContent .= "pause_resume = 一時停止 / 再開`n"
    jaContent .= "repeat_song = 曲を繰り返す`n"
    jaContent .= "playlist = プレイリスト`n"
    jaContent .= "guide = ガイド`n"
    jaContent .= "update_hotkeys = ホットキーを更新`n"
    jaContent .= "hotkeys_updated = ホットキーが正常に更新されました。`n"
    jaContent .= "invalid_hotkey = '{1}'のホットキーが無効です。``n値を修正して再試行してください。`n"
    jaContent .= "guide_text = 形式：修飾キー+キー``n``n有効な修飾キー：``n  Ctrl, Alt, Shift, Win``n``n例：``n  Ctrl+9``n  Alt+F1``n  Ctrl+Shift+P``n  Win+R``n``n単独キーも設定できますが推奨しません（例：F9）。``n``nNumpadの場合：Ctrl+Numpad9``nNumpadを使用する場合はNum Lockを有効にしてください。`n"
    jaContent .= "`n"
    jaContent .= "[Setup]`n"
    jaContent .= "select_music_folder = 音楽フォルダを選択してください`n"
    jaContent .= "must_select_folder = 続行するには音楽フォルダを選択してください。`n"
    jaContent .= "invalid_folder = 無効なフォルダです。`n"
    jaContent .= "select_vlc = vlc.exeファイルを選択してください`n"
    jaContent .= "must_select_vlc = vlc.exeを選択してください。`n"
    jaContent .= "incorrect_file = 不正なファイルです。`n"
    jaContent .= "music_folders_title = 音楽フォルダ`n"
    jaContent .= "music_folders_label = 音楽フォルダ：`n"
    jaContent .= "add_folder = + 追加`n"
    jaContent .= "change_folder_btn = 変更`n"
    jaContent .= "remove_folder = 削除`n"
    jaContent .= "select_music_folder_dir = 音楽フォルダを選択してください`n"
    jaContent .= "select_new_location = 新しい場所を選択してください`n"
    jaContent .= "must_keep_one_folder = 少なくとも1つの音楽フォルダを保持する必要があります。`n"
    jaContent .= "add_folder_recursive = + サブフォルダを含めて追加`n"
    jaContent .= "tray_tip_start = Magic Jukebox はここにいます（バックグラウンド起動中）`n"
    jaContent .= "`n"
    jaContent .= "[Search]`n"
    jaContent .= "search_title = 曲を検索`n"
    jaContent .= "no_music_folder = 音楽フォルダが指定されていません。``n最初に設定してください。`n"
    jaContent .= "no_songs_found = 現在のフォルダに曲が見つかりません。`n"
    jaContent .= "`n"
    jaContent .= "[Playlist]`n"
    jaContent .= "playlist_title = プレイリストマネージャー`n"
    jaContent .= "reorder_title_playlists = プレイリストマネージャー（新しい順序を設定中）`n"
    jaContent .= "reorder_title_songs = プレイリストマネージャー（{1}の順序を設定中）`n"
    jaContent .= "search_song = 曲を検索：`n"
    jaContent .= "playlists = プレイリスト：`n"
    jaContent .= "playlist_songs = プレイリストの曲：`n"
    jaContent .= "play = ▶ 再生`n"
    jaContent .= "remove = ➖ 削除`n"
    jaContent .= "delete = 🗑 消去`n"
    jaContent .= "create_playlist = ➕ プレイリストを作成`n"
    jaContent .= "play_all = ▶ すべてのプレイリストを再生`n"
    jaContent .= "loop_on = ループ：オン`n"
    jaContent .= "loop_off = ループ：オフ`n"
    jaContent .= "random_on = シャッフル：オン`n"
    jaContent .= "random_off = シャッフル：オフ`n"
    jaContent .= "reorder_instructions = 再生順序を変更するには、曲またはプレイリストをダブルクリックしてください。`n"
    jaContent .= "reorder_playlists_instructions = プレイリストを選択して ▲ ▼ で移動してください。`n"
    jaContent .= "reorder_songs_instructions = 曲を選択して ▲ ▼ で移動してください。`n"
    jaContent .= "move_up = ▲ 上へ`n"
    jaContent .= "move_down = ▼ 下へ`n"
    jaContent .= "exit_reorder = ✖ 編集モードを終了`n"
    jaContent .= "new_playlist_title = プレイリストを作成`n"
    jaContent .= "new_playlist_label = 新しいプレイリストの名前：`n"
    jaContent .= "create = 作成`n"
    jaContent .= "cancel = キャンセル`n"
    jaContent .= "name_empty = 名前を空にすることはできません。`n"
    jaContent .= "name_exists = その名前のプレイリストはすでに存在します。`n"
    jaContent .= "confirm_delete = このプレイリストを削除してもよろしいですか？`n"
    jaContent .= "confirm_delete_title = 確認`n"
    jaContent .= "select_playlist_first = 最初にプレイリストを選択または作成してください。`n"
    jaContent .= "`n"
    jaContent .= "[MiniPlayer]`n"
    jaContent .= "artist = アーティスト`n"
    jaContent .= "album = アルバム`n"
    jaContent .= "title = タイトル`n"
    jaContent .= "`n"
    jaContent .= "[Language]`n"
    jaContent .= "language_title = 言語を選択`n"
    jaContent .= "`n"
    try FileDelete(langDir  "\ja-lang.ini")
    FileAppend(jaContent, langDir "\ja-lang.ini", "UTF-8")

    ; ===== ZH =====
    zhContent := ""
    zhContent .= "[General]`n"
    zhContent .= "app_name = Magic Jukebox`n"
    zhContent .= "playing = 正在播放：`n"
    zhContent .= "`n"
    zhContent .= "[Tray]`n"
    zhContent .= "search_song = 搜索歌曲`n"
    zhContent .= "playlist_manager = 播放列表`n"
    zhContent .= "open_miniplayer = 打开迷你播放器`n"
    zhContent .= "auto_mode_on = 自动模式 [开]`n"
    zhContent .= "auto_mode_off = 自动模式 [关]`n"
    zhContent .= "pause_resume = 暂停 / 继续`n"
    zhContent .= "repeat_song = 重复歌曲`n"
    zhContent .= "change_music_folder = 更改音乐文件夹`n"
    zhContent .= "change_vlc = 更改 VLC.exe`n"
    zhContent .= "assign_hotkeys = 设置热键`n"
    zhContent .= "change_language = 更改语言`n"
    zhContent .= "return_normal_mode = 返回正常模式`n"
    zhContent .= "quit = 退出`n"
    zhContent .= "`n"
    zhContent .= "[Hotkeys]`n"
    zhContent .= "prev_song = 上一首歌`n"
    zhContent .= "next_song = 下一首歌`n"
    zhContent .= "search_song = 搜索歌曲`n"
    zhContent .= "pause_resume = 暂停 / 继续`n"
    zhContent .= "repeat_song = 重复歌曲`n"
    zhContent .= "playlist = 播放列表`n"
    zhContent .= "guide = 指南`n"
    zhContent .= "update_hotkeys = 更新热键`n"
    zhContent .= "hotkeys_updated = 热键已成功更新。`n"
    zhContent .= "invalid_hotkey = '{1}' 的热键无效。``n请更正该值并重试。`n"
    zhContent .= "guide_text = 格式：修饰键+键``n``n有效修饰键：``n  Ctrl, Alt, Shift, Win``n``n示例：``n  Ctrl+9``n  Alt+F1``n  Ctrl+Shift+P``n  Win+R``n``n也可以分配单个键，但不推荐（例如 F9）。``n``n数字键盘：Ctrl+Numpad9``n使用数字键盘时请记得开启 Num Lock。`n"
    zhContent .= "`n"
    zhContent .= "[Setup]`n"
    zhContent .= "select_music_folder = 选择您的音乐文件夹`n"
    zhContent .= "must_select_folder = 您必须选择一个音乐文件夹才能继续。`n"
    zhContent .= "invalid_folder = 无效的文件夹。`n"
    zhContent .= "select_vlc = 选择 vlc.exe 文件`n"
    zhContent .= "must_select_vlc = 您必须选择 vlc.exe。`n"
    zhContent .= "incorrect_file = 文件不正确。`n"
    zhContent .= "music_folders_title = 音乐文件夹`n"
    zhContent .= "music_folders_label = 音乐文件夹：`n"
    zhContent .= "add_folder = + 添加`n"
    zhContent .= "change_folder_btn = 更改`n"
    zhContent .= "remove_folder = 删除`n"
    zhContent .= "select_music_folder_dir = 选择音乐文件夹`n"
    zhContent .= "select_new_location = 选择新位置`n"
    zhContent .= "must_keep_one_folder = 您必须保留至少一个音乐文件夹。`n"
    zhContent .= "add_folder_recursive = + 添加含子文件夹`n"
    zhContent .= "tray_tip_start = Magic Jukebox 在这里，正在后台运行`n"
    zhContent .= "`n"
    zhContent .= "[Search]`n"
    zhContent .= "search_title = 搜索歌曲`n"
    zhContent .= "no_music_folder = 未指定音乐文件夹。``n请先进行设置。`n"
    zhContent .= "no_songs_found = 当前文件夹中未找到歌曲。`n"
    zhContent .= "`n"
    zhContent .= "[Playlist]`n"
    zhContent .= "playlist_title = 播放列表管理器`n"
    zhContent .= "reorder_title_playlists = 播放列表管理器（设置新顺序）`n"
    zhContent .= "reorder_title_songs = 播放列表管理器（设置 {1} 的顺序）`n"
    zhContent .= "search_song = 搜索歌曲：`n"
    zhContent .= "playlists = 播放列表：`n"
    zhContent .= "playlist_songs = 播放列表中的歌曲：`n"
    zhContent .= "play = ▶ 播放`n"
    zhContent .= "remove = ➖ 移除`n"
    zhContent .= "delete = 🗑 删除`n"
    zhContent .= "create_playlist = ➕ 创建播放列表`n"
    zhContent .= "play_all = ▶ 播放所有列表`n"
    zhContent .= "loop_on = 循环：开`n"
    zhContent .= "loop_off = 循环：关`n"
    zhContent .= "random_on = 随机：开`n"
    zhContent .= "random_off = 随机：关`n"
    zhContent .= "reorder_instructions = 要更改播放顺序，请双击歌曲或播放列表进入编辑模式。`n"
    zhContent .= "reorder_playlists_instructions = 选择一个播放列表并使用 ▲ ▼ 移动它。`n"
    zhContent .= "reorder_songs_instructions = 选择一首歌曲并使用 ▲ ▼ 移动它。`n"
    zhContent .= "move_up = ▲ 上移`n"
    zhContent .= "move_down = ▼ 下移`n"
    zhContent .= "exit_reorder = ✖ 退出编辑模式`n"
    zhContent .= "new_playlist_title = 创建播放列表`n"
    zhContent .= "new_playlist_label = 新播放列表的名称：`n"
    zhContent .= "create = 创建`n"
    zhContent .= "cancel = 取消`n"
    zhContent .= "name_empty = 名称不能为空。`n"
    zhContent .= "name_exists = 已存在同名播放列表。`n"
    zhContent .= "confirm_delete = 您确定要删除此播放列表吗？`n"
    zhContent .= "confirm_delete_title = 确认`n"
    zhContent .= "select_playlist_first = 请先选择或创建一个播放列表。`n"
    zhContent .= "`n"
    zhContent .= "[MiniPlayer]`n"
    zhContent .= "artist = 艺术家`n"
    zhContent .= "album = 专辑`n"
    zhContent .= "title = 标题`n"
    zhContent .= "`n"
    zhContent .= "[Language]`n"
    zhContent .= "language_title = 选择语言`n"
    zhContent .= "`n"
    try FileDelete(langDir  "\zh-lang.ini")
    FileAppend(zhContent, langDir "\zh-lang.ini", "UTF-8")

    ; ===== KO =====
    koContent := ""
    koContent .= "[General]`n"
    koContent .= "app_name = Magic Jukebox`n"
    koContent .= "playing = 재생 중:`n"
    koContent .= "`n"
    koContent .= "[Tray]`n"
    koContent .= "search_song = 노래 검색`n"
    koContent .= "playlist_manager = 재생 목록`n"
    koContent .= "open_miniplayer = 미니 플레이어 열기`n"
    koContent .= "auto_mode_on = 자동 모드 [켜짐]`n"
    koContent .= "auto_mode_off = 자동 모드 [꺼짐]`n"
    koContent .= "pause_resume = 일시 정지 / 재개`n"
    koContent .= "repeat_song = 노래 반복`n"
    koContent .= "change_music_folder = 음악 폴더 변경`n"
    koContent .= "change_vlc = VLC.exe 변경`n"
    koContent .= "assign_hotkeys = 단축키 지정`n"
    koContent .= "change_language = 언어 변경`n"
    koContent .= "return_normal_mode = 일반 모드로 돌아가기`n"
    koContent .= "quit = 종료`n"
    koContent .= "`n"
    koContent .= "[Hotkeys]`n"
    koContent .= "prev_song = 이전 노래`n"
    koContent .= "next_song = 다음 노래`n"
    koContent .= "search_song = 노래 검색`n"
    koContent .= "pause_resume = 일시 정지 / 재개`n"
    koContent .= "repeat_song = 노래 반복`n"
    koContent .= "playlist = 재생 목록`n"
    koContent .= "guide = 가이드`n"
    koContent .= "update_hotkeys = 단축키 업데이트`n"
    koContent .= "hotkeys_updated = 단축키가 성공적으로 업데이트되었습니다.`n"
    koContent .= "invalid_hotkey = '{1}'의 단축키가 올바르지 않습니다.``n값을 수정하고 다시 시도하세요.`n"
    koContent .= "guide_text = 형식: 수정키+키``n``n유효한 수정키:``n  Ctrl, Alt, Shift, Win``n``n예시:``n  Ctrl+9``n  Alt+F1``n  Ctrl+Shift+P``n  Win+R``n``n단일 키도 지정할 수 있지만 권장하지 않습니다 (예: F9).``n``nNumpad의 경우: Ctrl+Numpad9``nNumpad 사용 시 Num Lock을 활성화하는 것을 잊지 마세요.`n"
    koContent .= "`n"
    koContent .= "[Setup]`n"
    koContent .= "select_music_folder = 음악 폴더를 선택하세요`n"
    koContent .= "must_select_folder = 계속하려면 음악 폴더를 선택해야 합니다.`n"
    koContent .= "invalid_folder = 올바르지 않은 폴더입니다.`n"
    koContent .= "select_vlc = vlc.exe 파일을 선택하세요`n"
    koContent .= "must_select_vlc = vlc.exe를 선택해야 합니다.`n"
    koContent .= "incorrect_file = 올바르지 않은 파일입니다.`n"
    koContent .= "music_folders_title = 음악 폴더`n"
    koContent .= "music_folders_label = 음악 폴더:`n"
    koContent .= "add_folder = + 추가`n"
    koContent .= "change_folder_btn = 변경`n"
    koContent .= "remove_folder = 삭제`n"
    koContent .= "select_music_folder_dir = 음악 폴더를 선택하세요`n"
    koContent .= "select_new_location = 새 위치를 선택하세요`n"
    koContent .= "must_keep_one_folder = 음악 폴더를 최소 하나 유지해야 합니다.`n"
    koContent .= "add_folder_recursive = + 하위 폴더 포함 추가`n"
    koContent .= "tray_tip_start = Magic Jukebox가 여기 있습니다, 백그라운드 실행 중`n"
    koContent .= "`n"
    koContent .= "[Search]`n"
    koContent .= "search_title = 노래 검색`n"
    koContent .= "no_music_folder = 음악 폴더가 지정되지 않았습니다.``n먼저 설정하세요.`n"
    koContent .= "no_songs_found = 현재 폴더에서 노래를 찾을 수 없습니다.`n"
    koContent .= "`n"
    koContent .= "[Playlist]`n"
    koContent .= "playlist_title = 재생 목록 관리자`n"
    koContent .= "reorder_title_playlists = 재생 목록 관리자 (새 순서 설정 중)`n"
    koContent .= "reorder_title_songs = 재생 목록 관리자 ({1} 순서 설정 중)`n"
    koContent .= "search_song = 노래 검색:`n"
    koContent .= "playlists = 재생 목록:`n"
    koContent .= "playlist_songs = 재생 목록의 노래:`n"
    koContent .= "play = ▶ 재생`n"
    koContent .= "remove = ➖ 제거`n"
    koContent .= "delete = 🗑 삭제`n"
    koContent .= "create_playlist = ➕ 재생 목록 만들기`n"
    koContent .= "play_all = ▶ 모든 재생 목록 재생`n"
    koContent .= "loop_on = 반복: 켜짐`n"
    koContent .= "loop_off = 반복: 꺼짐`n"
    koContent .= "random_on = 무작위: 켜짐`n"
    koContent .= "random_off = 무작위: 꺼짐`n"
    koContent .= "reorder_instructions = 재생 순서를 변경하려면 노래 또는 재생 목록을 두 번 클릭하세요.`n"
    koContent .= "reorder_playlists_instructions = 재생 목록을 선택하고 ▲ ▼ 를 사용하여 이동하세요.`n"
    koContent .= "reorder_songs_instructions = 노래를 선택하고 ▲ ▼ 를 사용하여 이동하세요.`n"
    koContent .= "move_up = ▲ 위로`n"
    koContent .= "move_down = ▼ 아래로`n"
    koContent .= "exit_reorder = ✖ 편집 모드 종료`n"
    koContent .= "new_playlist_title = 재생 목록 만들기`n"
    koContent .= "new_playlist_label = 새 재생 목록의 이름:`n"
    koContent .= "create = 만들기`n"
    koContent .= "cancel = 취소`n"
    koContent .= "name_empty = 이름은 비워 둘 수 없습니다.`n"
    koContent .= "name_exists = 같은 이름의 재생 목록이 이미 있습니다.`n"
    koContent .= "confirm_delete = 이 재생 목록을 삭제하시겠습니까?`n"
    koContent .= "confirm_delete_title = 확인`n"
    koContent .= "select_playlist_first = 먼저 재생 목록을 선택하거나 만드세요.`n"
    koContent .= "`n"
    koContent .= "[MiniPlayer]`n"
    koContent .= "artist = 아티스트`n"
    koContent .= "album = 앨범`n"
    koContent .= "title = 제목`n"
    koContent .= "`n"
    koContent .= "[Language]`n"
    koContent .= "language_title = 언어 선택`n"
    koContent .= "`n"
    try FileDelete(langDir  "\ko-lang.ini")
    FileAppend(koContent, langDir "\ko-lang.ini", "UTF-8")

    ; ===== AR =====
    arContent := ""
    arContent .= "[General]`n"
    arContent .= "app_name = Magic Jukebox`n"
    arContent .= "playing = جارٍ التشغيل:`n"
    arContent .= "`n"
    arContent .= "[Tray]`n"
    arContent .= "search_song = البحث عن أغنية`n"
    arContent .= "playlist_manager = قائمة التشغيل`n"
    arContent .= "open_miniplayer = فتح المشغل المصغر`n"
    arContent .= "auto_mode_on = الوضع التلقائي [تشغيل]`n"
    arContent .= "auto_mode_off = الوضع التلقائي [إيقاف]`n"
    arContent .= "pause_resume = إيقاف مؤقت / استئناف`n"
    arContent .= "repeat_song = تكرار الأغنية`n"
    arContent .= "change_music_folder = تغيير مجلد الموسيقى`n"
    arContent .= "change_vlc = تغيير VLC.exe`n"
    arContent .= "assign_hotkeys = تعيين الاختصارات`n"
    arContent .= "change_language = تغيير اللغة`n"
    arContent .= "return_normal_mode = العودة إلى الوضع الطبيعي`n"
    arContent .= "quit = خروج`n"
    arContent .= "`n"
    arContent .= "[Hotkeys]`n"
    arContent .= "prev_song = الأغنية السابقة`n"
    arContent .= "next_song = الأغنية التالية`n"
    arContent .= "search_song = البحث عن أغنية`n"
    arContent .= "pause_resume = إيقاف مؤقت / استئناف`n"
    arContent .= "repeat_song = تكرار الأغنية`n"
    arContent .= "playlist = قائمة التشغيل`n"
    arContent .= "guide = دليل`n"
    arContent .= "update_hotkeys = تحديث الاختصارات`n"
    arContent .= "hotkeys_updated = تم تحديث الاختصارات بنجاح.`n"
    arContent .= "invalid_hotkey = الاختصار لـ '{1}' غير صالح.``nصحّح القيمة وحاول مجددًا.`n"
    arContent .= "guide_text = الصيغة: معدِّل+مفتاح``n``nالمعدِّلات الصالحة:``n  Ctrl, Alt, Shift, Win``n``nأمثلة:``n  Ctrl+9``n  Alt+F1``n  Ctrl+Shift+P``n  Win+R``n``nيمكن تعيين مفاتيح منفردة رغم عدم التوصية بذلك (مثل F9).``n``nللوحة الرقمية: Ctrl+Numpad9``nتذكّر تفعيل Num Lock.`n"
    arContent .= "`n"
    arContent .= "[Setup]`n"
    arContent .= "select_music_folder = اختر مجلد الموسيقى`n"
    arContent .= "must_select_folder = يجب اختيار مجلد الموسيقى للمتابعة.`n"
    arContent .= "invalid_folder = مجلد غير صالح.`n"
    arContent .= "select_vlc = اختر ملف vlc.exe`n"
    arContent .= "must_select_vlc = يجب اختيار vlc.exe.`n"
    arContent .= "incorrect_file = ملف غير صحيح.`n"
    arContent .= "music_folders_title = مجلدات الموسيقى`n"
    arContent .= "music_folders_label = مجلدات الموسيقى:`n"
    arContent .= "add_folder = + إضافة`n"
    arContent .= "change_folder_btn = تغيير`n"
    arContent .= "remove_folder = إزالة`n"
    arContent .= "select_music_folder_dir = اختر مجلد الموسيقى`n"
    arContent .= "select_new_location = اختر الموقع الجديد`n"
    arContent .= "must_keep_one_folder = يجب الاحتفاظ بمجلد موسيقى واحد على الأقل.`n"
    arContent .= "add_folder_recursive = + إضافة مع المجلدات الفرعية`n"
    arContent .= "tray_tip_start = Magic Jukebox هنا، يعمل في الخلفية`n"
    arContent .= "`n"
    arContent .= "[Search]`n"
    arContent .= "search_title = البحث عن أغنية`n"
    arContent .= "no_music_folder = لم يتم تحديد مجلد الموسيقى.``nقم بإعداده أولاً.`n"
    arContent .= "no_songs_found = لم يتم العثور على أغاني في المجلد الحالي.`n"
    arContent .= "`n"
    arContent .= "[Playlist]`n"
    arContent .= "playlist_title = مدير قوائم التشغيل`n"
    arContent .= "reorder_title_playlists = مدير قوائم التشغيل (تعيين ترتيب جديد)`n"
    arContent .= "reorder_title_songs = مدير قوائم التشغيل (تعيين ترتيب {1})`n"
    arContent .= "search_song = البحث عن أغنية:`n"
    arContent .= "playlists = قوائم التشغيل:`n"
    arContent .= "playlist_songs = أغاني القائمة:`n"
    arContent .= "play = ▶ تشغيل`n"
    arContent .= "remove = ➖ إزالة`n"
    arContent .= "delete = 🗑 حذف`n"
    arContent .= "create_playlist = ➕ إنشاء قائمة تشغيل`n"
    arContent .= "play_all = ▶ تشغيل كل القوائم`n"
    arContent .= "loop_on = تكرار: تشغيل`n"
    arContent .= "loop_off = تكرار: إيقاف`n"
    arContent .= "random_on = عشوائي: تشغيل`n"
    arContent .= "random_off = عشوائي: إيقاف`n"
    arContent .= "reorder_instructions = لتغيير ترتيب التشغيل، انقر نقرًا مزدوجًا على أغنية أو قائمة.`n"
    arContent .= "reorder_playlists_instructions = اختر قائمة واستخدم ▲ ▼ لتحريكها.`n"
    arContent .= "reorder_songs_instructions = اختر أغنية واستخدم ▲ ▼ لتحريكها.`n"
    arContent .= "move_up = ▲ للأعلى`n"
    arContent .= "move_down = ▼ للأسفل`n"
    arContent .= "exit_reorder = ✖ الخروج من وضع التحرير`n"
    arContent .= "new_playlist_title = إنشاء قائمة تشغيل`n"
    arContent .= "new_playlist_label = اسم قائمة التشغيل الجديدة:`n"
    arContent .= "create = إنشاء`n"
    arContent .= "cancel = إلغاء`n"
    arContent .= "name_empty = لا يمكن أن يكون الاسم فارغًا.`n"
    arContent .= "name_exists = توجد بالفعل قائمة بهذا الاسم.`n"
    arContent .= "confirm_delete = هل أنت متأكد من حذف هذه القائمة؟`n"
    arContent .= "confirm_delete_title = تأكيد`n"
    arContent .= "select_playlist_first = الرجاء اختيار أو إنشاء قائمة أولاً.`n"
    arContent .= "`n"
    arContent .= "[MiniPlayer]`n"
    arContent .= "artist = الفنان`n"
    arContent .= "album = الألبوم`n"
    arContent .= "title = العنوان`n"
    arContent .= "`n"
    arContent .= "[Language]`n"
    arContent .= "language_title = اختر اللغة`n"
    arContent .= "`n"
    try FileDelete(langDir  "\ar-lang.ini")
    FileAppend(arContent, langDir "\ar-lang.ini", "UTF-8")

    ; ===== HI =====
    hiContent := ""
    hiContent .= "[General]`n"
    hiContent .= "app_name = Magic Jukebox`n"
    hiContent .= "playing = चल रहा है:`n"
    hiContent .= "`n"
    hiContent .= "[Tray]`n"
    hiContent .= "search_song = गाना खोजें`n"
    hiContent .= "playlist_manager = प्लेलिस्ट`n"
    hiContent .= "open_miniplayer = मिनीप्लेयर खोलें`n"
    hiContent .= "auto_mode_on = स्वचालित मोड [चालू]`n"
    hiContent .= "auto_mode_off = स्वचालित मोड [बंद]`n"
    hiContent .= "pause_resume = रोकें / जारी रखें`n"
    hiContent .= "repeat_song = गाना दोहराएं`n"
    hiContent .= "change_music_folder = संगीत फ़ोल्डर बदलें`n"
    hiContent .= "change_vlc = VLC.exe बदलें`n"
    hiContent .= "assign_hotkeys = शॉर्टकट सेट करें`n"
    hiContent .= "change_language = भाषा बदलें`n"
    hiContent .= "return_normal_mode = सामान्य मोड पर लौटें`n"
    hiContent .= "quit = बाहर निकलें`n"
    hiContent .= "`n"
    hiContent .= "[Hotkeys]`n"
    hiContent .= "prev_song = पिछला गाना`n"
    hiContent .= "next_song = अगला गाना`n"
    hiContent .= "search_song = गाना खोजें`n"
    hiContent .= "pause_resume = रोकें / जारी रखें`n"
    hiContent .= "repeat_song = गाना दोहराएं`n"
    hiContent .= "playlist = प्लेलिस्ट`n"
    hiContent .= "guide = गाइड`n"
    hiContent .= "update_hotkeys = शॉर्टकट अपडेट करें`n"
    hiContent .= "hotkeys_updated = शॉर्टकट सफलतापूर्वक अपडेट किए गए।`n"
    hiContent .= "invalid_hotkey = '{1}' के लिए शॉर्टकट मान्य नहीं है।``nमान सुधारें और फिर प्रयास करें।`n"
    hiContent .= "guide_text = प्रारूप: संशोधक+कुंजी``n``nमान्य संशोधक:``n  Ctrl, Alt, Shift, Win``n``nउदाहरण:``n  Ctrl+9``n  Alt+F1``n  Ctrl+Shift+P``n  Win+R``n``nएकल कुंजियाँ भी सेट की जा सकती हैं``nहालांकि अनुशंसित नहीं (जैसे F9)।``n``nNumpad के लिए: Ctrl+Numpad9``nNumpad उपयोग करते समय Num Lock सक्षम करना न भूलें।`n"
    hiContent .= "`n"
    hiContent .= "[Setup]`n"
    hiContent .= "select_music_folder = अपना संगीत फ़ोल्डर चुनें`n"
    hiContent .= "must_select_folder = जारी रखने के लिए संगीत फ़ोल्डर चुनना आवश्यक है।`n"
    hiContent .= "invalid_folder = अमान्य फ़ोल्डर।`n"
    hiContent .= "select_vlc = vlc.exe फ़ाइल चुनें`n"
    hiContent .= "must_select_vlc = vlc.exe चुनना आवश्यक है।`n"
    hiContent .= "incorrect_file = गलत फ़ाइल।`n"
    hiContent .= "music_folders_title = संगीत फ़ोल्डर`n"
    hiContent .= "music_folders_label = संगीत फ़ोल्डर:`n"
    hiContent .= "add_folder = + जोड़ें`n"
    hiContent .= "change_folder_btn = बदलें`n"
    hiContent .= "remove_folder = हटाएं`n"
    hiContent .= "select_music_folder_dir = संगीत फ़ोल्डर चुनें`n"
    hiContent .= "select_new_location = नई स्थान चुनें`n"
    hiContent .= "must_keep_one_folder = आपको कम से कम एक संगीत फ़ोल्डर रखना होगा।`n"
    hiContent .= "add_folder_recursive = + सबफ़ोल्डर के साथ जोड़ें`n"
    hiContent .= "tray_tip_start = Magic Jukebox यहाँ है, पृष्ठभूमि में चल रहा है`n"
    hiContent .= "`n"
    hiContent .= "[Search]`n"
    hiContent .= "search_title = गाना खोजें`n"
    hiContent .= "no_music_folder = कोई संगीत फ़ोल्डर नहीं चुना गया।``nपहले इसे सेट करें।`n"
    hiContent .= "no_songs_found = वर्तमान फ़ोल्डर में कोई गाना नहीं मिला।`n"
    hiContent .= "`n"
    hiContent .= "[Playlist]`n"
    hiContent .= "playlist_title = प्लेलिस्ट प्रबंधक`n"
    hiContent .= "reorder_title_playlists = प्लेलिस्ट प्रबंधक (नया क्रम सेट हो रहा है)`n"
    hiContent .= "reorder_title_songs = प्लेलिस्ट प्रबंधक ({1} का क्रम सेट हो रहा है)`n"
    hiContent .= "search_song = गाना खोजें:`n"
    hiContent .= "playlists = प्लेलिस्ट:`n"
    hiContent .= "playlist_songs = प्लेलिस्ट के गाने:`n"
    hiContent .= "play = ▶ चलाएं`n"
    hiContent .= "remove = ➖ हटाएं`n"
    hiContent .= "delete = 🗑 मिटाएं`n"
    hiContent .= "create_playlist = ➕ प्लेलिस्ट बनाएं`n"
    hiContent .= "play_all = ▶ सभी प्लेलिस्ट चलाएं`n"
    hiContent .= "loop_on = लूप: चालू`n"
    hiContent .= "loop_off = लूप: बंद`n"
    hiContent .= "random_on = यादृच्छिक: चालू`n"
    hiContent .= "random_off = यादृच्छिक: बंद`n"
    hiContent .= "reorder_instructions = क्रम बदलने के लिए किसी गाने या प्लेलिस्ट पर डबल-क्लिक करें।`n"
    hiContent .= "reorder_playlists_instructions = एक प्लेलिस्ट चुनें और ▲ ▼ से स्थानांतरित करें।`n"
    hiContent .= "reorder_songs_instructions = एक गाना चुनें और ▲ ▼ से स्थानांतरित करें।`n"
    hiContent .= "move_up = ▲ ऊपर`n"
    hiContent .= "move_down = ▼ नीचे`n"
    hiContent .= "exit_reorder = ✖ संपादन मोड से बाहर निकलें`n"
    hiContent .= "new_playlist_title = प्लेलिस्ट बनाएं`n"
    hiContent .= "new_playlist_label = नई प्लेलिस्ट का नाम:`n"
    hiContent .= "create = बनाएं`n"
    hiContent .= "cancel = रद्द करें`n"
    hiContent .= "name_empty = नाम खाली नहीं हो सकता।`n"
    hiContent .= "name_exists = इस नाम की प्लेलिस्ट पहले से मौजूद है।`n"
    hiContent .= "confirm_delete = क्या आप वाकई इस प्लेलिस्ट को हटाना चाहते हैं?`n"
    hiContent .= "confirm_delete_title = पुष्टि करें`n"
    hiContent .= "select_playlist_first = पहले कोई प्लेलिस्ट चुनें या बनाएं।`n"
    hiContent .= "`n"
    hiContent .= "[MiniPlayer]`n"
    hiContent .= "artist = कलाकार`n"
    hiContent .= "album = एल्बम`n"
    hiContent .= "title = शीर्षक`n"
    hiContent .= "`n"
    hiContent .= "[Language]`n"
    hiContent .= "language_title = भाषा चुनें`n"
    hiContent .= "`n"
    try FileDelete(langDir  "\hi-lang.ini")
    FileAppend(hiContent, langDir "\hi-lang.ini", "UTF-8")

    ; ===== BN =====
    bnContent := ""
    bnContent .= "[General]`n"
    bnContent .= "app_name = Magic Jukebox`n"
    bnContent .= "playing = চলছে:`n"
    bnContent .= "`n"
    bnContent .= "[Tray]`n"
    bnContent .= "search_song = গান খুঁজুন`n"
    bnContent .= "playlist_manager = প্লেলিস্ট`n"
    bnContent .= "open_miniplayer = মিনিপ্লেয়ার খুলুন`n"
    bnContent .= "auto_mode_on = স্বয়ংক্রিয় মোড [চালু]`n"
    bnContent .= "auto_mode_off = স্বয়ংক্রিয় মোড [বন্ধ]`n"
    bnContent .= "pause_resume = বিরতি / পুনরায় চালু`n"
    bnContent .= "repeat_song = গান পুনরাবৃত্তি`n"
    bnContent .= "change_music_folder = মিউজিক ফোল্ডার পরিবর্তন`n"
    bnContent .= "change_vlc = VLC.exe পরিবর্তন`n"
    bnContent .= "assign_hotkeys = হটকি নির্ধারণ করুন`n"
    bnContent .= "change_language = ভাষা পরিবর্তন`n"
    bnContent .= "return_normal_mode = স্বাভাবিক মোডে ফিরুন`n"
    bnContent .= "quit = প্রস্থান`n"
    bnContent .= "`n"
    bnContent .= "[Hotkeys]`n"
    bnContent .= "prev_song = আগের গান`n"
    bnContent .= "next_song = পরবর্তী গান`n"
    bnContent .= "search_song = গান খুঁজুন`n"
    bnContent .= "pause_resume = বিরতি / পুনরায় চালু`n"
    bnContent .= "repeat_song = গান পুনরাবৃত্তি`n"
    bnContent .= "playlist = প্লেলিস্ট`n"
    bnContent .= "guide = গাইড`n"
    bnContent .= "update_hotkeys = হটকি আপডেট করুন`n"
    bnContent .= "hotkeys_updated = হটকি সফলভাবে আপডেট হয়েছে।`n"
    bnContent .= "invalid_hotkey = '{1}' এর হটকি বৈধ নয়।``nমান সংশোধন করুন এবং আবার চেষ্টা করুন।`n"
    bnContent .= "guide_text = ফরম্যাট: মডিফায়ার+কী``n``nবৈধ মডিফায়ার:``n  Ctrl, Alt, Shift, Win``n``nউদাহরণ:``n  Ctrl+9``n  Alt+F1``n  Ctrl+Shift+P``n  Win+R``n``nএকক কী-ও নির্ধারণ করা যায়``nতবে প্রস্তাবিত নয় (যেমন F9)।``n``nNumpad এর জন্য: Ctrl+Numpad9``nNumpad ব্যবহার করলে Num Lock চালু রাখুন।`n"
    bnContent .= "`n"
    bnContent .= "[Setup]`n"
    bnContent .= "select_music_folder = আপনার মিউজিক ফোল্ডার নির্বাচন করুন`n"
    bnContent .= "must_select_folder = চালিয়ে যেতে একটি মিউজিক ফোল্ডার নির্বাচন করতে হবে।`n"
    bnContent .= "invalid_folder = অবৈধ ফোল্ডার।`n"
    bnContent .= "select_vlc = vlc.exe ফাইল নির্বাচন করুন`n"
    bnContent .= "must_select_vlc = vlc.exe নির্বাচন করতে হবে।`n"
    bnContent .= "incorrect_file = ভুল ফাইল।`n"
    bnContent .= "music_folders_title = মিউজিক ফোল্ডার`n"
    bnContent .= "music_folders_label = মিউজিক ফোল্ডার:`n"
    bnContent .= "add_folder = + যোগ`n"
    bnContent .= "change_folder_btn = বদলান`n"
    bnContent .= "remove_folder = সরান`n"
    bnContent .= "select_music_folder_dir = মিউজিক ফোল্ডার নির্বাচন করুন`n"
    bnContent .= "select_new_location = নতুন অবস্থান নির্বাচন করুন`n"
    bnContent .= "must_keep_one_folder = আপনাকে কমপক্ষে একটি মিউজিক ফোল্ডার রাখতে হবে।`n"
    bnContent .= "add_folder_recursive = + সাবফোল্ডারসহ যোগ করুন`n"
    bnContent .= "tray_tip_start = Magic Jukebox এখানে আছে, ব্যাকগ্রাউন্ডে চলছে`n"
    bnContent .= "`n"
    bnContent .= "[Search]`n"
    bnContent .= "search_title = গান খুঁজুন`n"
    bnContent .= "no_music_folder = কোনো মিউজিক ফোল্ডার নির্ধারিত নেই।``nআগে সেটআপ করুন।`n"
    bnContent .= "no_songs_found = বর্তমান ফোল্ডারে কোনো গান পাওয়া যায়নি।`n"
    bnContent .= "`n"
    bnContent .= "[Playlist]`n"
    bnContent .= "playlist_title = প্লেলিস্ট ম্যানেজার`n"
    bnContent .= "reorder_title_playlists = প্লেলিস্ট ম্যানেজার (নতুন ক্রম নির্ধারণ হচ্ছে)`n"
    bnContent .= "reorder_title_songs = প্লেলিস্ট ম্যানেজার ({1} এর ক্রম নির্ধারণ হচ্ছে)`n"
    bnContent .= "search_song = গান খুঁজুন:`n"
    bnContent .= "playlists = প্লেলিস্ট:`n"
    bnContent .= "playlist_songs = প্লেলিস্টের গান:`n"
    bnContent .= "play = ▶ চালান`n"
    bnContent .= "remove = ➖ সরান`n"
    bnContent .= "delete = 🗑 মুছুন`n"
    bnContent .= "create_playlist = ➕ প্লেলিস্ট তৈরি করুন`n"
    bnContent .= "play_all = ▶ সব প্লেলিস্ট চালান`n"
    bnContent .= "loop_on = লুপ: চালু`n"
    bnContent .= "loop_off = লুপ: বন্ধ`n"
    bnContent .= "random_on = এলোমেলো: চালু`n"
    bnContent .= "random_off = এলোমেলো: বন্ধ`n"
    bnContent .= "reorder_instructions = ক্রম পরিবর্তন করতে একটি গান বা প্লেলিস্টে ডাবল-ক্লিক করুন।`n"
    bnContent .= "reorder_playlists_instructions = একটি প্লেলিস্ট নির্বাচন করুন এবং উপরে / নিচে ব্যবহার করুন।`n"
    bnContent .= "reorder_songs_instructions = একটি গান নির্বাচন করুন এবং উপরে / নিচে ব্যবহার করুন।`n"
    bnContent .= "move_up = ▲ উপরে`n"
    bnContent .= "move_down = ▼ নিচে`n"
    bnContent .= "exit_reorder = ✖ সম্পাদনা মোড থেকে বের হন`n"
    bnContent .= "new_playlist_title = প্লেলিস্ট তৈরি করুন`n"
    bnContent .= "new_playlist_label = নতুন প্লেলিস্টের নাম:`n"
    bnContent .= "create = তৈরি করুন`n"
    bnContent .= "cancel = বাতিল`n"
    bnContent .= "name_empty = নাম খালি রাখা যাবে না।`n"
    bnContent .= "name_exists = এই নামের প্লেলিস্ট ইতিমধ্যে আছে।`n"
    bnContent .= "confirm_delete = আপনি কি এই প্লেলিস্টটি মুছতে চান?`n"
    bnContent .= "confirm_delete_title = নিশ্চিত করুন`n"
    bnContent .= "select_playlist_first = আগে একটি প্লেলিস্ট নির্বাচন বা তৈরি করুন।`n"
    bnContent .= "`n"
    bnContent .= "[MiniPlayer]`n"
    bnContent .= "artist = শিল্পী`n"
    bnContent .= "album = অ্যালবাম`n"
    bnContent .= "title = শিরোনাম`n"
    bnContent .= "`n"
    bnContent .= "[Language]`n"
    bnContent .= "language_title = ভাষা নির্বাচন করুন`n"
    bnContent .= "`n"
    try FileDelete(langDir  "\bn-lang.ini")
    FileAppend(bnContent, langDir "\bn-lang.ini", "UTF-8")

    ; ===== ID =====
    idContent := ""
    idContent .= "[General]`n"
    idContent .= "app_name = Magic Jukebox`n"
    idContent .= "playing = Memutar:`n"
    idContent .= "`n"
    idContent .= "[Tray]`n"
    idContent .= "search_song = Cari lagu`n"
    idContent .= "playlist_manager = Daftar putar`n"
    idContent .= "open_miniplayer = Buka miniplayer`n"
    idContent .= "auto_mode_on = Mode otomatis [Aktif]`n"
    idContent .= "auto_mode_off = Mode otomatis [Nonaktif]`n"
    idContent .= "pause_resume = Jeda / Lanjutkan`n"
    idContent .= "repeat_song = Ulangi lagu`n"
    idContent .= "change_music_folder = Ubah folder musik`n"
    idContent .= "change_vlc = Ubah VLC.exe`n"
    idContent .= "assign_hotkeys = Tetapkan hotkey`n"
    idContent .= "change_language = Ubah bahasa`n"
    idContent .= "return_normal_mode = Kembali ke mode normal`n"
    idContent .= "quit = Keluar`n"
    idContent .= "`n"
    idContent .= "[Hotkeys]`n"
    idContent .= "prev_song = Lagu sebelumnya`n"
    idContent .= "next_song = Lagu berikutnya`n"
    idContent .= "search_song = Cari lagu`n"
    idContent .= "pause_resume = Jeda / Lanjutkan`n"
    idContent .= "repeat_song = Ulangi lagu`n"
    idContent .= "playlist = Daftar putar`n"
    idContent .= "guide = Panduan`n"
    idContent .= "update_hotkeys = Perbarui hotkey`n"
    idContent .= "hotkeys_updated = Hotkey berhasil diperbarui.`n"
    idContent .= "invalid_hotkey = Hotkey untuk '{1}' tidak valid.``nPerbaiki nilai dan coba lagi.`n"
    idContent .= "guide_text = Format: Modifier+Tombol``n``nModifier yang valid:``n  Ctrl, Alt, Shift, Win``n``nContoh:``n  Ctrl+9``n  Alt+F1``n  Ctrl+Shift+P``n  Win+R``n``nAnda juga dapat menetapkan tombol tunggal``nmeskipun tidak disarankan (mis. F9).``n``nUntuk Numpad: Ctrl+Numpad9``nIngat untuk mengaktifkan Num Lock jika menggunakan Numpad.`n"
    idContent .= "`n"
    idContent .= "[Setup]`n"
    idContent .= "select_music_folder = Pilih folder musik Anda`n"
    idContent .= "must_select_folder = Anda harus memilih folder musik untuk melanjutkan.`n"
    idContent .= "invalid_folder = Folder tidak valid.`n"
    idContent .= "select_vlc = Pilih file vlc.exe`n"
    idContent .= "must_select_vlc = Anda harus memilih vlc.exe.`n"
    idContent .= "incorrect_file = File tidak benar.`n"
    idContent .= "music_folders_title = Folder Musik`n"
    idContent .= "music_folders_label = Folder musik:`n"
    idContent .= "add_folder = + Tambah`n"
    idContent .= "change_folder_btn = Ubah`n"
    idContent .= "remove_folder = Hapus`n"
    idContent .= "select_music_folder_dir = Pilih folder musik`n"
    idContent .= "select_new_location = Pilih lokasi baru`n"
    idContent .= "must_keep_one_folder = Anda harus menyimpan setidaknya satu folder musik.`n"
    idContent .= "add_folder_recursive = + Tambah dengan subfolder`n"
    idContent .= "tray_tip_start = Magic Jukebox ada di sini, berjalan di latar belakang`n"
    idContent .= "`n"
    idContent .= "[Search]`n"
    idContent .= "search_title = Cari lagu`n"
    idContent .= "no_music_folder = Tidak ada folder musik yang ditentukan.``nAtur terlebih dahulu.`n"
    idContent .= "no_songs_found = Tidak ada lagu ditemukan di folder saat ini.`n"
    idContent .= "`n"
    idContent .= "[Playlist]`n"
    idContent .= "playlist_title = Manajer Daftar Putar`n"
    idContent .= "reorder_title_playlists = Manajer Daftar Putar (Mengatur urutan baru)`n"
    idContent .= "reorder_title_songs = Manajer Daftar Putar (Mengatur urutan {1})`n"
    idContent .= "search_song = Cari lagu:`n"
    idContent .= "playlists = Daftar putar:`n"
    idContent .= "playlist_songs = Lagu dalam daftar putar:`n"
    idContent .= "play = ▶ Putar`n"
    idContent .= "remove = ➖ Keluarkan`n"
    idContent .= "delete = 🗑 Hapus`n"
    idContent .= "create_playlist = ➕ Buat daftar putar`n"
    idContent .= "play_all = ▶ Putar semua daftar putar`n"
    idContent .= "loop_on = Ulangi: AKTIF`n"
    idContent .= "loop_off = Ulangi: NONAKTIF`n"
    idContent .= "random_on = Acak: AKTIF`n"
    idContent .= "random_off = Acak: NONAKTIF`n"
    idContent .= "reorder_instructions = Untuk mengubah urutan putar, klik dua kali lagu atau daftar putar.`n"
    idContent .= "reorder_playlists_instructions = Pilih daftar putar dan gunakan Naik / Turun untuk memindahkannya.`n"
    idContent .= "reorder_songs_instructions = Pilih lagu dan gunakan Naik / Turun untuk memindahkannya.`n"
    idContent .= "move_up = ▲ Naik`n"
    idContent .= "move_down = ▼ Turun`n"
    idContent .= "exit_reorder = ✖ Keluar dari mode edit`n"
    idContent .= "new_playlist_title = Buat daftar putar`n"
    idContent .= "new_playlist_label = Nama daftar putar baru:`n"
    idContent .= "create = Buat`n"
    idContent .= "cancel = Batal`n"
    idContent .= "name_empty = Nama tidak boleh kosong.`n"
    idContent .= "name_exists = Daftar putar dengan nama itu sudah ada.`n"
    idContent .= "confirm_delete = Apakah Anda yakin ingin menghapus daftar putar ini?`n"
    idContent .= "confirm_delete_title = Konfirmasi`n"
    idContent .= "select_playlist_first = Pilih atau buat daftar putar terlebih dahulu.`n"
    idContent .= "`n"
    idContent .= "[MiniPlayer]`n"
    idContent .= "artist = Artis`n"
    idContent .= "album = Album`n"
    idContent .= "title = Judul`n"
    idContent .= "`n"
    idContent .= "[Language]`n"
    idContent .= "language_title = Pilih bahasa`n"
    idContent .= "`n"
    try FileDelete(langDir  "\id-lang.ini")
    FileAppend(idContent, langDir "\id-lang.ini", "UTF-8")

    ; ===== SW =====
    swContent := ""
    swContent .= "[General]`n"
    swContent .= "app_name = Magic Jukebox`n"
    swContent .= "playing = Inacheza:`n"
    swContent .= "`n"
    swContent .= "[Tray]`n"
    swContent .= "search_song = Tafuta wimbo`n"
    swContent .= "playlist_manager = Orodha ya nyimbo`n"
    swContent .= "open_miniplayer = Fungua kichezaji kidogo`n"
    swContent .= "auto_mode_on = Hali ya kiotomatiki [Imewashwa]`n"
    swContent .= "auto_mode_off = Hali ya kiotomatiki [Imezimwa]`n"
    swContent .= "pause_resume = Simamisha / Endelea`n"
    swContent .= "repeat_song = Rudia wimbo`n"
    swContent .= "change_music_folder = Badilisha folda ya muziki`n"
    swContent .= "change_vlc = Badilisha VLC.exe`n"
    swContent .= "assign_hotkeys = Weka vitufe vya mkato`n"
    swContent .= "change_language = Badilisha lugha`n"
    swContent .= "return_normal_mode = Rudi hali ya kawaida`n"
    swContent .= "quit = Toka`n"
    swContent .= "`n"
    swContent .= "[Hotkeys]`n"
    swContent .= "prev_song = Wimbo uliopita`n"
    swContent .= "next_song = Wimbo unaofuata`n"
    swContent .= "search_song = Tafuta wimbo`n"
    swContent .= "pause_resume = Simamisha / Endelea`n"
    swContent .= "repeat_song = Rudia wimbo`n"
    swContent .= "playlist = Orodha ya nyimbo`n"
    swContent .= "guide = Mwongozo`n"
    swContent .= "update_hotkeys = Sasisha vitufe vya mkato`n"
    swContent .= "hotkeys_updated = Vitufe vya mkato vimesasishwa.`n"
    swContent .= "invalid_hotkey = Kitufe cha mkato cha '{1}' si sahihi.``nSahihisha thamani na ujaribu tena.`n"
    swContent .= "guide_text = Muundo: Kibonyezi+Ufunguo``n``nVibonyezi sahihi:``n  Ctrl, Alt, Shift, Win``n``nMifano:``n  Ctrl+9``n  Alt+F1``n  Ctrl+Shift+P``n  Win+R``n``nUnaweza pia kuweka funguo moja``ningawa haipendekezwi (mfano F9).``n``nKwa Numpad: Ctrl+Numpad9``nKumbuka kuwasha Num Lock ukitumia Numpad.`n"
    swContent .= "`n"
    swContent .= "[Setup]`n"
    swContent .= "select_music_folder = Chagua folda yako ya muziki`n"
    swContent .= "must_select_folder = Lazima uchague folda ya muziki kuendelea.`n"
    swContent .= "invalid_folder = Folda si sahihi.`n"
    swContent .= "select_vlc = Chagua faili la vlc.exe`n"
    swContent .= "must_select_vlc = Lazima uchague vlc.exe.`n"
    swContent .= "incorrect_file = Faili si sahihi.`n"
    swContent .= "music_folders_title = Folda za Muziki`n"
    swContent .= "music_folders_label = Folda za muziki:`n"
    swContent .= "add_folder = + Ongeza`n"
    swContent .= "change_folder_btn = Badilisha`n"
    swContent .= "remove_folder = Ondoa`n"
    swContent .= "select_music_folder_dir = Chagua folda ya muziki`n"
    swContent .= "select_new_location = Chagua mahali mpya`n"
    swContent .= "must_keep_one_folder = Lazima uhifadhi angalau folda moja ya muziki.`n"
    swContent .= "add_folder_recursive = + Ongeza na folda ndogo`n"
    swContent .= "tray_tip_start = Magic Jukebox ipo hapa, inafanya kazi chinichini`n"
    swContent .= "`n"
    swContent .= "[Search]`n"
    swContent .= "search_title = Tafuta wimbo`n"
    swContent .= "no_music_folder = Hakuna folda ya muziki iliyowekwa.``nIweke kwanza.`n"
    swContent .= "no_songs_found = Hakuna nyimbo zilizopatikana kwenye folda ya sasa.`n"
    swContent .= "`n"
    swContent .= "[Playlist]`n"
    swContent .= "playlist_title = Msimamizi wa Orodha`n"
    swContent .= "reorder_title_playlists = Msimamizi wa Orodha (Kuweka mpangilio mpya)`n"
    swContent .= "reorder_title_songs = Msimamizi wa Orodha (Kuweka mpangilio wa {1})`n"
    swContent .= "search_song = Tafuta wimbo:`n"
    swContent .= "playlists = Orodha za nyimbo:`n"
    swContent .= "playlist_songs = Nyimbo za orodha:`n"
    swContent .= "play = ▶ Cheza`n"
    swContent .= "remove = ➖ Ondoa`n"
    swContent .= "delete = 🗑 Futa`n"
    swContent .= "create_playlist = ➕ Unda orodha ya nyimbo`n"
    swContent .= "play_all = ▶ Cheza orodha zote`n"
    swContent .= "loop_on = Rudia: IMEWASHWA`n"
    swContent .= "loop_off = Rudia: IMEZIMWA`n"
    swContent .= "random_on = Nasibu: IMEWASHWA`n"
    swContent .= "random_off = Nasibu: IMEZIMWA`n"
    swContent .= "reorder_instructions = Bonyeza mara mbili wimbo au orodha kubadilisha mpangilio.`n"
    swContent .= "reorder_playlists_instructions = Chagua orodha na utumie Juu / Chini kuihamisha.`n"
    swContent .= "reorder_songs_instructions = Chagua wimbo na utumie Juu / Chini kuuhamisha.`n"
    swContent .= "move_up = ▲ Juu`n"
    swContent .= "move_down = ▼ Chini`n"
    swContent .= "exit_reorder = ✖ Toka hali ya uhariri`n"
    swContent .= "new_playlist_title = Unda orodha ya nyimbo`n"
    swContent .= "new_playlist_label = Jina la orodha mpya:`n"
    swContent .= "create = Unda`n"
    swContent .= "cancel = Ghairi`n"
    swContent .= "name_empty = Jina haliwezi kuwa tupu.`n"
    swContent .= "name_exists = Orodha yenye jina hilo tayari ipo.`n"
    swContent .= "confirm_delete = Una uhakika unataka kufuta orodha hii?`n"
    swContent .= "confirm_delete_title = Thibitisha`n"
    swContent .= "select_playlist_first = Chagua au unda orodha kwanza.`n"
    swContent .= "`n"
    swContent .= "[MiniPlayer]`n"
    swContent .= "artist = Msanii`n"
    swContent .= "album = Albamu`n"
    swContent .= "title = Kichwa`n"
    swContent .= "`n"
    swContent .= "[Language]`n"
    swContent .= "language_title = Chagua lugha`n"
    swContent .= "`n"
    try FileDelete(langDir  "\sw-lang.ini")
    FileAppend(swContent, langDir "\sw-lang.ini", "UTF-8")

    ; ===== VI =====
    viContent := ""
    viContent .= "[General]`n"
    viContent .= "app_name = Magic Jukebox`n"
    viContent .= "playing = Đang phát:`n"
    viContent .= "`n"
    viContent .= "[Tray]`n"
    viContent .= "search_song = Tìm bài hát`n"
    viContent .= "playlist_manager = Danh sách phát`n"
    viContent .= "open_miniplayer = Mở trình phát mini`n"
    viContent .= "auto_mode_on = Chế độ tự động [Bật]`n"
    viContent .= "auto_mode_off = Chế độ tự động [Tắt]`n"
    viContent .= "pause_resume = Tạm dừng / Tiếp tục`n"
    viContent .= "repeat_song = Lặp lại bài hát`n"
    viContent .= "change_music_folder = Thay đổi thư mục nhạc`n"
    viContent .= "change_vlc = Thay đổi VLC.exe`n"
    viContent .= "assign_hotkeys = Gán phím tắt`n"
    viContent .= "change_language = Đổi ngôn ngữ`n"
    viContent .= "return_normal_mode = Quay lại chế độ bình thường`n"
    viContent .= "quit = Thoát`n"
    viContent .= "`n"
    viContent .= "[Hotkeys]`n"
    viContent .= "prev_song = Bài hát trước`n"
    viContent .= "next_song = Bài hát tiếp theo`n"
    viContent .= "search_song = Tìm bài hát`n"
    viContent .= "pause_resume = Tạm dừng / Tiếp tục`n"
    viContent .= "repeat_song = Lặp lại bài hát`n"
    viContent .= "playlist = Danh sách phát`n"
    viContent .= "guide = Hướng dẫn`n"
    viContent .= "update_hotkeys = Cập nhật phím tắt`n"
    viContent .= "hotkeys_updated = Phím tắt đã được cập nhật thành công.`n"
    viContent .= "invalid_hotkey = Phím tắt cho '{1}' không hợp lệ.``nSửa giá trị và thử lại.`n"
    viContent .= "guide_text = Định dạng: Phím bổ trợ+Phím``n``nPhím bổ trợ hợp lệ:``n  Ctrl, Alt, Shift, Win``n``nVí dụ:``n  Ctrl+9``n  Alt+F1``n  Ctrl+Shift+P``n  Win+R``n``nBạn cũng có thể gán phím đơn``nmặc dù không được khuyến nghị (ví dụ F9).``n``nCho Numpad: Ctrl+Numpad9``nNhớ bật Num Lock nếu dùng Numpad.`n"
    viContent .= "`n"
    viContent .= "[Setup]`n"
    viContent .= "select_music_folder = Chọn thư mục nhạc của bạn`n"
    viContent .= "must_select_folder = Bạn phải chọn thư mục nhạc để tiếp tục.`n"
    viContent .= "invalid_folder = Thư mục không hợp lệ.`n"
    viContent .= "select_vlc = Chọn tệp vlc.exe`n"
    viContent .= "must_select_vlc = Bạn phải chọn vlc.exe.`n"
    viContent .= "incorrect_file = Tệp không đúng.`n"
    viContent .= "music_folders_title = Thư mục nhạc`n"
    viContent .= "music_folders_label = Thư mục nhạc:`n"
    viContent .= "add_folder = + Thêm`n"
    viContent .= "change_folder_btn = Thay đổi`n"
    viContent .= "remove_folder = Xóa`n"
    viContent .= "select_music_folder_dir = Chọn thư mục nhạc`n"
    viContent .= "select_new_location = Chọn vị trí mới`n"
    viContent .= "must_keep_one_folder = Bạn phải giữ ít nhất một thư mục nhạc.`n"
    viContent .= "add_folder_recursive = + Thêm kèm thư mục con`n"
    viContent .= "tray_tip_start = Magic Jukebox đang ở đây, chạy nền`n"
    viContent .= "`n"
    viContent .= "[Search]`n"
    viContent .= "search_title = Tìm bài hát`n"
    viContent .= "no_music_folder = Chưa có thư mục nhạc nào được chỉ định.``nHãy thiết lập trước.`n"
    viContent .= "no_songs_found = Không tìm thấy bài hát nào trong thư mục hiện tại.`n"
    viContent .= "`n"
    viContent .= "[Playlist]`n"
    viContent .= "playlist_title = Trình quản lý danh sách phát`n"
    viContent .= "reorder_title_playlists = Trình quản lý danh sách phát (Đang đặt thứ tự mới)`n"
    viContent .= "reorder_title_songs = Trình quản lý danh sách phát (Đang đặt thứ tự của {1})`n"
    viContent .= "search_song = Tìm bài hát:`n"
    viContent .= "playlists = Danh sách phát:`n"
    viContent .= "playlist_songs = Bài hát trong danh sách:`n"
    viContent .= "play = ▶ Phát`n"
    viContent .= "remove = ➖ Bỏ qua`n"
    viContent .= "delete = 🗑 Xóa`n"
    viContent .= "create_playlist = ➕ Tạo danh sách phát`n"
    viContent .= "play_all = ▶ Phát tất cả danh sách`n"
    viContent .= "loop_on = Lặp: BẬT`n"
    viContent .= "loop_off = Lặp: TẮT`n"
    viContent .= "random_on = Ngẫu nhiên: BẬT`n"
    viContent .= "random_off = Ngẫu nhiên: TẮT`n"
    viContent .= "reorder_instructions = Để thay đổi thứ tự phát, nhấp đúp vào bài hát hoặc danh sách phát.`n"
    viContent .= "reorder_playlists_instructions = Chọn danh sách phát và dùng Lên / Xuống để di chuyển.`n"
    viContent .= "reorder_songs_instructions = Chọn bài hát và dùng Lên / Xuống để di chuyển.`n"
    viContent .= "move_up = ▲ Lên`n"
    viContent .= "move_down = ▼ Xuống`n"
    viContent .= "exit_reorder = ✖ Thoát chế độ chỉnh sửa`n"
    viContent .= "new_playlist_title = Tạo danh sách phát`n"
    viContent .= "new_playlist_label = Tên danh sách phát mới:`n"
    viContent .= "create = Tạo`n"
    viContent .= "cancel = Hủy`n"
    viContent .= "name_empty = Tên không được để trống.`n"
    viContent .= "name_exists = Đã có danh sách phát với tên đó.`n"
    viContent .= "confirm_delete = Bạn có chắc muốn xóa danh sách phát này?`n"
    viContent .= "confirm_delete_title = Xác nhận`n"
    viContent .= "select_playlist_first = Hãy chọn hoặc tạo danh sách phát trước.`n"
    viContent .= "`n"
    viContent .= "[MiniPlayer]`n"
    viContent .= "artist = Nghệ sĩ`n"
    viContent .= "album = Album`n"
    viContent .= "title = Tiêu đề`n"
    viContent .= "`n"
    viContent .= "[Language]`n"
    viContent .= "language_title = Chọn ngôn ngữ`n"
    viContent .= "`n"
    try FileDelete(langDir  "\vi-lang.ini")
    FileAppend(viContent, langDir "\vi-lang.ini", "UTF-8")

    ; ===== TH =====
    thContent := ""
    thContent .= "[General]`n"
    thContent .= "app_name = Magic Jukebox`n"
    thContent .= "playing = กำลังเล่น:`n"
    thContent .= "`n"
    thContent .= "[Tray]`n"
    thContent .= "search_song = ค้นหาเพลง`n"
    thContent .= "playlist_manager = เพลย์ลิสต์`n"
    thContent .= "open_miniplayer = เปิดมินิเพลเยอร์`n"
    thContent .= "auto_mode_on = โหมดอัตโนมัติ [เปิด]`n"
    thContent .= "auto_mode_off = โหมดอัตโนมัติ [ปิด]`n"
    thContent .= "pause_resume = หยุดชั่วคราว / เล่นต่อ`n"
    thContent .= "repeat_song = เล่นซ้ำ`n"
    thContent .= "change_music_folder = เปลี่ยนโฟลเดอร์เพลง`n"
    thContent .= "change_vlc = เปลี่ยน VLC.exe`n"
    thContent .= "assign_hotkeys = กำหนดปุ่มลัด`n"
    thContent .= "change_language = เปลี่ยนภาษา`n"
    thContent .= "return_normal_mode = กลับสู่โหมดปกติ`n"
    thContent .= "quit = ออก`n"
    thContent .= "`n"
    thContent .= "[Hotkeys]`n"
    thContent .= "prev_song = เพลงก่อนหน้า`n"
    thContent .= "next_song = เพลงถัดไป`n"
    thContent .= "search_song = ค้นหาเพลง`n"
    thContent .= "pause_resume = หยุดชั่วคราว / เล่นต่อ`n"
    thContent .= "repeat_song = เล่นซ้ำ`n"
    thContent .= "playlist = เพลย์ลิสต์`n"
    thContent .= "guide = คู่มือ`n"
    thContent .= "update_hotkeys = อัปเดตปุ่มลัด`n"
    thContent .= "hotkeys_updated = อัปเดตปุ่มลัดสำเร็จแล้ว`n"
    thContent .= "invalid_hotkey = ปุ่มลัดสำหรับ '{1}' ไม่ถูกต้อง``nแก้ไขค่าแล้วลองอีกครั้ง`n"
    thContent .= "guide_text = รูปแบบ: ตัวปรับ+ปุ่ม``n``nตัวปรับที่ใช้ได้:``n  Ctrl, Alt, Shift, Win``n``nตัวอย่าง:``n  Ctrl+9``n  Alt+F1``n  Ctrl+Shift+P``n  Win+R``n``nสามารถกำหนดปุ่มเดี่ยวได้``nแต่ไม่แนะนำ (เช่น F9)``n``nสำหรับ Numpad: Ctrl+Numpad9``nอย่าลืมเปิด Num Lock หากใช้ Numpad`n"
    thContent .= "`n"
    thContent .= "[Setup]`n"
    thContent .= "select_music_folder = เลือกโฟลเดอร์เพลงของคุณ`n"
    thContent .= "must_select_folder = คุณต้องเลือกโฟลเดอร์เพลงเพื่อดำเนินการต่อ`n"
    thContent .= "invalid_folder = โฟลเดอร์ไม่ถูกต้อง`n"
    thContent .= "select_vlc = เลือกไฟล์ vlc.exe`n"
    thContent .= "must_select_vlc = คุณต้องเลือก vlc.exe`n"
    thContent .= "incorrect_file = ไฟล์ไม่ถูกต้อง`n"
    thContent .= "music_folders_title = โฟลเดอร์เพลง`n"
    thContent .= "music_folders_label = โฟลเดอร์เพลง:`n"
    thContent .= "add_folder = + เพิ่ม`n"
    thContent .= "change_folder_btn = เปลี่ยน`n"
    thContent .= "remove_folder = ลบ`n"
    thContent .= "select_music_folder_dir = เลือกโฟลเดอร์เพลง`n"
    thContent .= "select_new_location = เลือกตำแหน่งใหม่`n"
    thContent .= "must_keep_one_folder = คุณต้องเก็บโฟลเดอร์เพลงไว้อย่างน้อยหนึ่งโฟลเดอร์`n"
    thContent .= "add_folder_recursive = + เพิ่มพร้อมโฟลเดอร์ย่อย`n"
    thContent .= "tray_tip_start = Magic Jukebox อยู่ที่นี่ ทำงานอยู่เบื้องหลัง`n"
    thContent .= "`n"
    thContent .= "[Search]`n"
    thContent .= "search_title = ค้นหาเพลง`n"
    thContent .= "no_music_folder = ยังไม่ได้กำหนดโฟลเดอร์เพลง``nกรุณาตั้งค่าก่อน`n"
    thContent .= "no_songs_found = ไม่พบเพลงในโฟลเดอร์ปัจจุบัน`n"
    thContent .= "`n"
    thContent .= "[Playlist]`n"
    thContent .= "playlist_title = จัดการเพลย์ลิสต์`n"
    thContent .= "reorder_title_playlists = จัดการเพลย์ลิสต์ (กำลังกำหนดลำดับใหม่)`n"
    thContent .= "reorder_title_songs = จัดการเพลย์ลิสต์ (กำลังกำหนดลำดับของ {1})`n"
    thContent .= "search_song = ค้นหาเพลง:`n"
    thContent .= "playlists = เพลย์ลิสต์:`n"
    thContent .= "playlist_songs = เพลงในเพลย์ลิสต์:`n"
    thContent .= "play = ▶ เล่น`n"
    thContent .= "remove = ➖ ลบออก`n"
    thContent .= "delete = 🗑 ลบถาวร`n"
    thContent .= "create_playlist = ➕ สร้างเพลย์ลิสต์`n"
    thContent .= "play_all = ▶ เล่นทุกเพลย์ลิสต์`n"
    thContent .= "loop_on = วนซ้ำ: เปิด`n"
    thContent .= "loop_off = วนซ้ำ: ปิด`n"
    thContent .= "random_on = สุ่ม: เปิด`n"
    thContent .= "random_off = สุ่ม: ปิด`n"
    thContent .= "reorder_instructions = ดับเบิลคลิกที่เพลงหรือเพลย์ลิสต์เพื่อเปลี่ยนลำดับการเล่น`n"
    thContent .= "reorder_playlists_instructions = เลือกเพลย์ลิสต์แล้วใช้ขึ้น / ลงเพื่อย้าย`n"
    thContent .= "reorder_songs_instructions = เลือกเพลงแล้วใช้ขึ้น / ลงเพื่อย้าย`n"
    thContent .= "move_up = ▲ ขึ้น`n"
    thContent .= "move_down = ▼ ลง`n"
    thContent .= "exit_reorder = ✖ ออกจากโหมดแก้ไข`n"
    thContent .= "new_playlist_title = สร้างเพลย์ลิสต์`n"
    thContent .= "new_playlist_label = ชื่อเพลย์ลิสต์ใหม่:`n"
    thContent .= "create = สร้าง`n"
    thContent .= "cancel = ยกเลิก`n"
    thContent .= "name_empty = ชื่อต้องไม่ว่างเปล่า`n"
    thContent .= "name_exists = มีเพลย์ลิสต์ชื่อนี้อยู่แล้ว`n"
    thContent .= "confirm_delete = คุณแน่ใจหรือไม่ว่าต้องการลบเพลย์ลิสต์นี้?`n"
    thContent .= "confirm_delete_title = ยืนยัน`n"
    thContent .= "select_playlist_first = กรุณาเลือกหรือสร้างเพลย์ลิสต์ก่อน`n"
    thContent .= "`n"
    thContent .= "[MiniPlayer]`n"
    thContent .= "artist = ศิลปิน`n"
    thContent .= "album = อัลบั้ม`n"
    thContent .= "title = ชื่อเพลง`n"
    thContent .= "`n"
    thContent .= "[Language]`n"
    thContent .= "language_title = เลือกภาษา`n"
    thContent .= "`n"
    try FileDelete(langDir  "\th-lang.ini")
    FileAppend(thContent, langDir "\th-lang.ini", "UTF-8")

    ; ===== UK =====
    ukContent := ""
    ukContent .= "[General]`n"
    ukContent .= "app_name = Magic Jukebox`n"
    ukContent .= "playing = Відтворення:`n"
    ukContent .= "`n"
    ukContent .= "[Tray]`n"
    ukContent .= "search_song = Знайти пісню`n"
    ukContent .= "playlist_manager = Список відтворення`n"
    ukContent .= "open_miniplayer = Відкрити міні-плеєр`n"
    ukContent .= "auto_mode_on = Автоматичний режим [Увімк]`n"
    ukContent .= "auto_mode_off = Автоматичний режим [Вимк]`n"
    ukContent .= "pause_resume = Пауза / Продовжити`n"
    ukContent .= "repeat_song = Повторити пісню`n"
    ukContent .= "change_music_folder = Змінити папку музики`n"
    ukContent .= "change_vlc = Змінити VLC.exe`n"
    ukContent .= "assign_hotkeys = Призначити гарячі клавіші`n"
    ukContent .= "change_language = Змінити мову`n"
    ukContent .= "return_normal_mode = Повернутися до звичайного режиму`n"
    ukContent .= "quit = Вихід`n"
    ukContent .= "`n"
    ukContent .= "[Hotkeys]`n"
    ukContent .= "prev_song = Попередня пісня`n"
    ukContent .= "next_song = Наступна пісня`n"
    ukContent .= "search_song = Знайти пісню`n"
    ukContent .= "pause_resume = Пауза / Продовжити`n"
    ukContent .= "repeat_song = Повторити пісню`n"
    ukContent .= "playlist = Список відтворення`n"
    ukContent .= "guide = Посібник`n"
    ukContent .= "update_hotkeys = Оновити гарячі клавіші`n"
    ukContent .= "hotkeys_updated = Гарячі клавіші успішно оновлено.`n"
    ukContent .= "invalid_hotkey = Гаряча клавіша для '{1}' недійсна.``nВиправте значення і спробуйте знову.`n"
    ukContent .= "guide_text = Формат: Модифікатор+Клавіша``n``nДопустимі модифікатори:``n  Ctrl, Alt, Shift, Win``n``nПриклади:``n  Ctrl+9``n  Alt+F1``n  Ctrl+Shift+P``n  Win+R``n``nМожна також призначити окремі клавіші,``nхоча це не рекомендується (напр. F9).``n``nДля цифрової клавіатури: Ctrl+Numpad9``nНе забудьте ввімкнути Num Lock.`n"
    ukContent .= "`n"
    ukContent .= "[Setup]`n"
    ukContent .= "select_music_folder = Виберіть папку з музикою`n"
    ukContent .= "must_select_folder = Необхідно вибрати папку з музикою для продовження.`n"
    ukContent .= "invalid_folder = Недійсна папка.`n"
    ukContent .= "select_vlc = Виберіть файл vlc.exe`n"
    ukContent .= "must_select_vlc = Необхідно вибрати vlc.exe.`n"
    ukContent .= "incorrect_file = Неправильний файл.`n"
    ukContent .= "music_folders_title = Папки з музикою`n"
    ukContent .= "music_folders_label = Папки з музикою:`n"
    ukContent .= "add_folder = + Додати`n"
    ukContent .= "change_folder_btn = Змінити`n"
    ukContent .= "remove_folder = Видалити`n"
    ukContent .= "select_music_folder_dir = Виберіть папку з музикою`n"
    ukContent .= "select_new_location = Виберіть нове розташування`n"
    ukContent .= "must_keep_one_folder = Необхідно зберегти принаймні одну папку з музикою.`n"
    ukContent .= "add_folder_recursive = + Додати з підпапками`n"
    ukContent .= "tray_tip_start = Magic Jukebox тут, працює у фоновому режимі`n"
    ukContent .= "`n"
    ukContent .= "[Search]`n"
    ukContent .= "search_title = Знайти пісню`n"
    ukContent .= "no_music_folder = Папку з музикою не призначено.``nСпочатку налаштуйте її.`n"
    ukContent .= "no_songs_found = Пісні в поточній папці не знайдено.`n"
    ukContent .= "`n"
    ukContent .= "[Playlist]`n"
    ukContent .= "playlist_title = Менеджер плейлистів`n"
    ukContent .= "reorder_title_playlists = Менеджер плейлистів (Встановлення нового порядку)`n"
    ukContent .= "reorder_title_songs = Менеджер плейлистів (Встановлення порядку {1})`n"
    ukContent .= "search_song = Знайти пісню:`n"
    ukContent .= "playlists = Плейлисти:`n"
    ukContent .= "playlist_songs = Пісні плейлиста:`n"
    ukContent .= "play = ▶ Відтворити`n"
    ukContent .= "remove = ➖ Видалити`n"
    ukContent .= "delete = 🗑 Стерти`n"
    ukContent .= "create_playlist = ➕ Створити плейлист`n"
    ukContent .= "play_all = ▶ Відтворити всі плейлисти`n"
    ukContent .= "loop_on = Повтор: УВІМК`n"
    ukContent .= "loop_off = Повтор: ВИМК`n"
    ukContent .= "random_on = Випадково: УВІМК`n"
    ukContent .= "random_off = Випадково: ВИМК`n"
    ukContent .= "reorder_instructions = Для зміни порядку відтворення двічі клацніть пісню або плейлист.`n"
    ukContent .= "reorder_playlists_instructions = Виберіть плейлист і використовуйте Вгору / Вниз для переміщення.`n"
    ukContent .= "reorder_songs_instructions = Виберіть пісню і використовуйте Вгору / Вниз для переміщення.`n"
    ukContent .= "move_up = ▲ Вгору`n"
    ukContent .= "move_down = ▼ Вниз`n"
    ukContent .= "exit_reorder = ✖ Вийти з режиму редагування`n"
    ukContent .= "new_playlist_title = Створити плейлист`n"
    ukContent .= "new_playlist_label = Назва нового плейлиста:`n"
    ukContent .= "create = Створити`n"
    ukContent .= "cancel = Скасувати`n"
    ukContent .= "name_empty = Назва не може бути порожньою.`n"
    ukContent .= "name_exists = Плейлист з такою назвою вже існує.`n"
    ukContent .= "confirm_delete = Ви впевнені, що хочете видалити цей плейлист?`n"
    ukContent .= "confirm_delete_title = Підтвердити`n"
    ukContent .= "select_playlist_first = Спочатку виберіть або створіть плейлист.`n"
    ukContent .= "`n"
    ukContent .= "[MiniPlayer]`n"
    ukContent .= "artist = Виконавець`n"
    ukContent .= "album = Альбом`n"
    ukContent .= "title = Назва`n"
    ukContent .= "`n"
    ukContent .= "[Language]`n"
    ukContent .= "language_title = Вибір мови`n"
    ukContent .= "`n"
    try FileDelete(langDir  "\uk-lang.ini")
    FileAppend(ukContent, langDir "\uk-lang.ini", "UTF-8")

    ; ===== FA =====
    faContent := ""
    faContent .= "[General]`n"
    faContent .= "app_name = Magic Jukebox`n"
    faContent .= "playing = در حال پخش:`n"
    faContent .= "`n"
    faContent .= "[Tray]`n"
    faContent .= "search_song = جستجوی آهنگ`n"
    faContent .= "playlist_manager = فهرست پخش`n"
    faContent .= "open_miniplayer = باز کردن مینی‌پلیر`n"
    faContent .= "auto_mode_on = حالت خودکار [روشن]`n"
    faContent .= "auto_mode_off = حالت خودکار [خاموش]`n"
    faContent .= "pause_resume = مکث / ادامه`n"
    faContent .= "repeat_song = تکرار آهنگ`n"
    faContent .= "change_music_folder = تغییر پوشه موسیقی`n"
    faContent .= "change_vlc = تغییر VLC.exe`n"
    faContent .= "assign_hotkeys = تعیین کلیدهای میانبر`n"
    faContent .= "change_language = تغییر زبان`n"
    faContent .= "return_normal_mode = بازگشت به حالت عادی`n"
    faContent .= "quit = خروج`n"
    faContent .= "`n"
    faContent .= "[Hotkeys]`n"
    faContent .= "prev_song = آهنگ قبلی`n"
    faContent .= "next_song = آهنگ بعدی`n"
    faContent .= "search_song = جستجوی آهنگ`n"
    faContent .= "pause_resume = مکث / ادامه`n"
    faContent .= "repeat_song = تکرار آهنگ`n"
    faContent .= "playlist = فهرست پخش`n"
    faContent .= "guide = راهنما`n"
    faContent .= "update_hotkeys = به‌روزرسانی میانبرها`n"
    faContent .= "hotkeys_updated = میانبرها با موفقیت به‌روز شدند.`n"
    faContent .= "invalid_hotkey = میانبر '{1}' معتبر نیست.``nمقدار را اصلاح کنید و دوباره امتحان کنید.`n"
    faContent .= "guide_text = قالب: تغییردهنده+کلید``n``nتغییردهنده‌های معتبر:``n  Ctrl, Alt, Shift, Win``n``nمثال‌ها:``n  Ctrl+9``n  Alt+F1``n  Ctrl+Shift+P``n  Win+R``n``nمی‌توانید کلیدهای تکی هم تعیین کنید``nاگرچه توصیه نمی‌شود (مثلاً F9).``n``nبرای Numpad: Ctrl+Numpad9``nفراموش نکنید Num Lock را فعال کنید.`n"
    faContent .= "`n"
    faContent .= "[Setup]`n"
    faContent .= "select_music_folder = پوشه موسیقی خود را انتخاب کنید`n"
    faContent .= "must_select_folder = برای ادامه باید یک پوشه موسیقی انتخاب کنید.`n"
    faContent .= "invalid_folder = پوشه نامعتبر است.`n"
    faContent .= "select_vlc = فایل vlc.exe را انتخاب کنید`n"
    faContent .= "must_select_vlc = باید vlc.exe را انتخاب کنید.`n"
    faContent .= "incorrect_file = فایل اشتباه است.`n"
    faContent .= "music_folders_title = پوشه‌های موسیقی`n"
    faContent .= "music_folders_label = پوشه‌های موسیقی:`n"
    faContent .= "add_folder = + افزودن`n"
    faContent .= "change_folder_btn = تغییر`n"
    faContent .= "remove_folder = حذف`n"
    faContent .= "select_music_folder_dir = پوشه موسیقی را انتخاب کنید`n"
    faContent .= "select_new_location = مکان جدید را انتخاب کنید`n"
    faContent .= "must_keep_one_folder = باید حداقل یک پوشه موسیقی نگه دارید.`n"
    faContent .= "add_folder_recursive = + افزودن با زیرپوشه‌ها`n"
    faContent .= "tray_tip_start = Magic Jukebox اینجاست، در پس‌زمینه در حال اجرا است`n"
    faContent .= "`n"
    faContent .= "[Search]`n"
    faContent .= "search_title = جستجوی آهنگ`n"
    faContent .= "no_music_folder = هیچ پوشه موسیقی‌ای تعیین نشده.``nابتدا آن را تنظیم کنید.`n"
    faContent .= "no_songs_found = هیچ آهنگی در پوشه فعلی یافت نشد.`n"
    faContent .= "`n"
    faContent .= "[Playlist]`n"
    faContent .= "playlist_title = مدیریت فهرست پخش`n"
    faContent .= "reorder_title_playlists = مدیریت فهرست پخش (تعیین ترتیب جدید)`n"
    faContent .= "reorder_title_songs = مدیریت فهرست پخش (تعیین ترتیب {1})`n"
    faContent .= "search_song = جستجوی آهنگ:`n"
    faContent .= "playlists = فهرست‌های پخش:`n"
    faContent .= "playlist_songs = آهنگ‌های فهرست:`n"
    faContent .= "play = ▶ پخش`n"
    faContent .= "remove = ➖ حذف`n"
    faContent .= "delete = 🗑 پاک کردن`n"
    faContent .= "create_playlist = ➕ ایجاد فهرست پخش`n"
    faContent .= "play_all = ▶ پخش همه فهرست‌ها`n"
    faContent .= "loop_on = تکرار: روشن`n"
    faContent .= "loop_off = تکرار: خاموش`n"
    faContent .= "random_on = تصادفی: روشن`n"
    faContent .= "random_off = تصادفی: خاموش`n"
    faContent .= "reorder_instructions = برای تغییر ترتیب پخش، روی آهنگ یا فهرست دوبار کلیک کنید.`n"
    faContent .= "reorder_playlists_instructions = یک فهرست انتخاب کنید و از بالا / پایین برای جابجایی استفاده کنید.`n"
    faContent .= "reorder_songs_instructions = یک آهنگ انتخاب کنید و از بالا / پایین برای جابجایی استفاده کنید.`n"
    faContent .= "move_up = ▲ بالا`n"
    faContent .= "move_down = ▼ پایین`n"
    faContent .= "exit_reorder = ✖ خروج از حالت ویرایش`n"
    faContent .= "new_playlist_title = ایجاد فهرست پخش`n"
    faContent .= "new_playlist_label = نام فهرست پخش جدید:`n"
    faContent .= "create = ایجاد`n"
    faContent .= "cancel = لغو`n"
    faContent .= "name_empty = نام نمی‌تواند خالی باشد.`n"
    faContent .= "name_exists = فهرستی با این نام قبلاً وجود دارد.`n"
    faContent .= "confirm_delete = آیا مطمئنید که می‌خواهید این فهرست را حذف کنید?`n"
    faContent .= "confirm_delete_title = تأیید`n"
    faContent .= "select_playlist_first = ابتدا یک فهرست انتخاب یا ایجاد کنید.`n"
    faContent .= "`n"
    faContent .= "[MiniPlayer]`n"
    faContent .= "artist = هنرمند`n"
    faContent .= "album = آلبوم`n"
    faContent .= "title = عنوان`n"
    faContent .= "`n"
    faContent .= "[Language]`n"
    faContent .= "language_title = انتخاب زبان`n"
    faContent .= "`n"
    try FileDelete(langDir  "\fa-lang.ini")
    FileAppend(faContent, langDir "\fa-lang.ini", "UTF-8")

    ; ===== HA =====
    haContent := ""
    haContent .= "[General]`n"
    haContent .= "app_name = Magic Jukebox`n"
    haContent .= "playing = Ana Kunna:`n"
    haContent .= "`n"
    haContent .= "[Tray]`n"
    haContent .= "search_song = Nemi waƙa`n"
    haContent .= "playlist_manager = Jerin waƙoƙi`n"
    haContent .= "open_miniplayer = Buɗe ƙaramin mai kunna`n"
    haContent .= "auto_mode_on = Yanayin atomatik [A kan]`n"
    haContent .= "auto_mode_off = Yanayin atomatik [A kashe]`n"
    haContent .= "pause_resume = Dakatar / Ci gaba`n"
    haContent .= "repeat_song = Maimaita waƙa`n"
    haContent .= "change_music_folder = Canza babban fayil na kiɗa`n"
    haContent .= "change_vlc = Canza VLC.exe`n"
    haContent .= "assign_hotkeys = Saita maɓallan gajeriyar hanya`n"
    haContent .= "change_language = Canza harshe`n"
    haContent .= "return_normal_mode = Koma yanayin al'ada`n"
    haContent .= "quit = Fita`n"
    haContent .= "`n"
    haContent .= "[Hotkeys]`n"
    haContent .= "prev_song = Waƙar da ta gabata`n"
    haContent .= "next_song = Waƙa ta gaba`n"
    haContent .= "search_song = Nemi waƙa`n"
    haContent .= "pause_resume = Dakatar / Ci gaba`n"
    haContent .= "repeat_song = Maimaita waƙa`n"
    haContent .= "playlist = Jerin waƙoƙi`n"
    haContent .= "guide = Jagora`n"
    haContent .= "update_hotkeys = Sabunta`n"
    haContent .= "hotkeys_updated = An sabunta maɓallan gajeriyar hanya.`n"
    haContent .= "invalid_hotkey = Maɓallin gajeriyar hanya na '{1}' bai dace ba.``nGyara ƙimar kuma sake gwadawa.`n"
    haContent .= "guide_text = Tsari: Mai gyara+Maɓalli``n``nMasu gyara masu inganci:``n  Ctrl, Alt, Shift, Win``n``nMisalai:``n  Ctrl+9``n  Alt+F1``n  Ctrl+Shift+P``n  Win+R``n``nKana iya saita maɓalli ɗaya``nkoda yake ba a ba da shawara ba (misali F9).``n``nGa Numpad: Ctrl+Numpad9``nKa tuna kunna Num Lock idan kana amfani da Numpad.`n"
    haContent .= "`n"
    haContent .= "[Setup]`n"
    haContent .= "select_music_folder = Zaɓi babban fayil ɗinka na kiɗa`n"
    haContent .= "must_select_folder = Dole ne ka zaɓi babban fayil na kiɗa don ci gaba.`n"
    haContent .= "invalid_folder = Babban fayil bai dace ba.`n"
    haContent .= "select_vlc = Zaɓi fayil vlc.exe`n"
    haContent .= "must_select_vlc = Dole ne ka zaɓi vlc.exe.`n"
    haContent .= "incorrect_file = Fayil mara daidai.`n"
    haContent .= "music_folders_title = Fayilolin kiɗa`n"
    haContent .= "music_folders_label = Fayilolin kiɗa:`n"
    haContent .= "add_folder = + Ƙara`n"
    haContent .= "change_folder_btn = Canza`n"
    haContent .= "remove_folder = Cire`n"
    haContent .= "select_music_folder_dir = Zaɓi babban fayil na kiɗa`n"
    haContent .= "select_new_location = Zaɓi sabon wuri`n"
    haContent .= "must_keep_one_folder = Dole ne ka kiyaye aƙalla fayil ɗaya na kiɗa.`n"
    haContent .= "add_folder_recursive = + Ƙara tare da manyan fayiloli`n"
    haContent .= "tray_tip_start = Magic Jukebox yana nan, yana aiki a bango`n"
    haContent .= "`n"
    haContent .= "[Search]`n"
    haContent .= "search_title = Nemi waƙa`n"
    haContent .= "no_music_folder = Ba a saita babban fayil na kiɗa ba.``nSaita shi da farko.`n"
    haContent .= "no_songs_found = Ba a sami waƙoƙi a babban fayil na yanzu ba.`n"
    haContent .= "`n"
    haContent .= "[Playlist]`n"
    haContent .= "playlist_title = Mai Sarrafa Jerin Waƙoƙi`n"
    haContent .= "reorder_title_playlists = Mai Sarrafa Jerin Waƙoƙi (Ana saita sabon tsari)`n"
    haContent .= "reorder_title_songs = Mai Sarrafa Jerin Waƙoƙi (Ana saita tsarin {1})`n"
    haContent .= "search_song = Nemi waƙa:`n"
    haContent .= "playlists = Jerin waƙoƙi:`n"
    haContent .= "playlist_songs = Waƙoƙin jerin:`n"
    haContent .= "play = ▶ Kunna`n"
    haContent .= "remove = ➖ Cire`n"
    haContent .= "delete = 🗑 Goge`n"
    haContent .= "create_playlist = ➕ Ƙirƙiri jerin waƙoƙi`n"
    haContent .= "play_all = ▶ Kunna duk jerin waƙoƙi`n"
    haContent .= "loop_on = Maimaita: A KAN`n"
    haContent .= "loop_off = Maimaita: A KASHE`n"
    haContent .= "random_on = Na bazuwar: A KAN`n"
    haContent .= "random_off = Na bazuwar: A KASHE`n"
    haContent .= "reorder_instructions = Danna sau biyu akan waƙa ko jerin don canza tsarin kunna.`n"
    haContent .= "reorder_playlists_instructions = Zaɓi jerin kuma yi amfani da Sama / Ƙasa don motsa shi.`n"
    haContent .= "reorder_songs_instructions = Zaɓi waƙa kuma yi amfani da Sama / Ƙasa don motsa ta.`n"
    haContent .= "move_up = ▲ Sama`n"
    haContent .= "move_down = ▼ Ƙasa`n"
    haContent .= "exit_reorder = ✖ Fita daga yanayin gyara`n"
    haContent .= "new_playlist_title = Ƙirƙiri jerin waƙoƙi`n"
    haContent .= "new_playlist_label = Sunan sabon jerin:`n"
    haContent .= "create = Ƙirƙira`n"
    haContent .= "cancel = Soke`n"
    haContent .= "name_empty = Sunan ba zai iya zama fanko ba.`n"
    haContent .= "name_exists = Akwai jerin da wannan suna.`n"
    haContent .= "confirm_delete = Shin kana tabbata kana son goge wannan jerin?`n"
    haContent .= "confirm_delete_title = Tabbatar`n"
    haContent .= "select_playlist_first = Da farko zaɓi ko ƙirƙiri jerin.`n"
    haContent .= "`n"
    haContent .= "[MiniPlayer]`n"
    haContent .= "artist = Mai fasaha`n"
    haContent .= "album = Album`n"
    haContent .= "title = Taken waƙa`n"
    haContent .= "`n"
    haContent .= "[Language]`n"
    haContent .= "language_title = Zaɓi harshe`n"
    haContent .= "`n"
    try FileDelete(langDir  "\ha-lang.ini")
    FileAppend(haContent, langDir "\ha-lang.ini", "UTF-8")

}

; ===== CREAR SECCIÓN HOTKEYS SI NO EXISTE =====
if (IniRead(configFile, "Hotkeys", "next_song", "") = "") {

    IniWrite("^NumpadEnter", configFile, "Hotkeys", "next_song")
    IniWrite("^Numpad4",     configFile, "Hotkeys", "search_song")
    IniWrite("^NumpadAdd",   configFile, "Hotkeys", "pause_resume")
    IniWrite("^Numpad0",     configFile, "Hotkeys", "repeat_song")
    IniWrite("^Numpad5",     configFile, "Hotkeys", "playlist")
    IniWrite("^Numpad6",     configFile, "Hotkeys", "miniplayer")
    IniWrite("^NumpadDot",   configFile, "Hotkeys", "prev_song")
    IniWrite("^Numpad2",     configFile, "Hotkeys", "vol_up")
    IniWrite("^Numpad1",     configFile, "Hotkeys", "vol_down")
    IniWrite("^Numpad3",     configFile, "Hotkeys", "mute")

tutorial := "; If you broke something by editing this file, delete it and restart the program.`n"
    . "`n; --- Quick guide ---`n"
    . "; ^ = Ctrl    ! = Alt    + = Shift    # = Win`n"
    . "; --- Examples ---`n"
    . "; ^P = Ctrl+P`n"
    . "; !F1 = Alt+F1`n"
    . "; ^F6 = Ctrl+F6`n"
    . "; +B = Shift+B`n"
    . "; #R = Win+R`n"
    . "; ^Numpad9 = Ctrl+Numpad9`n"
    . "; Avoid assigning single keys`n"
    . "; If using Numpad, remember to enable Num Lock`n"

    FileAppend(tutorial, configFile)
}

; ===== CREAR ARCHIVO PLAYLISTS SI NO EXISTE =====
if !FileExist(playlistsFile) {
    IniWrite("", playlistsFile, "Playlists", "Order")
}

; ====== RECURSOS EMBEBIDOS ======
FileInstall("rocola.wav", tempDir "\rocola.wav", 1)
FileInstall("rocola.ico", tempDir "\rocola.ico", 1)
FileInstall("vinilo1.ico", tempDir "\vinilo1.ico", 1)
FileInstall("vinilo2.ico", tempDir "\vinilo2.ico", 1)
FileInstall("vinilo3.ico", tempDir "\vinilo3.ico", 1)
FileInstall("vinilo4.ico", tempDir "\vinilo4.ico", 1)
FileInstall("MiniPlay1.png", A_Temp "\Rocola\MiniPlay1.png", 1)
FileInstall("MiniPlay2.png", A_Temp "\Rocola\MiniPlay2.png", 1)
FileInstall("MiniPlay3.png", A_Temp "\Rocola\MiniPlay3.png", 1)
FileInstall("MiniPlay4.png", A_Temp "\Rocola\MiniPlay4.png", 1)
FileInstall("volumenalto.png", A_Temp "\Rocola\volumenalto.png", 1)
FileInstall("volumenmedio.png", A_Temp "\Rocola\volumenmedio.png", 1)
FileInstall("pocovolumen.png", A_Temp "\Rocola\pocovolumen.png", 1)
FileInstall("muteado.png", A_Temp "\Rocola\muteado.png", 1)
FileInstall("contornoslider.png", A_Temp "\Rocola\contornoslider.png", 1)
FileInstall("rellenoslider.png", A_Temp "\Rocola\rellenoslider.png", 1)
FileInstall("contornoprogreso.png", A_Temp "\Rocola\contornoprogreso.png", 1)
FileInstall("barraprogreso.png", A_Temp "\Rocola\barraprogreso.png", 1)
FileInstall("contornoprogreso.png", A_Temp "\Rocola\contornoprogreso.png", 1)
FileInstall("barraprogreso.png", A_Temp "\Rocola\barraprogreso.png", 1)
CreateLanguageFiles()

jukeboxSound := tempDir "\rocola.wav"
iconIdle := tempDir "\rocola.ico"

vinylFrames := [
    tempDir "\vinilo1.ico",
    tempDir "\vinilo2.ico",
    tempDir "\vinilo3.ico",
    tempDir "\vinilo4.ico"
]

songs := []
shuffled := []
currentIndex := 0
vlcPID := 0
currentSong := ""
isPlaying := false
isPaused := false
frameIndex := 1
autoMode := (IniRead(configFile, "State", "AutoMode", "1") = "1")
currentPrevKey := ""
currentNextKey := ""
currentSearchKey := ""
currentPauseKey := ""
currentRepeatKey := ""
currentPlaylistKey := ""
currentMiniPlayerKey := ""
isTransitioning := false
repeatLoop := false
shuffledPlaylistPool := []
shuffledPoolIndex := 0
playlistWorkingOrder := []   ; copia de trabajo del orden de playlist (no toca playlists[])
lastFolderTime := ""
vlcRCPort := 54321
L := Map()
currentLang := ""
miniPlayer := 0
miniPlayerShown := false
isWindowMoving  := false
trayTipShown := false
volumeLevel := Integer(IniRead(configFile, "State", "Volume", "100"))
volumeBeforeMute := 100
isMuted := false
imgVolIcon := 0
imgVolContorno := 0
imgVolRelleno  := 0   ; imagen de relleno - su ancho cambia segun el volumen
volDragging    := false

; Estado barra de progreso
imgProgContorno := 0
imgProgBarra    := 0
lblProgCurrent  := 0
lblProgTotal    := 0
; variables de progreso inicializadas en la seccion de funciones
currentVolUpKey := ""
currentVolDownKey := ""
currentMuteKey := ""

; ===== SISTEMA PLAYLIST =====
playMode := "normal"   ; "normal" o "playlist"
playlists := Map()     ; nombre => array de canciones
playlistOrder := []    ; orden visual de playlists
currentPlaylist := ""  ; nombre activo
playlistSongIndex := 0

playlistLoop := (IniRead(configFile, "State", "Loop", "0") = "1")
playlistLoopActive := playlistLoop      ; valor activo durante reproduccion (no cambia con los botones)
playlistAuto := false
playlistRandom := (IniRead(configFile, "State", "Random", "0") = "1")
playlistRandomActive := playlistRandom  ; valor activo durante reproduccion (no cambia con los botones)
isPlaylistMode := false
currentPlaylistGlobalIndex := 0
btnLoop := 0
playlistInsertQueue := []  ; Cola de canciones insertadas por Buscar en modo playlist

; ===== CARGAR IDIOMA =====
savedLang := IniRead(configFile, "General", "Language", "")
if (savedLang = "")
    OpenLanguageSelector()
else
    LoadLanguage(savedLang)

; ===== CARGAR CONFIG =====
vlcPath := IniRead(configFile, "Paths", "VLC", "")

if (IniRead(configFile, "Paths", "MusicFolder1", "") = "")
    SelectMusicFolder()

if (!FileExist(vlcPath) || !InStr(StrLower(vlcPath), "vlc.exe"))
    SelectVLC()

TraySetIcon(iconIdle)
A_IconTip := L["app_name"]

A_TrayMenu.Delete()

RestoreNormalTray()


TrayClick(wParam, lParam, *) {
    if (lParam = 0x202)
        PlayNext()
}

; ================= BUSCADOR =================

OpenSearchWindow(*) {
    global songs, playMode, playlists, currentPlaylist, currentPlaylistGlobalIndex, playlistOrder

    if (GetMusicFolders().Length = 0) {
    MsgBox(L["no_music_folder"])
    return
}

    ; En modo playlist, verificar que haya canciones en la(s) playlist(s) activa(s)
    if (playMode = "playlist") {
        playlistSongs := GetActivePlaylistSongs()
        if (playlistSongs.Length = 0) {
            MsgBox(L["no_songs_found"])
            return
        }
    } else {
        if (songs.Length = 0) {
            MsgBox(L["no_songs_found"])
            return
        }
    }

    searchGui := Gui("+AlwaysOnTop", L["search_title"])
    searchGui.SetFont("s10")

    searchEdit := searchGui.AddEdit("w300 vSearchInput")
    listBox := searchGui.AddListBox("w300 h200 vResults HScroll")

    searchEdit.OnEvent("Change", (*) => FilterSongs(searchEdit, listBox))
    listBox.OnEvent("DoubleClick", (*) => PlaySelectedFromSearch(listBox, searchGui))

    hiddenBtn := searchGui.AddButton("Default Hidden", "OK")
    hiddenBtn.OnEvent("Click", (*) =>
        listBox.Value != 0 ? PlaySelectedFromSearch(listBox, searchGui) : ""
    )

    FilterSongs(searchEdit, listBox)
    searchGui.Show()
}

; Devuelve todas las canciones de la(s) playlist(s) actualmente activa(s)
GetActivePlaylistSongs() {
    global playlists, currentPlaylist, currentPlaylistGlobalIndex, playlistOrder
    result := []
    if (currentPlaylistGlobalIndex > 0) {
        ; Modo "reproducir todas"
        for name in playlistOrder {
            if playlists.Has(name) {
                for song in playlists[name]
                    result.Push(song)
            }
        }
    } else {
        ; Playlist individual
        if playlists.Has(currentPlaylist) {
            for song in playlists[currentPlaylist]
                result.Push(song)
        }
    }
    return result
}

FilterSongs(edit, listBox, forceAllSongs := false) {
    global songs, playMode

    query := StrLower(edit.Value)
    listBox.Delete()

    ; En modo playlist el buscador independiente muestra canciones de la playlist,
    ; pero el buscador del administrador siempre muestra todas las canciones
    sourceList := (!forceAllSongs && playMode = "playlist") ? GetActivePlaylistSongs() : songs

    results := []

    for song in sourceList {
        name := RegExReplace(song, "^.*\\")
        if (query = "" || InStr(StrLower(name), query))
            results.Push(name)
    }

    if (results.Length > 0)
        listBox.Add(results)
}

PlaySelectedFromSearch(listBox, gui) {
    global songs, shuffled, currentIndex, playMode, autoMode, isPlaylistMode
    global playlistInsertQueue, playlists, currentPlaylist, currentPlaylistGlobalIndex
    global playlistOrder, playlistSongIndex, playlistRandom, shuffledPlaylistPool, shuffledPoolIndex
    global playlistWorkingOrder

    if (listBox.Value = 0)
        return

    selectedName := listBox.Text

    ; Buscar la ruta según la fuente correcta
    sourceList := (playMode = "playlist") ? GetActivePlaylistSongs() : songs
    selectedPath := ""

    for song in sourceList {
        if (RegExReplace(song, "^.*\\") = selectedName) {
            selectedPath := song
            break
        }
    }

    if (selectedPath = "")
        return

    gui.Destroy()

    if (playMode = "playlist") {
        if (playlistRandom) {
            ; Modo aleatorio: operar sobre shuffledPlaylistPool + shuffledPoolIndex
            for i, s in shuffledPlaylistPool {
                if (s = selectedPath) {
                    shuffledPlaylistPool.RemoveAt(i)
                    if (i <= shuffledPoolIndex)
                        shuffledPoolIndex--
                    break
                }
            }
            shuffledPlaylistPool.InsertAt(shuffledPoolIndex + 1, selectedPath)
            ; En modo aleatorio la queue es necesaria para que suene ahora
            playlistInsertQueue.InsertAt(1, selectedPath)
        } else {
            ; Modo orden: reordenar playlistWorkingOrder e ir a la siguiente
            ; La cancion queda en playlistWorkingOrder[playlistSongIndex+1]
            ; GetNextSong la encontrara naturalmente - no necesita la queue
            for i, s in playlistWorkingOrder {
                if (s = selectedPath) {
                    playlistWorkingOrder.RemoveAt(i)
                    if (i <= playlistSongIndex)
                        playlistSongIndex--
                    break
                }
            }
            playlistWorkingOrder.InsertAt(playlistSongIndex + 1, selectedPath)
        }
    } else {
        ; En modo normal: insertar como siguiente en el shuffle normal
        if (shuffled.Length = 0)
            ShuffleSongs()
        for i, s in shuffled {
            if (s = selectedPath) {
                shuffled.RemoveAt(i)
                if (i <= currentIndex)
                    currentIndex--
                break
            }
        }
        ; Insertar como siguiente
        shuffled.InsertAt(currentIndex + 1, selectedPath)
    }

    PlayNext()
}

; ================= RESTO DEL SISTEMA =================

SelectMusicFolder(*) {
    global configFile
    while true {
        folder := DirSelect(, , L["select_music_folder"])
        if (folder = "") {
            MsgBox(L["must_select_folder"])
            continue
        }
        if (DirExist(folder)) {
            IniWrite(folder, configFile, "Paths", "MusicFolder1")
            LoadSongs()
            ShuffleSongs()
            break
        } else {
            MsgBox(L["invalid_folder"])
        }
    }
}

GetMusicFolders() {
    global configFile
    folders := []
    i := 1
    Loop {
        folder := IniRead(configFile, "Paths", "MusicFolder" i, "")
        if (folder = "")
            break
        folders.Push(folder)
        i++
    }
    return folders
}

OpenLanguageSelector(*) {
    langs := [
        ["en", "English"],
        ["es", "Español"],
        ["pt", "Português"],
        ["fr", "Français"],
        ["de", "Deutsch"],
        ["it", "Italiano"],
        ["nl", "Nederlands"],
        ["pl", "Polski"],
        ["ru", "Русский"],
        ["tr", "Türkçe"],
        ["ja", "日本語"],
        ["zh", "中文"],
        ["ko", "한국어"],
        ["ar", "العربية"],
        ["hi", "हिन्दी"],
        ["bn", "বাংলা"],
        ["id", "Bahasa Indonesia"],
        ["sw", "Kiswahili"],
        ["vi", "Tiếng Việt"],
        ["th", "ภาษาไทย"],
        ["uk", "Українська"],
        ["fa", "فارسی"],
        ["ha", "Hausa"]
    ]

    langGui := Gui("+AlwaysOnTop", "Magic Jukebox")
    langGui.SetFont("s10")
    langGui.AddText("w260 Center", "Select your language / Selecciona tu idioma")

    lbLang := langGui.AddListBox("xm w260 h300 y+10")

    names := []
    for item in langs
        names.Push(item[2])
    lbLang.Add(names)

    btnOK := langGui.AddButton("xm w260 y+5 Default", "OK")

    btnOK.OnEvent("Click", ConfirmLang)
    lbLang.OnEvent("DoubleClick", ConfirmLang)
	langGui.OnEvent("Close", (*) => ConfirmLang())

    langGui.Show()
    WinWaitClose(langGui)

    ConfirmLang(*) {
    code := (lbLang.Value = 0) ? "en" : langs[lbLang.Value][1]
    srcFile := A_AppData "\Magic Jukebox\" code "-lang.ini"
    LoadLanguage(code)
    langGui.Destroy()
    if (ProcessExist(vlcPID))
        ProcessClose(vlcPID)
    Run(A_ScriptFullPath)
    ExitApp()
}
}

RefreshSongs() {
    global lastFolderTime

    folders := GetMusicFolders()
    if (folders.Length = 0)
        return

    currentTime := ""
    for folder in folders {
        if (DirExist(folder))
            currentTime .= FileGetTime(folder, "M")
    }

    if (currentTime = lastFolderTime)
        return

    lastFolderTime := currentTime
    LoadSongs()
}

SelectVLC(*) {
    global vlcPath, configFile
    while true {
        defaultPath := FileExist("C:\Program Files\VideoLAN\VLC\vlc.exe") 
            ? "C:\Program Files\VideoLAN\VLC" 
            : ""
        path := FileSelect(1, defaultPath, L["select_vlc"], "vlc.exe")
        if (path = "") {
            MsgBox(L["must_select_vlc"])
            continue
        }
        if (FileExist(path) && InStr(StrLower(path), "vlc.exe")) {
            vlcPath := path
            IniWrite(path, configFile, "Paths", "VLC")
            break
        } else {
            MsgBox(L["incorrect_file"])
        }
    }
}

LoadSongs() {
    global songs

    songs := []
    allowed := "^(mp3|flac|wav|ogg|m4a|aac|opus|wma|aiff|mp4|webm)$"

    for folder in GetMusicFolders() {
        if (!DirExist(folder))
            continue
        Loop Files folder "\*.*" {
            ext := StrLower(A_LoopFileExt)
            if (ext ~= allowed) {
                songs.Push(A_LoopFileFullPath)
            }
            else if (ext = "lnk") {
                try {
                    FileGetShortcut(A_LoopFileFullPath, &target)
                    if (FileExist(target)) {
                        targetExt := StrLower(SubStr(target, InStr(target, ".", , -1) + 1))
                        if (targetExt ~= allowed)
                            songs.Push(target)
                    }
                }
            }
        }
    }
}

ShuffleSongs() {
    global songs, shuffled, currentIndex
    shuffled := songs.Clone()
    Loop shuffled.Length - 1 {
        i := shuffled.Length - A_Index + 1
        j := Random(1, i)
        temp := shuffled[i]
        shuffled[i] := shuffled[j]
        shuffled[j] := temp
    }
    currentIndex := 0
}

GetNextSong() {
    global playMode
    global shuffled, currentIndex
    global playlists, currentPlaylist, playlistSongIndex
    global currentPlaylistGlobalIndex, playlistOrder, playlistLoop, isPlaylistMode
    global playlistRandom, shuffledPlaylistPool, shuffledPoolIndex
    global playlistInsertQueue
    global playlistWorkingOrder
    global playlistLoopActive, playlistRandomActive

    ; ===== MODO PLAYLIST =====
    if (playMode = "playlist") {

        ; --- Primero revisar si hay canciones en la cola de inserción (Buscar canción) ---
        if (playlistInsertQueue.Length > 0) {
            nextSong := playlistInsertQueue[1]
            playlistInsertQueue.RemoveAt(1)
            return nextSong
        }

        ; ===== MODO ALEATORIO: pool único mezclado =====
        if (playlistRandomActive) {

            ; Si el pool está vacío o terminó, construirlo/rebarajarlo
            if (shuffledPlaylistPool.Length = 0 || shuffledPoolIndex >= shuffledPlaylistPool.Length) {

                if (shuffledPlaylistPool.Length > 0 && !playlistLoopActive) {
                    ; Termina la playlist: volver al modo normal y reproducir siguiente canción normal
                    playMode := "normal"
                    isPlaylistMode := false
                    RestoreNormalTray()
                    return GetNextNormalSong()
                }

                ; Construir pool con todas las canciones de las playlists activas
                shuffledPlaylistPool := []

                ; Si es "reproducir todas", usar todas las playlists
                if (currentPlaylistGlobalIndex > 0) {
                    for name in playlistOrder {
                        if playlists.Has(name) {
                            for song in playlists[name]
                                shuffledPlaylistPool.Push(song)
                        }
                    }
                } else {
                    ; Solo la playlist activa
                    if playlists.Has(currentPlaylist) {
                        for song in playlists[currentPlaylist]
                            shuffledPlaylistPool.Push(song)
                    }
                }

                ; Barajar el pool
                Loop shuffledPlaylistPool.Length - 1 {
                    i := shuffledPlaylistPool.Length - A_Index + 1
                    j := Random(1, i)
                    temp := shuffledPlaylistPool[i]
                    shuffledPlaylistPool[i] := shuffledPlaylistPool[j]
                    shuffledPlaylistPool[j] := temp
                }

                shuffledPoolIndex := 0
            }

            shuffledPoolIndex++
            return shuffledPlaylistPool[shuffledPoolIndex]
        }

        ; ===== MODO NORMAL (orden original) =====
        if (!playlists.Has(currentPlaylist))
            return ""

        ; Usar la copia de trabajo, no playlists[] directamente
        list := playlistWorkingOrder

        if (list.Length = 0)
            return ""

        if (playlistSongIndex >= list.Length) {

            if (currentPlaylistGlobalIndex > 0) {

                currentPlaylistGlobalIndex++

                if (currentPlaylistGlobalIndex > playlistOrder.Length) {
                    if (playlistLoopActive) {
                        currentPlaylistGlobalIndex := 1
                    } else {
                        ; Termina "reproducir todas": volver al modo normal y reproducir siguiente canción normal
                        playMode := "normal"
                        isPlaylistMode := false
                        currentPlaylistGlobalIndex := 0
                        RestoreNormalTray()
                        return GetNextNormalSong()
                    }
                }

                currentPlaylist := playlistOrder[currentPlaylistGlobalIndex]
                playlistSongIndex := 0
                ; Actualizar la copia de trabajo para la nueva playlist activa
                playlistWorkingOrder := []
                if playlists.Has(currentPlaylist) {
                    for s in playlists[currentPlaylist]
                        playlistWorkingOrder.Push(s)
                }
                list := playlistWorkingOrder
            } else {
                if (playlistLoopActive) {
                    playlistSongIndex := 0
                } else {
                    ; Termina la playlist individual: volver al modo normal y reproducir siguiente canción normal
                    playMode := "normal"
                    isPlaylistMode := false
                    RestoreNormalTray()
                    return GetNextNormalSong()
                }
            }
        }

        playlistSongIndex++
        return list[playlistSongIndex]
    }

    ; ===== MODO NORMAL =====
    return GetNextNormalSong()
}

; Función auxiliar: obtiene la siguiente canción del shuffle normal
GetNextNormalSong() {
    global shuffled, currentIndex

    if (shuffled.Length = 0)
        return ""

    ; Si se agotó el shuffle, empezar desde el principio del mismo shuffle (sin reorganizar)
    if (currentIndex >= shuffled.Length)
        currentIndex := 0

    currentIndex++
    return shuffled[currentIndex]
}

PlayNext(*) {
    global shuffled, currentIndex, vlcPID, vlcPath
    global jukeboxSound, currentSong, isPlaying, isPaused, iconIdle
    global playMode, isTransitioning, vlcRCPort, repeatLoop
    global progBusy, miniPlayerShown, imgProgBarra, lblProgCurrent, lblProgTotal
    global progTotalSecs, progCurrentSecs, progSeekTime, progPendingSeek, progDragging

    if (isTransitioning)
        return

    isTransitioning := true

    if (playMode = "normal" && shuffled.Length = 0) {
        MsgBox(L["no_songs_found"])
        isTransitioning := false
        return
    }

    if (ProcessExist(vlcPID))
        ProcessClose(vlcPID)

    SetTimer(CheckVLC, 0)

    isPaused := false
    isPlaying := false

    ; Resetear barra de progreso completamente, igual que los labels
    StopProgTimers()
    progBusy        := false
    progTotalSecs   := 0
    progCurrentSecs := 0
    progSeekTime    := 0
    progPendingSeek := -1
    progDragging    := false
    if (miniPlayerShown && IsObject(imgProgBarra)) {
        try imgProgBarra.Move(, , 1)
        try lblProgCurrent.Text := "00:00"
        try lblProgTotal.Text   := "00:00"
    }

	if (miniPlayerShown && IsObject(miniPlayer)) {
    lblArtist.Text := L["artist"] ":"
    lblAlbum.Text  := L["album"] ":"
    lblTitle.Text  := L["title"] ":"
}
    TraySetIcon(iconIdle)
    SoundPlay(jukeboxSound, 1)

    currentSong := GetNextSong()

    if (currentSong = "") {
        isTransitioning := false
        return
    }

    Run('"' vlcPath '" --intf rc --rc-host localhost:' vlcRCPort ' --no-video --play-and-exit --no-loop "' currentSong '"'
        , , "Hide", &vlcPID)

    isPlaying := true
    isTransitioning := false

    SetTimer(AnimateVinyl, 120)
    SetTimer(CheckVLC, 1000)

    if (repeatLoop)
        SendVLCCommand("repeat on")
		SendVLCCommand("volume " Round(volumeLevel * 256 / 100))

    ; Reanudar la barra de progreso con la nueva cancion
    StartProgTimers()

    A_IconTip := L["playing"] "`n" RegExReplace(currentSong, "^.*\\")
	UpdateMiniPlayer()
}

PrevSong(*) {
    global shuffled, currentIndex, vlcPID, vlcPath
    global jukeboxSound, currentSong, isPlaying, isPaused, iconIdle
    global playMode, isTransitioning, vlcRCPort, repeatLoop
    global playlists, currentPlaylist, playlistSongIndex
    global currentPlaylistGlobalIndex, playlistOrder
    global playlistRandom, shuffledPlaylistPool, shuffledPoolIndex

    if (isTransitioning)
        return

    ; Modo normal
    if (playMode = "normal") {
        if (currentIndex <= 1)
            return
        currentIndex -= 2
    }

    ; Modo playlist sin random
    else if (playMode = "playlist" && !playlistRandom) {
        if (currentPlaylistGlobalIndex > 0) {
    ; Reproducir todas
    if (playlistSongIndex <= 1) {
        if (currentPlaylistGlobalIndex <= 1)
            return
        currentPlaylistGlobalIndex--
        currentPlaylist := playlistOrder[currentPlaylistGlobalIndex]
        playlistSongIndex := playlists[currentPlaylist].Length - 1
    } else {
        playlistSongIndex -= 2
    }
} else {
            ; Playlist individual
            if (playlistSongIndex <= 1)
                return
            playlistSongIndex -= 2
        }
    }

    ; Modo playlist con random
    else if (playMode = "playlist" && playlistRandom) {
        if (shuffledPoolIndex <= 1)
            return
        shuffledPoolIndex -= 2
    }

    PlayNext()
}

CheckVLC() {
    global vlcPID, isPlaying, iconIdle, autoMode

    if (vlcPID != 0 && !ProcessExist(vlcPID)) {

        SetTimer(CheckVLC, 0)
        SetTimer(AnimateVinyl, 0)
        TraySetIcon(iconIdle)
        isPlaying := false
        vlcPID := 0

        if (autoMode) {
            PlayNext()
        }
    }
}

TogglePause(*) {
    global vlcPID, isPaused, iconIdle, volumeLevel, isMuted
    global progIsPaused, progCurrentSecs

    if (!ProcessExist(vlcPID))
        return

    if (!isPaused) {
        SendVLCCommand("pause")
        isPaused := true
        progIsPaused := true
        SetTimer(AnimateVinyl, 0)
        TraySetIcon(iconIdle)
    } else {
        SendVLCCommand("pause")
        isPaused := false
        SetTimer(AnimateVinyl, 120)
        ; Reenviar volumen al reanudar
        if (isMuted)
            SendVLCCommand("volume 0")
        else
            SendVLCCommand("volume " Round(volumeLevel * 256 / 100))
        progIsPaused := false
    }
	UpdateMiniPlayer()
}

ToggleRepeatLoop(*) {
    global repeatLoop, vlcPID

    repeatLoop := !repeatLoop

    if (ProcessExist(vlcPID)) {
        if (repeatLoop)
            SendVLCCommand("repeat on")
        else
            SendVLCCommand("repeat off")
    }

    UpdateMiniPlayerImage()
if (playMode = "playlist")
    SwitchToPlaylistTray()
else
    RestoreNormalTray()
}

ToggleAutoMode(*) {
    global autoMode
    autoMode := !autoMode
    IniWrite(autoMode ? "1" : "0", configFile, "State", "AutoMode")

    RestoreNormalTray()
}

AnimateVinyl() {
    global vinylFrames, frameIndex, isPlaying
    if (!isPlaying)
        return
    TraySetIcon(vinylFrames[frameIndex])
    frameIndex := (frameIndex >= vinylFrames.Length) ? 1 : frameIndex + 1
}

CloseApp(*) {
    global vlcPID
    if (ProcessExist(vlcPID))
        ProcessClose(vlcPID)
    for proc in ComObjGet("winmgmts:").ExecQuery("Select * from Win32_Process Where Name='vlc.exe'")
        ProcessClose(proc.ProcessId)
    ExitApp()
}

SendVLCCommand(cmd) {
    global vlcRCPort

    ; Inicializar Winsock primero
    wsaData := Buffer(408, 0)
    DllCall("ws2_32\WSAStartup", "UShort", 0x0202, "Ptr", wsaData)

    socket := DllCall("ws2_32\socket", "Int", 2, "Int", 1, "Int", 6, "Ptr")
    if (socket = -1)
        return false

    ; Construir estructura sockaddr_in
    addr := Buffer(16, 0)
    NumPut("UShort", 2, addr, 0)
    NumPut("UShort", DllCall("ws2_32\htons", "UShort", vlcRCPort, "UShort"), addr, 2)
    NumPut("UInt", DllCall("ws2_32\inet_addr", "AStr", "127.0.0.1", "UInt"), addr, 4)

    ; Intentar conectar hasta 10 veces con 100ms de espera
    connected := false
    Loop 10 {
        result := DllCall("ws2_32\connect", "Ptr", socket, "Ptr", addr, "Int", 16, "Int")
        if (result = 0) {
            connected := true
            break
        }
        Sleep(100)
    }

    if (!connected) {
        DllCall("ws2_32\closesocket", "Ptr", socket)
        return false
    }

    ; Enviar comando
    cmdBuf := Buffer(StrPut(cmd "`n", "UTF-8"), 0)
    StrPut(cmd "`n", cmdBuf, "UTF-8")
    DllCall("ws2_32\send", "Ptr", socket, "Ptr", cmdBuf, "Int", cmdBuf.Size - 1, "Int", 0)

    DllCall("ws2_32\closesocket", "Ptr", socket)
    return true
}

LoadLanguage(langCode) {
    global L, currentLang, configFile
    currentLang := langCode

    langFile := A_AppData "\Magic Jukebox\" langCode "-lang.ini"

    if (!FileExist(langFile)) {
        langFile := A_AppData "\Magic Jukebox\en-lang.ini"
        currentLang := "en"
    }

    L := Map()

    try
    fileContent := FileRead(langFile, "UTF-8")
    catch
    fileContent := ""
    for line in StrSplit(fileContent, "`n", "`r") {
        line := Trim(line)
        if (line = "" || SubStr(line, 1, 1) = ";" || SubStr(line, 1, 1) = "[")
            continue
        eqPos := InStr(line, "=")
        if (eqPos > 0) {
            key := Trim(SubStr(line, 1, eqPos - 1))
            value := Trim(SubStr(line, eqPos + 1))
            value := StrReplace(value, "``n", "`n")
            L[key] := value

        }
    }
    IniWrite(currentLang, configFile, "General", "Language")
}

LoadHotkeysFromIni() {
    global configFile
    global currentNextKey, currentSearchKey
    global currentPauseKey, currentRepeatKey
    global currentPlaylistKey, currentMiniPlayerKey

    
    try Hotkey(currentPrevKey, "Off")
	try Hotkey(currentNextKey, "Off")
    try Hotkey(currentSearchKey, "Off")
    try Hotkey(currentPauseKey, "Off")
    try Hotkey(currentRepeatKey, "Off")
    try Hotkey(currentPlaylistKey, "Off")
    try Hotkey(currentMiniPlayerKey, "Off")
	try Hotkey(currentVolUpKey, "Off")
    try Hotkey(currentVolDownKey, "Off")
    try Hotkey(currentMuteKey, "Off")

    ; Leer nuevas teclas
    prevKey     := IniRead(configFile, "Hotkeys", "prev_song",    "^NumpadDot")
	nextKey     := IniRead(configFile, "Hotkeys", "next_song",    "^NumpadEnter")
    searchKey   := IniRead(configFile, "Hotkeys", "search_song",  "^Numpad4")
    pauseKey    := IniRead(configFile, "Hotkeys", "pause_resume", "^NumpadAdd")
    repeatKey   := IniRead(configFile, "Hotkeys", "repeat_song",  "^Numpad0")
    playlistKey    := IniRead(configFile, "Hotkeys", "playlist",    "^Numpad5")
    miniPlayerKey  := IniRead(configFile, "Hotkeys", "miniplayer",  "^Numpad6")
	volUpKey   := IniRead(configFile, "Hotkeys", "vol_up",   "^Numpad2")
    volDownKey := IniRead(configFile, "Hotkeys", "vol_down", "^Numpad1")
    muteKey    := IniRead(configFile, "Hotkeys", "mute",     "^Numpad3")

    ; Activarlas (solo si no estan vacias)
    if (prevKey != "") {
        try Hotkey(prevKey, PrevSong, "On")
    }
    if (nextKey != "") {
        try Hotkey(nextKey, PlayNext, "On")
    }
    if (searchKey != "") {
        try Hotkey(searchKey, OpenSearchWindow, "On")
    }
    if (pauseKey != "") {
        try Hotkey(pauseKey, TogglePause, "On")
    }
    if (repeatKey != "") {
        try Hotkey(repeatKey, ToggleRepeatLoop, "On")
    }
    if (playlistKey != "") {
        try Hotkey(playlistKey, OpenPlaylistManager, "On")
    }
    if (miniPlayerKey != "") {
        try Hotkey(miniPlayerKey, OpenMiniPlayer, "On")
    }
    if (volUpKey != "") {
        try Hotkey(volUpKey, VolumeUp, "On")
    }
    if (volDownKey != "") {
        try Hotkey(volDownKey, VolumeDown, "On")
    }
    if (muteKey != "") {
        try Hotkey(muteKey, ToggleMute, "On")
    }

    
    currentPrevKey := prevKey
	currentNextKey := nextKey
    currentSearchKey := searchKey
    currentPauseKey := pauseKey
    currentRepeatKey := repeatKey
    currentPlaylistKey := playlistKey
    currentMiniPlayerKey := miniPlayerKey
	currentVolUpKey   := volUpKey
    currentVolDownKey := volDownKey
    currentMuteKey    := muteKey
}

LoadPlaylistsFromIni() {
    global playlistsFile, playlists, playlistOrder

    playlists := Map()
    playlistOrder := []

    order := IniRead(playlistsFile, "Playlists", "Order", "")

    if (order != "")
        playlistOrder := StrSplit(order, "|")

    for name in playlistOrder {

        songsArray := []
        index := 1

        Loop {
            key := "Song" index
            value := IniRead(playlistsFile, name, key, "")

            if (value = "")
                break

            songsArray.Push(value)
            index++
        }

        playlists[name] := songsArray
    }
}

SavePlaylistToIni(name) {
    global playlistsFile, playlists

    if !playlists.Has(name)
        return

    ; Primero borrar sección anterior
    IniDelete(playlistsFile, name)

    songsArray := playlists[name]

    index := 1
    for song in songsArray {
        IniWrite(song, playlistsFile, name, "Song" index)
        index++
    }
}

PlaylistHasErrors(name) {
    if !playlists.Has(name)
        return false
    for songPath in playlists[name]
        if (!FileExist(songPath))
            return true
    return false
}

CreateNewPlaylist(*) {
    global playlistsFile, playlists, playlistOrder

    inputGui := Gui("+AlwaysOnTop", L["new_playlist_title"])
    inputGui.SetFont("s10")

    inputGui.AddText("w250", L["new_playlist_label"])
    nameEdit := inputGui.AddEdit("w250")

    btnCreate := inputGui.AddButton("w120", L["create"])
    btnCancel := inputGui.AddButton("x+10 w120", L["cancel"])

    btnCreate.OnEvent("Click", CreatePlaylistConfirm)
    btnCancel.OnEvent("Click", (*) => inputGui.Destroy())

    inputGui.Show()

    CreatePlaylistConfirm(*) {
        name := Trim(nameEdit.Value)

        if (name = "") {
            MsgBox(L["name_empty"], "Error", "Owner" inputGui.Hwnd)
            return
        }

        if playlists.Has(name) {
            MsgBox(L["name_exists"], "Error", "Owner" inputGui.Hwnd)
            return
        }

        playlists[name] := []
        playlistOrder.Push(name)

        orderString := ""
        for i, nameItem in playlistOrder {
            if (i > 1)
                orderString .= "|"
            orderString .= nameItem
        }

        IniWrite(orderString, playlistsFile, "Playlists", "Order")
        try {
            lbPlaylists.Delete()
            displayPlaylists := []
            for name in playlistOrder
            displayPlaylists.Push(PlaylistHasErrors(name) ? "[!] " name : name)
            lbPlaylists.Add(displayPlaylists)
        }
        inputGui.Destroy()
    }
}

OpenHotkeyWindow(*) {
    global configFile

    AHKToHuman(ahkKey) {
        result := ""
        if (InStr(ahkKey, "^"))
            result .= "Ctrl+"
        if (InStr(ahkKey, "!"))
            result .= "Alt+"
        if (InStr(ahkKey, "+"))
            result .= "Shift+"
        if (InStr(ahkKey, "#"))
            result .= "Win+"
        base := RegExReplace(ahkKey, "[\^!+#]", "")
        result .= base
        return result
    }

    HumanToAHK(humanKey) {
        result := ""
        upper := StrUpper(humanKey)
        if (InStr(upper, "CTRL+"))
            result .= "^"
        if (InStr(upper, "ALT+"))
            result .= "!"
        if (InStr(upper, "SHIFT+"))
            result .= "+"
        if (InStr(upper, "WIN+"))
            result .= "#"
        base := humanKey
        while (InStr(base, "+"))
            base := SubStr(base, InStr(base, "+") + 1)
        base := Trim(base)
        if (base = "")
            return ""
        result .= base
        return result
    }

    IsValidKey(humanKey) {
        if (Trim(humanKey) = "")
            return true   ; vacio es valido - significa sin atajo
        upper := StrUpper(Trim(humanKey))
        cleaned := upper
        cleaned := StrReplace(cleaned, "CTRL+", "")
        cleaned := StrReplace(cleaned, "ALT+", "")
        cleaned := StrReplace(cleaned, "SHIFT+", "")
        cleaned := StrReplace(cleaned, "WIN+", "")
        if (InStr(cleaned, "+"))
            return false
        if (Trim(cleaned) = "")
            return false
        ahkKey := HumanToAHK(humanKey)
        try {
            Hotkey(ahkKey, (*) => 0, "Off")
            return true
        } catch {
            return false
        }
    }

    volUpKey   := IniRead(configFile, "Hotkeys", "vol_up",       "^Numpad2")
    volDownKey := IniRead(configFile, "Hotkeys", "vol_down",     "^Numpad1")
    muteKey    := IniRead(configFile, "Hotkeys", "mute",         "^Numpad3")
	prevKey     := IniRead(configFile, "Hotkeys", "prev_song",    "^NumpadDot")
	nextKey     := IniRead(configFile, "Hotkeys", "next_song",    "^NumpadEnter")
    searchKey   := IniRead(configFile, "Hotkeys", "search_song",  "^Numpad4")
    pauseKey    := IniRead(configFile, "Hotkeys", "pause_resume", "^NumpadAdd")
    repeatKey   := IniRead(configFile, "Hotkeys", "repeat_song",  "^Numpad0")
    playlistKey    := IniRead(configFile, "Hotkeys", "playlist",    "^Numpad5")
    miniPlayerKey  := IniRead(configFile, "Hotkeys", "miniplayer",  "^Numpad6")

    hotkeyGui := Gui("+AlwaysOnTop", L["assign_hotkeys"])
    hotkeyGui.SetFont("s10")

    hotkeyGui.AddText("w320", "Volume up:")
    editVolUp := hotkeyGui.AddEdit("w320", AHKToHuman(volUpKey))

    hotkeyGui.AddText("w320 y+8", "Volume down:")
    editVolDown := hotkeyGui.AddEdit("w320", AHKToHuman(volDownKey))

    hotkeyGui.AddText("w320 y+8", "Mute:")
    editMute := hotkeyGui.AddEdit("w320", AHKToHuman(muteKey))
	
	hotkeyGui.AddText("w320", L["prev_song"] ":")
    editPrev := hotkeyGui.AddEdit("w320", AHKToHuman(prevKey))
	
	hotkeyGui.AddText("w320", L["next_song"] ":")
    editNext := hotkeyGui.AddEdit("w320", AHKToHuman(nextKey))

    hotkeyGui.AddText("w320 y+8", L["search_song"] ":")
    editSearch := hotkeyGui.AddEdit("w320", AHKToHuman(searchKey))

    hotkeyGui.AddText("w320 y+8", L["pause_resume"] ":")
    editPause := hotkeyGui.AddEdit("w320", AHKToHuman(pauseKey))

    hotkeyGui.AddText("w320 y+8", L["repeat_song"] ":")
    editRepeat := hotkeyGui.AddEdit("w320", AHKToHuman(repeatKey))

    hotkeyGui.AddText("w320 y+8", L["playlist"] ":")
    editPlaylist := hotkeyGui.AddEdit("w320", AHKToHuman(playlistKey))

    hotkeyGui.AddText("w320 y+8", L["open_miniplayer"] ":")
    editMiniPlayer := hotkeyGui.AddEdit("w320", AHKToHuman(miniPlayerKey))

    hotkeyGui.AddText("w320 y+15", "")

    btnGuide  := hotkeyGui.AddButton("w155 y+5", L["guide"])
    btnUpdate := hotkeyGui.AddButton("x+10 w155", L["update_hotkeys"])

    btnGuide.OnEvent("Click", (*) => MsgBox(L["guide_text"], L["guide"], "Owner" hotkeyGui.Hwnd))

    btnUpdate.OnEvent("Click", UpdateHotkeys)

    hotkeyGui.Show()

    UpdateHotkeys(*) {
        values := [
            editVolUp.Value,
            editVolDown.Value,
            editMute.Value,
			editPrev.Value,
			editNext.Value,
            editSearch.Value,
            editPause.Value,
            editRepeat.Value,
            editPlaylist.Value,
            editMiniPlayer.Value
        ]
        names := [
            "Volume up",
            "Volume down",
            "Mute",
			L["prev_song"],
			L["next_song"],
            L["search_song"],
            L["pause_resume"],
            L["repeat_song"],
            L["playlist"],
            L["open_miniplayer"]
        ]
        iniKeys := [
            "vol_up",
            "vol_down",
            "mute",
			"prev_song",
			"next_song",
            "search_song",
            "pause_resume",
            "repeat_song",
            "playlist",
            "miniplayer"
        ]

        for i, val in values {
            if (!IsValidKey(val)) {
                MsgBox(
                    StrReplace(L["invalid_hotkey"], "{1}", names[i]),
                    "Error", "Owner" hotkeyGui.Hwnd
                )
                return
            }
        }

        for i, val in values {
            IniWrite(HumanToAHK(val), configFile, "Hotkeys", iniKeys[i])
        }

        LoadHotkeysFromIni()
        MsgBox(L["hotkeys_updated"], L["app_name"], "Owner" hotkeyGui.Hwnd)
        hotkeyGui.Destroy()
    }
}

OpenPlaylistManager(*) {
    global playlists, playlistOrder
    global playMode, currentPlaylist, playlistSongIndex
    global songs, playlistsFile
    reorderMode := ""

    managerGui := Gui("+AlwaysOnTop", L["playlist_title"])
    managerGui.Opt("+OwnDialogs")
    managerGui.SetFont("s10")
	managerGui.SetFont("s10", "Segoe UI Emoji")

    ; ================= IZQUIERDA =================

    managerGui.AddText("xm", L["search_song"])
    searchEdit := managerGui.AddEdit("xm w250")
    lbSearch := managerGui.AddListBox("xm w250 h150 HScroll")

    managerGui.AddText("xm y+10", L["playlists"])
    global lbPlaylists
    lbPlaylists := managerGui.AddListBox("xm w250 h120")
    displayPlaylists := []
    for name in playlistOrder
    displayPlaylists.Push(PlaylistHasErrors(name) ? "[!] " name : name)
    lbPlaylists.Add(displayPlaylists)

    btnCreate := managerGui.AddButton("xm w250 y+5", L["create_playlist"])
    btnPlayAll := managerGui.AddButton("xm w250 y+5", L["play_all"])
    global btnLoop
    btnLoop := managerGui.AddButton("xm w250 y+5", playlistLoop ? L["loop_on"] : L["loop_off"])
    global btnRandom
    btnRandom := managerGui.AddButton("xm w250 y+5", playlistRandom ? L["random_on"] : L["random_off"])

    ; ================= DERECHA =================

    rightX := 320
    topY := 20

    managerGui.AddText("x" rightX " y" topY, L["playlist_songs"])

    lbSongs := managerGui.AddListBox("x" rightX " y" topY+20 " w340 h320")

    btnPlay := managerGui.AddButton("x" rightX " y" topY+350 " w105", L["play"])
    btnRemove := managerGui.AddButton("x" rightX+115 " y" topY+350 " w105", L["remove"])
    btnDelete := managerGui.AddButton("x" rightX+230 " y" topY+350 " w105", L["delete"])

    btnApply := managerGui.AddButton("x" rightX " y" topY+385 " w340 Hidden", L["exit_reorder"])

    lblInstructions := managerGui.AddText("x" rightX " y" topY+420 " w340", L["reorder_instructions"])

    btnUp := managerGui.AddButton("x" rightX " y" topY+455 " w165 Hidden", L["move_up"])
    btnDown := managerGui.AddButton("x" rightX+175 " y" topY+455 " w165 Hidden", L["move_down"])

    ; ================= EVENTOS =================

    searchEdit.OnEvent("Change", (*) => FilterSongs(searchEdit, lbSearch, true))
    lbSearch.OnEvent("DoubleClick", (*) => AddSongToPlaylist())
    lbPlaylists.OnEvent("Change", (*) => UpdateSongList())
    btnCreate.OnEvent("Click", CreateNewPlaylist)
    btnLoop.OnEvent("Click", TogglePlaylistLoop)
    btnRandom.OnEvent("Click", TogglePlaylistRandom)
    btnPlayAll.OnEvent("Click", PlayAllPlaylists)
    btnPlay.OnEvent("Click", (*) => StartPlaylist())
    btnRemove.OnEvent("Click", (*) => RemoveSongFromPlaylist())
    btnDelete.OnEvent("Click", (*) => DeletePlaylist())
    btnApply.OnEvent("Click", (*) => ExitReorderMode())
    lbPlaylists.OnEvent("DoubleClick", (*) => EnterReorderMode("playlists"))
    lbSongs.OnEvent("DoubleClick", (*) => EnterReorderMode("songs"))
    btnUp.OnEvent("Click", (*) => MoveItem(-1))
    btnDown.OnEvent("Click", (*) => MoveItem(1))

    FilterSongs(searchEdit, lbSearch, true)
    managerGui.Show()

    ; ================= FUNCIONES INTERNAS =================

    AddSongToPlaylist() {
        if (lbPlaylists.Value = 0) {
            MsgBox(L["select_playlist_first"], L["app_name"], "Owner" managerGui.Hwnd)
            return
        }
        if (lbSearch.Value = 0)
            return
        selectedName := lbSearch.Text
        selectedPath := ""
        for song in songs {
            if (RegExReplace(song, "^.*\\") = selectedName) {
                selectedPath := song
                break
            }
        }
        if (selectedPath = "")
            return
        name := lbPlaylists.Text
        name := RegExReplace(name, "^\[!\] ", "")
		playlists[name].Push(selectedPath)
        SavePlaylistToIni(name)
        UpdateSongList()
    }

     UpdateSongList() {
    lbSongs.Delete()
    if (lbPlaylists.Value = 0)
        return
    name := lbPlaylists.Text
    name := RegExReplace(name, "^\[!\] ", "")
    if playlists.Has(name) {
        displayNames := []
        for songPath in playlists[name] {
            cleanName := RegExReplace(songPath, "^.*\\")
            if (FileExist(songPath))
                displayNames.Push(cleanName)
            else
                displayNames.Push("[!] " cleanName)
        }
        lbSongs.Add(displayNames)
    }
}

    StartPlaylist() {
        global currentPlaylist, playlistSongIndex
        global playMode, autoMode, isPlaylistMode
        global currentPlaylistGlobalIndex
        global shuffledPlaylistPool, shuffledPoolIndex
        global playlistInsertQueue, playlistWorkingOrder
        global playlistLoopActive, playlistRandomActive, playlistLoop, playlistRandom

        if (lbPlaylists.Value = 0)
            return

        currentPlaylist := lbPlaylists.Text
        currentPlaylist := RegExReplace(currentPlaylist, "^\[!\] ", "")
        playlistSongIndex := 0
        currentPlaylistGlobalIndex := 0
        shuffledPlaylistPool := []
        shuffledPoolIndex := 0
        playlistInsertQueue := []
        ; Fijar valores activos al momento de iniciar (los botones no los cambiaran)
        playlistLoopActive   := playlistLoop
        playlistRandomActive := playlistRandom
        ; Crear copia de trabajo del orden (el administrador no la ve)
        playlistWorkingOrder := []
        if playlists.Has(currentPlaylist) {
            for s in playlists[currentPlaylist]
                playlistWorkingOrder.Push(s)
        }
        playMode := "playlist"
        autoMode := true
        isPlaylistMode := true
        SwitchToPlaylistTray()
        managerGui.Destroy()
        PlayNext()
    }

PlayAllPlaylists(*) {
        global playlistOrder
        global currentPlaylist, playlistSongIndex
        global currentPlaylistGlobalIndex
        global playMode, autoMode, isPlaylistMode
        global shuffledPlaylistPool, shuffledPoolIndex
        global playlistInsertQueue, playlistWorkingOrder
        global playlistLoopActive, playlistRandomActive, playlistLoop, playlistRandom

        if (playlistOrder.Length = 0)
            return

        currentPlaylistGlobalIndex := 1
        currentPlaylist := playlistOrder[1]
        playlistSongIndex := 0
        shuffledPlaylistPool := []
        shuffledPoolIndex := 0
        playlistInsertQueue := []
        ; Fijar valores activos al momento de iniciar
        playlistLoopActive   := playlistLoop
        playlistRandomActive := playlistRandom
        ; Crear copia de trabajo del orden de la primera playlist
        playlistWorkingOrder := []
        if playlists.Has(currentPlaylist) {
            for s in playlists[currentPlaylist]
                playlistWorkingOrder.Push(s)
        }
        playMode := "playlist"
        autoMode := true
        isPlaylistMode := true
        SwitchToPlaylistTray()
        managerGui.Destroy()
        PlayNext()
    }

    RemoveSongFromPlaylist() {
        if (lbPlaylists.Value = 0 || lbSongs.Value = 0)
            return
        name := lbPlaylists.Text
        name := RegExReplace(name, "^\[!\] ", "")
		index := lbSongs.Value
        playlists[name].RemoveAt(index)
        SavePlaylistToIni(name)
        UpdateSongList()
    }

    DeletePlaylist() {
        if (lbPlaylists.Value = 0)
            return
        result := MsgBox(L["confirm_delete"], L["confirm_delete_title"], "YesNo Icon? Owner" managerGui.Hwnd)
        if (result != "Yes")
            return
        name := lbPlaylists.Text
        name := RegExReplace(name, "^\[!\] ", "")
		playlists.Delete(name)
        for i, v in playlistOrder {
            if (v = name) {
                playlistOrder.RemoveAt(i)
                break
            }
        }
        orderString := ""
        for i, nameItem in playlistOrder {
            if (i > 1)
                orderString .= "|"
            orderString .= nameItem
        }
        IniWrite(orderString, playlistsFile, "Playlists", "Order")
        IniDelete(playlistsFile, name)
        lbPlaylists.Delete()
        displayPlaylists := []
        for name in playlistOrder
        displayPlaylists.Push(PlaylistHasErrors(name) ? "[!] " name : name)
        lbPlaylists.Add(displayPlaylists)
        lbSongs.Delete()
    }
	    EnterReorderMode(mode) {
        reorderMode := mode
        if (mode = "playlists") {
            managerGui.Title := L["reorder_title_playlists"]
            lblInstructions.Text := L["reorder_playlists_instructions"]
        } else {
            if (lbPlaylists.Value = 0)
                return
            managerGui.Title := StrReplace(L["reorder_title_songs"], "{1}", RegExReplace(lbPlaylists.Text, "^\[!\] ", ""))
            lblInstructions.Text := L["reorder_songs_instructions"]
        }
        btnApply.Visible := true
        lblInstructions.Visible := true
        btnUp.Visible := true
        btnDown.Visible := true
    }

    ExitReorderMode() {
        reorderMode := ""
        managerGui.Title := L["playlist_title"]
        btnApply.Visible := false
        btnUp.Visible := false
        btnDown.Visible := false
        lblInstructions.Text := L["reorder_instructions"]
    }

    MoveItem(direction) {
        if (reorderMode = "playlists") {
            if (lbPlaylists.Value = 0)
                return
            idx := lbPlaylists.Value
            newIdx := idx + direction
            if (newIdx < 1 || newIdx > playlistOrder.Length)
                return
            temp := playlistOrder[idx]
            playlistOrder[idx] := playlistOrder[newIdx]
            playlistOrder[newIdx] := temp
            orderString := ""
            for i, nameItem in playlistOrder {
                if (i > 1)
                    orderString .= "|"
                orderString .= nameItem
            }
            IniWrite(orderString, playlistsFile, "Playlists", "Order")
            lbPlaylists.Delete()
            displayPlaylists := []
            for name in playlistOrder
            displayPlaylists.Push(PlaylistHasErrors(name) ? "[!] " name : name)
            lbPlaylists.Add(displayPlaylists)
            lbPlaylists.Value := newIdx
        } else if (reorderMode = "songs") {
            if (lbPlaylists.Value = 0 || lbSongs.Value = 0)
                return
            name := lbPlaylists.Text
            name := RegExReplace(name, "^\[!\] ", "")
			idx := lbSongs.Value
            newIdx := idx + direction
            if (newIdx < 1 || newIdx > playlists[name].Length)
                return
            temp := playlists[name][idx]
            playlists[name][idx] := playlists[name][newIdx]
            playlists[name][newIdx] := temp
            SavePlaylistToIni(name)
            UpdateSongList()
            lbSongs.Value := newIdx
        }
    }
}  
 

TogglePlaylistLoop(*) {
    global playlistLoop, btnLoop, configFile
    playlistLoop := !playlistLoop
    IniWrite(playlistLoop ? "1" : "0", configFile, "State", "Loop")
    btnLoop.Text := playlistLoop ? L["loop_on"] : L["loop_off"]
}

TogglePlaylistRandom(*) {
    global playlistRandom, btnRandom, configFile
    playlistRandom := !playlistRandom
    IniWrite(playlistRandom ? "1" : "0", configFile, "State", "Random")
    btnRandom.Text := playlistRandom ? L["random_on"] : L["random_off"]
}

GetSongMetadata(filePath) {
    shell := ComObject("Shell.Application")
    folder := shell.NameSpace(RegExReplace(filePath, "\\[^\\]+$"))
    file := folder.ParseName(RegExReplace(filePath, "^.*\\"))

    artist := folder.GetDetailsOf(file, 13)
    if (InStr(artist, ";"))
    artist := Trim(SubStr(artist, 1, InStr(artist, ";") - 1))
    album  := folder.GetDetailsOf(file, 14)
    title  := folder.GetDetailsOf(file, 21)

    if (title = "")
        title := RegExReplace(filePath, "^.*\\")

    return Map("artist", artist, "album", album, "title", title)
}

; ================================================================
;  Barra de progreso de reproduccion
;  Arquitectura simplificada: consulta VLC directamente cada 800ms
;  Sin reloj manual, sin interpolacion, sin mutex complejo.
;  contornoprogreso.png = fondo 273x6 en x42 y59
;  barraprogreso.png    = relleno 271x4 en x43 y60
; ================================================================
PROG_X := 43
PROG_W := 271

; Estado
progTotalSecs   := 0
progCurrentSecs := 0
progIsPaused    := false
progDragging    := false
progDragSec     := 0
progPendingSeek := -1
progSeekTime    := 0   ; tick del ultimo seek, para ignorar polls inmediatos
progBusy        := false   ; evita consultas simultanias

; Controles
imgProgContorno := 0
imgProgBarra    := 0
lblProgCurrent  := 0
lblProgTotal    := 0

; ----------------------------------------------------------------
;  DrawProgBar
; ----------------------------------------------------------------
DrawProgBar(secs) {
    global imgProgBarra, progTotalSecs, PROG_W, miniPlayerShown
    if (!miniPlayerShown || !IsObject(imgProgBarra) || progTotalSecs <= 0)
        return
    N := Max(1, Min(Round((secs / progTotalSecs) * PROG_W), PROG_W))
    imgProgBarra.Move(, , N)
}

; ----------------------------------------------------------------
;  FormatProgTime
; ----------------------------------------------------------------
FormatProgTime(secs) {
    if (secs = "" || !IsNumber(secs) || secs < 0)
        return "00:00"
    secs := Round(secs)
    return Format("{:02d}:{:02d}", secs // 60, Mod(secs, 60))
}

; ----------------------------------------------------------------
;  ProgVLCQuery - una sola conexion, devuelve numero
; ----------------------------------------------------------------
ProgVLCQuery(cmd) {
    global vlcRCPort
    wsaData := Buffer(408, 0)
    DllCall("ws2_32\WSAStartup", "UShort", 0x0202, "Ptr", wsaData)
    socket := DllCall("ws2_32\socket", "Int", 2, "Int", 1, "Int", 6, "Ptr")
    if (socket = -1)
        return -1
    addr := Buffer(16, 0)
    NumPut("UShort", 2, addr, 0)
    NumPut("UShort", DllCall("ws2_32\htons", "UShort", vlcRCPort, "UShort"), addr, 2)
    NumPut("UInt",   DllCall("ws2_32\inet_addr", "AStr", "127.0.0.1", "UInt"), addr, 4)
    if (DllCall("ws2_32\connect", "Ptr", socket, "Ptr", addr, "Int", 16, "Int") != 0) {
        DllCall("ws2_32\closesocket", "Ptr", socket)
        return -1
    }
    cmdBuf := Buffer(StrPut(cmd "`n", "UTF-8"), 0)
    StrPut(cmd "`n", cmdBuf, "UTF-8")
    DllCall("ws2_32\send", "Ptr", socket, "Ptr", cmdBuf, "Int", cmdBuf.Size - 1, "Int", 0)
    Sleep(150)
    recvBuf   := Buffer(256, 0)
    bytesRecv := DllCall("ws2_32\recv", "Ptr", socket, "Ptr", recvBuf, "Int", 255, "Int", 0, "Int")
    DllCall("ws2_32\closesocket", "Ptr", socket)
    if (bytesRecv <= 0)
        return -1
    raw := StrGet(recvBuf, bytesRecv, "UTF-8")
    if RegExMatch(raw, "\b(\d+)\b", &m)
        return Number(m[1])
    return -1
}

; ----------------------------------------------------------------
;  ProgPoll - timer principal, corre en su propio hilo de timer
;  Consulta VLC y actualiza todo. Sin interpolacion.
; ----------------------------------------------------------------
ProgPoll() {
    global progTotalSecs, progCurrentSecs, progIsPaused, progBusy
    global progPendingSeek, progDragging, miniPlayerShown, vlcPID, progSeekTime
    global lblProgCurrent, lblProgTotal

    Critical "Off"

    if (!miniPlayerShown || progBusy || progDragging || isWindowMoving)
        return

    if (!ProcessExist(vlcPID))
        return

    ; Ejecutar seek pendiente y arrancar el cooldown
    if (progPendingSeek >= 0) {
        s := progPendingSeek
        progPendingSeek := -1
        ProgDoSeek(s)
        progSeekTime := A_TickCount
        ; Mostrar la posicion del seek inmediatamente sin esperar a VLC
        try DrawProgBar(progCurrentSecs)
        try lblProgCurrent.Text := FormatProgTime(progCurrentSecs)
        return
    }

    ; Durante el cooldown (2000ms tras un seek) mostrar progCurrentSecs
    ; sin consultar get_time para evitar el retroceso visual
    if (progSeekTime > 0 && A_TickCount - progSeekTime < 2000) {
        try DrawProgBar(progCurrentSecs)
        try lblProgCurrent.Text := FormatProgTime(progCurrentSecs)
        try lblProgTotal.Text   := FormatProgTime(progTotalSecs)
        return
    }
    progSeekTime := 0

    progBusy := true
    l := ProgVLCQuery("get_length")
    t := ProgVLCQuery("get_time")
    progBusy := false

    if (l > 0)
        progTotalSecs := l

    if (t >= 0 && progTotalSecs > 0 && !progDragging) {
        progCurrentSecs := t
        try DrawProgBar(t)
        try lblProgCurrent.Text := FormatProgTime(t)
        try lblProgTotal.Text   := FormatProgTime(progTotalSecs)
    }
}

; ----------------------------------------------------------------
;  ProgDoSeek - envia seek a VLC directamente (sin Sleep largo)
; ----------------------------------------------------------------
ProgDoSeek(s) {
    global vlcRCPort, progCurrentSecs
    wsaData := Buffer(408, 0)
    DllCall("ws2_32\WSAStartup", "UShort", 0x0202, "Ptr", wsaData)
    socket := DllCall("ws2_32\socket", "Int", 2, "Int", 1, "Int", 6, "Ptr")
    if (socket = -1)
        return
    addr := Buffer(16, 0)
    NumPut("UShort", 2, addr, 0)
    NumPut("UShort", DllCall("ws2_32\htons", "UShort", vlcRCPort, "UShort"), addr, 2)
    NumPut("UInt",   DllCall("ws2_32\inet_addr", "AStr", "127.0.0.1", "UInt"), addr, 4)
    if (DllCall("ws2_32\connect", "Ptr", socket, "Ptr", addr, "Int", 16, "Int") = 0) {
        cmd    := "seek " s
        cmdBuf := Buffer(StrPut(cmd "`n", "UTF-8"), 0)
        StrPut(cmd "`n", cmdBuf, "UTF-8")
        DllCall("ws2_32\send", "Ptr", socket, "Ptr", cmdBuf, "Int", cmdBuf.Size - 1, "Int", 0)
        progCurrentSecs := s
    }
    DllCall("ws2_32\closesocket", "Ptr", socket)
}

; ----------------------------------------------------------------
;  StartProgTimers / StopProgTimers
; ----------------------------------------------------------------
StartProgTimers() {
    SetTimer(ProgPoll, 800)
}

StopProgTimers() {
    SetTimer(ProgPoll, 0)
}


; ----------------------------------------------------------------
;  Barra de volumen
; ----------------------------------------------------------------
;  contornoslider.png = fondo fijo (50x4 px)
;  rellenoslider.png  = relleno cuyo ancho cambia (0-50 px)
;  Ambas en x267 y83. rellenoslider va encima de contornoslider.
; ================================================================
VOL_X := 267
VOL_Y := 83
VOL_W := 50
VOL_H := 4

DrawVolBar(level) {
    global imgVolRelleno, miniPlayerShown, VOL_W

    if (!miniPlayerShown || !IsObject(imgVolRelleno))
        return

    N := Round(Max(0, Min(level, 100)) / 100 * VOL_W)
    N := Max(1, N)   ; minimo 1px para que el control no desaparezca
    imgVolRelleno.Move(, , N)
}

OpenMiniPlayer(*) {
    global miniPlayer, miniPlayerShown, currentSong, isPlaying, isPaused, repeatLoop
    global lblArtist, lblAlbum, lblTitle

    if (miniPlayerShown && IsObject(miniPlayer)) {
    CloseMiniPlayer()
    Sleep(100)
}

    miniPlayer := Gui("-Caption +ToolWindow +AlwaysOnTop")
    miniPlayer.SetFont("s9", "Segoe UI")
    miniPlayer.BackColor := "1a1a2e"

    global imgBackground
    imgBackground := miniPlayer.AddPicture("x0 y0 w360 h105", A_Temp "\Rocola\MiniPlay1.png")
    global imgProgContorno, imgProgBarra, lblProgCurrent, lblProgTotal
    imgProgContorno := miniPlayer.AddPicture("x42 y58 w273 h6", A_Temp "\Rocola\contornoprogreso.png")
    imgProgBarra    := miniPlayer.AddPicture("x43 y59 w271 h4", A_Temp "\Rocola\barraprogreso.png")
    lblProgCurrent  := miniPlayer.AddText("x-5 y54 w37 BackgroundTrans cWhite Right", "00:00")
    lblProgCurrent.SetFont("s7")
    lblProgTotal    := miniPlayer.AddText("x328 y54 w37 BackgroundTrans cWhite", "00:00")
    lblProgTotal.SetFont("s7")

	global imgVolRelleno, imgVolContorno, imgVolIcon, volumeLevel, isMuted

    imgVolContorno := miniPlayer.AddPicture("x267 y83 w50 h4", A_Temp "\Rocola\contornoslider.png")
    imgVolRelleno  := miniPlayer.AddPicture("x267 y83 w50 h4", A_Temp "\Rocola\rellenoslider.png")
    imgVolIcon     := miniPlayer.AddPicture("x233 y74 w30 h23 Background111124", A_Temp "\Rocola\volumenalto.png")

    global lblArtist, lblAlbum, lblTitle
    lblArtist := miniPlayer.AddText("x8 y4  w340 BackgroundTrans cWhite 0x40C0", L["artist"] ":")
    lblAlbum  := miniPlayer.AddText("x8 y20 w340 BackgroundTrans cWhite 0x40C0", L["album"] ":")
    lblTitle  := miniPlayer.AddText("x8 y36 w340 BackgroundTrans cWhite 0x40C0", L["title"] ":")

    miniPlayer.OnEvent("Close", CloseMiniPlayer)
    miniPlayerShown := true
    UpdateMiniPlayer()
    x := (A_ScreenWidth - 360) // 2
    y := (A_ScreenHeight - 105) // 2
    miniPlayer.Show("x" x " y" y " w360 h105")
    UpdateVolumeIcon()
    DrawVolBar(volumeLevel)
    StartProgTimers()
}

CloseMiniPlayer(*) {
    global miniPlayer, miniPlayerShown, trayTipShown
    miniPlayerShown := false
    StopProgTimers()
    miniPlayer.Destroy()
}



UpdateMiniPlayer() {
    global miniPlayer, miniPlayerShown, currentSong, isPlaying, isPaused, repeatLoop
    global lblArtist, lblAlbum, lblTitle
    if (!miniPlayerShown || !IsObject(miniPlayer))
        return
    if (currentSong = "" || InStr(currentSong, "rocola.wav")) {
        lblArtist.Text := L["artist"] ":"
        lblAlbum.Text  := L["album"] ":"
        lblTitle.Text  := L["title"] ":"
        return
    }
    meta := GetSongMetadata(currentSong)
    lblArtist.Text := L["artist"] ": " meta["artist"]
    lblAlbum.Text  := L["album"] ": " meta["album"]
    lblTitle.Text  := L["title"] ": " meta["title"]
	UpdateMiniPlayerImage()
}

UpdateMiniPlayerImage() {
    global imgBackground, isPlaying, isPaused, repeatLoop, miniPlayerShown
    global volumeLevel

    if (!miniPlayerShown || !IsObject(imgBackground))
        return

    if (!isPaused && repeatLoop)
        imgBackground.Value := A_Temp "\Rocola\MiniPlay2.png"
    else if (isPaused && !repeatLoop)
        imgBackground.Value := A_Temp "\Rocola\MiniPlay3.png"
    else if (isPaused && repeatLoop)
        imgBackground.Value := A_Temp "\Rocola\MiniPlay4.png"
    else
        imgBackground.Value := A_Temp "\Rocola\MiniPlay1.png"

    DrawVolBar(volumeLevel)
}

UpdateVolumeIcon() {
    global imgVolIcon, volumeLevel, isMuted, miniPlayerShown
    static lastIcon := ""
    if (!miniPlayerShown || !IsObject(imgVolIcon))
        return
    if (isMuted || volumeLevel = 0)
        newIcon := A_Temp "\Rocola\muteado.png"
    else if (volumeLevel <= 33)
        newIcon := A_Temp "\Rocola\pocovolumen.png"
    else if (volumeLevel <= 66)
        newIcon := A_Temp "\Rocola\volumenmedio.png"
    else
        newIcon := A_Temp "\Rocola\volumenalto.png"
    if (newIcon != lastIcon) {
        imgVolIcon.Value := newIcon
        lastIcon := newIcon
    }
}

ToggleMute(*) {
    global isMuted, volumeLevel, volumeBeforeMute, vlcPID
    static lastMuteTime := 0
    if (A_TickCount - lastMuteTime < 300)
        return
    lastMuteTime := A_TickCount
    if (!ProcessExist(vlcPID))
        return
    if (!isMuted) {
    volumeBeforeMute := Integer(IniRead(configFile, "State", "Volume", "100"))
    volumeLevel := volumeBeforeMute
        isMuted := true
        SendVLCCommand("volume 0")
        DrawVolBar(0)
    } else {
        isMuted := false
        volumeLevel := volumeBeforeMute
        SendVLCCommand("volume " Round(volumeLevel * 256 / 100))
		IniWrite(volumeLevel, configFile, "State", "Volume")
        DrawVolBar(volumeLevel)
    }
    UpdateVolumeIcon()
}

VolumeUp(*) {
    global volumeLevel, vlcPID, isMuted, configFile
    if (isMuted)
        return
    volumeLevel := Min(100, volumeLevel + 2)
    DrawVolBar(volumeLevel)
    if (ProcessExist(vlcPID))
        SendVLCCommand("volume " Round(volumeLevel * 256 / 100))
    IniWrite(volumeLevel, configFile, "State", "Volume")
    UpdateVolumeIcon()
}

VolumeDown(*) {
    global volumeLevel, vlcPID, isMuted, configFile
    if (isMuted)
        return
    volumeLevel := Max(0, volumeLevel - 2)
    DrawVolBar(volumeLevel)
    if (ProcessExist(vlcPID))
        SendVLCCommand("volume " Round(volumeLevel * 256 / 100))
    IniWrite(volumeLevel, configFile, "State", "Volume")
    UpdateVolumeIcon()
}

WM_LBUTTONDOWN(wParam, lParam, msg, hwnd) {
    global miniPlayer, miniPlayerShown, isPlaying, isPaused, repeatLoop, volumeLevel, isMuted, vlcPID, configFile, volDragging
    global progDragging, progDragSec, progTotalSecs, PROG_X, PROG_W, lblProgCurrent, imgProgBarra
    if (!miniPlayerShown || !IsObject(miniPlayer))
    return
    if (hwnd != miniPlayer.Hwnd && hwnd != imgVolContorno.Hwnd)
    return
    x := lParam & 0xFFFF
    y := (lParam >> 16) & 0xFFFF
    if (hwnd != miniPlayer.Hwnd) {
    pt := Buffer(8)
    NumPut("Int", x, pt, 0)
    NumPut("Int", y, pt, 4)
    DllCall("ClientToScreen", "Ptr", hwnd, "Ptr", pt)
    DllCall("ScreenToClient", "Ptr", miniPlayer.Hwnd, "Ptr", pt)
    x := NumGet(pt, 0, "Int")
    y := NumGet(pt, 4, "Int")
}

    ; PrevSong
    if (x >= 12 && x <= 38 && y >= 79 && y <= 95)
        PrevSong()

    ; Pausar/Reanudar
    else if (x >= 54 && x <= 69 && y >= 77 && y <= 95) {
        TogglePause()
        UpdateMiniPlayerImage()
    }

    ; Bucle
    else if (x >= 84 && x <= 112 && y >= 76 && y <= 98) {
        ToggleRepeatLoop()
        UpdateMiniPlayerImage()
    }

    ; NextSong
    else if (x >= 122 && x <= 149 && y >= 76 && y <= 96)
        PlayNext()

    ; Playlist
    else if (x >= 163 && x <= 182 && y >= 76 && y <= 95) {
    OpenPlaylistManager()
    DrawVolBar(volumeLevel)
}

    ; Buscar
    else if (x >= 196 && x <= 220 && y >= 74 && y <= 98) {
    OpenSearchWindow()
    DrawVolBar(volumeLevel)
}

    ; Cerrar
    else if (x >= 330 && x <= 359 && y >= 71 && y <= 100)
        CloseMiniPlayer()

    ; Barra de progreso — iniciar drag/click
    else if (x >= 43 && x <= 314 && y >= 56 && y <= 65) {
        if (progTotalSecs > 0) {
            progDragging := true
            DllCall("SetCapture", "Ptr", miniPlayer.Hwnd)
            progDragSec := Round(Max(0, Min(x - PROG_X, PROG_W)) / PROG_W * progTotalSecs)
            DrawProgBar(progDragSec)
            lblProgCurrent.Text := FormatProgTime(progDragSec)
			progSeekTime := A_TickCount
        }
    }

    ; Icono de volumen — mute/unmute
    else if (x >= 233 && x <= 263 && y >= 74 && y <= 97)
        ToggleMute()

    ; Slider de volumen — iniciar drag
    else if (x >= 265 && x <= 319 && y >= 65 && y <= 100) {
        if (!isMuted) {
            volDragging := true
            DllCall("SetCapture", "Ptr", miniPlayer.Hwnd)
            volumeLevel := Max(0, Min(100, (x - 267) * 2))
            DrawVolBar(volumeLevel)
        }
    }

    ; Arrastrar ventana
    else
        PostMessage(0xA1, 2, 0, , miniPlayer.Hwnd)
}
; Detectar movimiento de ventana para pausar ProgPoll
WM_MOVING_Handler(wParam, lParam, msg, hwnd) {
    global isWindowMoving, miniPlayer, miniPlayerShown
    if (miniPlayerShown && IsObject(miniPlayer) && hwnd = miniPlayer.Hwnd)
        isWindowMoving := true
}
WM_EXITSIZEMOVE_Handler(wParam, lParam, msg, hwnd) {
    global isWindowMoving
    isWindowMoving := false
}
OnMessage(0x0216, WM_MOVING_Handler)
OnMessage(0x0232, WM_EXITSIZEMOVE_Handler)

OnMessage(0x201, WM_LBUTTONDOWN)

WM_MOUSEMOVE(wParam, lParam, msg, hwnd) {
    global miniPlayer, miniPlayerShown, volumeLevel, vlcPID, isMuted, volDragging
    global progDragging, progDragSec, progTotalSecs, PROG_X, PROG_W, lblProgCurrent

    if (!miniPlayerShown || !IsObject(miniPlayer))
        return
    if (!volDragging && !progDragging)
        return
    if (!(wParam & 0x1)) {
        volDragging  := false
        progDragging := false
        DllCall("ReleaseCapture")
        return
    }

    pt := Buffer(8, 0)
    DllCall("GetCursorPos", "Ptr", pt)
    DllCall("ScreenToClient", "Ptr", miniPlayer.Hwnd, "Ptr", pt)
    x := NumGet(pt, 0, "Int")

    if (volDragging && !isMuted) {
        volumeLevel := Max(0, Min(100, (x - 267) * 2))
        DrawVolBar(volumeLevel)
        UpdateVolumeIcon()
        SetTimer(ApplyVolumeDrag, 16)
    }

    if (progDragging && progTotalSecs > 0) {
        progDragSec := Round(Max(0, Min(x - PROG_X, PROG_W)) / PROG_W * progTotalSecs)
        DrawProgBar(progDragSec)
        lblProgCurrent.Text := FormatProgTime(progDragSec)
    }
}
OnMessage(0x200, WM_MOUSEMOVE)

; Version ligera de SendVLCCommand para el volumen durante drag:
; un solo intento sin loop ni Sleep para no bloquear el hilo principal
ApplyVolumeDrag() {
    global volumeLevel, vlcRCPort
    wsaData := Buffer(408, 0)
    DllCall("ws2_32\WSAStartup", "UShort", 0x0202, "Ptr", wsaData)
    socket := DllCall("ws2_32\socket", "Int", 2, "Int", 1, "Int", 6, "Ptr")
    if (socket = -1)
        return
    addr := Buffer(16, 0)
    NumPut("UShort", 2, addr, 0)
    NumPut("UShort", DllCall("ws2_32\htons", "UShort", vlcRCPort, "UShort"), addr, 2)
    NumPut("UInt",   DllCall("ws2_32\inet_addr", "AStr", "127.0.0.1", "UInt"), addr, 4)
    if (DllCall("ws2_32\connect", "Ptr", socket, "Ptr", addr, "Int", 16, "Int") = 0) {
        cmd    := "volume " Round(volumeLevel * 256 / 100)
        cmdBuf := Buffer(StrPut(cmd "`n", "UTF-8"), 0)
        StrPut(cmd "`n", cmdBuf, "UTF-8")
        DllCall("ws2_32\send", "Ptr", socket, "Ptr", cmdBuf, "Int", cmdBuf.Size - 1, "Int", 0)
    }
    DllCall("ws2_32\closesocket", "Ptr", socket)
}

WM_LBUTTONUP_All(wParam, lParam, msg, hwnd) {
    global miniPlayer, miniPlayerShown
    global volDragging, volumeLevel, isMuted, configFile
    global progDragging, progDragSec, progPendingSeek, progCurrentSecs

    if (!miniPlayerShown)
        return

    if (volDragging) {
        volDragging := false
        DllCall("ReleaseCapture")
        SetTimer(ApplyVolumeDrag, 0)   ; detener el timer
        if (!isMuted) {
            ApplyVolumeDrag()           ; envio final garantizado
            IniWrite(volumeLevel, configFile, "State", "Volume")
        }
    }

    if (progDragging) {
        progDragging    := false
        DllCall("ReleaseCapture")
        progCurrentSecs := progDragSec
        progPendingSeek := progDragSec
        
    }
}
OnMessage(0x202, WM_LBUTTONUP_All)

OpenMusicFolderManager(*) {
    global configFile

    folderGui := Gui("+AlwaysOnTop +OwnDialogs", L["music_folders_title"])
    folderGui.SetFont("s10")

    folderGui.AddText("xm w300", L["music_folders_label"])
    lbFolders := folderGui.AddListBox("xm w300 h150 y+5 HScroll")

    btnAdd    := folderGui.AddButton("xm w95 y+5", L["add_folder"])
    btnChange := folderGui.AddButton("x+5 w95", L["change_folder_btn"])
    btnRemove := folderGui.AddButton("x+5 w95", L["remove_folder"])
    btnAddRecursive := folderGui.AddButton("xm w310 y+5 Center", L["add_folder_recursive"])

    RefreshFolderList()

    btnAdd.OnEvent("Click", AddFolder)
    btnChange.OnEvent("Click", ChangeFolder)
    btnRemove.OnEvent("Click", RemoveFolder)
    btnAddRecursive.OnEvent("Click", AddFolderRecursive)

    folderGui.Show()

    RefreshFolderList() {
    lbFolders.Delete()
    for folder in GetMusicFolders() {
        if (DirExist(folder))
            lbFolders.Add([folder])
        else
            lbFolders.Add(["[!] " folder])
    }
}

    AddFolder(*) {
        folderGui.Hide()
        folder := DirSelect(, , L["select_music_folder_dir"])
        folderGui.Show()
        if (folder = "" || !DirExist(folder))
            return
        for existing in GetMusicFolders()
            if (existing = folder)
                return
        folders := GetMusicFolders()
        i := folders.Length + 1
        IniWrite(folder, configFile, "Paths", "MusicFolder" i)
        LoadSongs()
        ShuffleSongs()
        RefreshFolderList()
    }

    AddFolderRecursive(*) {
        folderGui.Hide()
        folder := DirSelect(, , L["select_music_folder_dir"])
        folderGui.Show()
        if (folder = "" || !DirExist(folder))
            return
        toAdd := []
        ; Agregar carpeta madre si no existe
        alreadyExists := false
        for existing in GetMusicFolders()
            if (existing = folder)
                alreadyExists := true
        if (!alreadyExists)
            toAdd.Push(folder)
        ; Recorrer subcarpetas recursivamente
        Loop Files folder "\*", "DR" {
            sub := A_LoopFileFullPath
            alreadyExists := false
            for existing in GetMusicFolders()
                if (existing = sub)
                    alreadyExists := true
            if (!alreadyExists)
                toAdd.Push(sub)
        }
        if (toAdd.Length = 0) {
            RefreshFolderList()
            return
        }
        folders := GetMusicFolders()
        for _, newFolder in toAdd {
            i := folders.Length + 1
            IniWrite(newFolder, configFile, "Paths", "MusicFolder" i)
            folders.Push(newFolder)
        }
        LoadSongs()
        ShuffleSongs()
        RefreshFolderList()
    }

    ChangeFolder(*) {
        if (lbFolders.Value = 0)
            return
        folderGui.Hide()
        folder := DirSelect(, , L["select_new_location"])
        folderGui.Show()
        if (folder = "" || !DirExist(folder))
            return
        idx := lbFolders.Value
        IniWrite(folder, configFile, "Paths", "MusicFolder" idx)
        LoadSongs()
        ShuffleSongs()
        RefreshFolderList()
    }

    RemoveFolder(*) {
        if (lbFolders.Value = 0)
            return
        folders := GetMusicFolders()
        if (folders.Length = 1) {
            MsgBox(L["must_keep_one_folder"], "Error", "Owner" folderGui.Hwnd)
            return
        }
        idx := lbFolders.Value
        folders.RemoveAt(idx)
        Loop 20
            IniDelete(configFile, "Paths", "MusicFolder" A_Index)
        for i, f in folders
            IniWrite(f, configFile, "Paths", "MusicFolder" i)
        LoadSongs()
        ShuffleSongs()
        RefreshFolderList()
    }
}

; ================= TRAY DINÁMICO =================

SwitchToPlaylistTray() {
    global repeatLoop, autoMode

    A_TrayMenu.Delete()

    A_TrayMenu.Add(L["return_normal_mode"], ReturnToNormalMode)
    A_TrayMenu.Add()
    A_TrayMenu.Add(L["search_song"], OpenSearchWindow)
    A_TrayMenu.Add(L["playlist_manager"], OpenPlaylistManager)
    A_TrayMenu.Add(L["open_miniplayer"], OpenMiniPlayer)
    A_TrayMenu.Add()
    if (autoMode)
        A_TrayMenu.Add(L["auto_mode_on"], ToggleAutoMode)
    else
        A_TrayMenu.Add(L["auto_mode_off"], ToggleAutoMode)
    A_TrayMenu.Add(L["pause_resume"], TogglePause)
    A_TrayMenu.Add(repeatLoop ? L["repeat_song"] " [On]" : L["repeat_song"] " [Off]", ToggleRepeatLoop)
    A_TrayMenu.Add()
    A_TrayMenu.Add(L["change_music_folder"], OpenMusicFolderManager)
    A_TrayMenu.Add(L["change_vlc"], SelectVLC)
    A_TrayMenu.Add(L["assign_hotkeys"], OpenHotkeyWindow)
    A_TrayMenu.Add(L["change_language"], OpenLanguageSelector)
    A_TrayMenu.Add()
    A_TrayMenu.Add(L["quit"], CloseApp)
}

RestoreNormalTray() {
    global autoMode

    A_TrayMenu.Delete()

    A_TrayMenu.Add(L["search_song"], OpenSearchWindow)
    A_TrayMenu.Add(L["playlist_manager"], OpenPlaylistManager)
	A_TrayMenu.Add(L["open_miniplayer"], OpenMiniPlayer)
    A_TrayMenu.Add()

    if (autoMode)
        A_TrayMenu.Add(L["auto_mode_on"], ToggleAutoMode)
    else
        A_TrayMenu.Add(L["auto_mode_off"], ToggleAutoMode)

    A_TrayMenu.Add(L["pause_resume"], TogglePause)
    A_TrayMenu.Add(repeatLoop ? L["repeat_song"] " [On]" : L["repeat_song"] " [Off]", ToggleRepeatLoop)
    A_TrayMenu.Add()
    A_TrayMenu.Add(L["change_music_folder"], OpenMusicFolderManager)
    A_TrayMenu.Add(L["change_vlc"], SelectVLC)
    A_TrayMenu.Add(L["assign_hotkeys"], OpenHotkeyWindow)
	A_TrayMenu.Add(L["change_language"], OpenLanguageSelector)
    A_TrayMenu.Add()
    A_TrayMenu.Add(L["quit"], CloseApp)
}

ReturnToNormalMode(*) {
    global playMode, isPlaylistMode
    global currentPlaylistGlobalIndex
    global playlistLoop
    global autoMode
    global playlistInsertQueue

    playMode := "normal"
    isPlaylistMode := false
    currentPlaylistGlobalIndex := 0
    playlistLoop := false
    playlistInsertQueue := []

    ; NO llamar ShuffleSongs() — el shuffle normal ya existe con su currentIndex intacto
    RestoreNormalTray()
}



LoadSongs()
ShuffleSongs()
LoadHotkeysFromIni()
LoadPlaylistsFromIni()
SetTimer(RefreshSongs, 1000)


OnMessage(0x404, TrayClick)
return